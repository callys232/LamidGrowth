import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilityDevelopmentSlide2,
  ClarityPatternsSlide1,
  CompletedActionsSlide4,
  ConsistencyHistorySlide3,
  OsProgressHeroSlide,
  OutcomesSlide5,
  TraceAnOutcomeBackToTheWorkSlide6,
} from './slides';

/** /os/progress — sections in reading order. */
export function OsProgressDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsProgressHeroSlide embedded={embedded} />}
    >
      <ClarityPatternsSlide1 embedded={embedded} />
      <CapabilityDevelopmentSlide2 embedded={embedded} />
      <ConsistencyHistorySlide3 embedded={embedded} />
      <CompletedActionsSlide4 embedded={embedded} />
      <OutcomesSlide5 embedded={embedded} />
      <TraceAnOutcomeBackToTheWorkSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
