import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BusinessGrowthSlide2,
  GrowWithoutLosingControlSlide4,
  GrowthChangesByContextTheOperatingPrinciplesStayConsistentSlide5,
  HowItWorksGrowthHeroSlide,
  OrganizationalGrowthSlide3,
  PersonalGrowthSlide1,
} from './slides';

/** /how-it-works/growth — sections in reading order. */
export function HowItWorksGrowthDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksGrowthHeroSlide embedded={embedded} />}
    >
      <PersonalGrowthSlide1 embedded={embedded} />
      <BusinessGrowthSlide2 embedded={embedded} />
      <OrganizationalGrowthSlide3 embedded={embedded} />
      <GrowWithoutLosingControlSlide4 embedded={embedded} />
      <GrowthChangesByContextTheOperatingPrinciplesStayConsistentSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
