import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ApprovalsSlide5,
  DefineHowCompletionWillBeJudgedSlide9,
  DependenciesSlide4,
  HistorySlide8,
  OsWorkflowsDetailHeroSlide,
  OutcomeSlide1,
  OwnersSlide3,
  StatusSlide6,
  StepsSlide2,
  SuggestedNextActionsSlide7,
} from './slides';

/** /os/workflows/[id] — sections in reading order. */
export function OsWorkflowsDetailDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsWorkflowsDetailHeroSlide embedded={embedded} />}
    >
      <OutcomeSlide1 embedded={embedded} />
      <StepsSlide2 embedded={embedded} />
      <OwnersSlide3 embedded={embedded} />
      <DependenciesSlide4 embedded={embedded} />
      <ApprovalsSlide5 embedded={embedded} />
      <StatusSlide6 embedded={embedded} />
      <SuggestedNextActionsSlide7 embedded={embedded} />
      <HistorySlide8 embedded={embedded} />
      <DefineHowCompletionWillBeJudgedSlide9 embedded={embedded} />
    </DocumentPageLayout>
  );
}
