import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  FromAgreementToVerifiedOutcomeSlide7,
  LaunchANewServiceSlide5,
  ProductWorkflowsHeroSlide,
  ProgressWithinTheBoundariesYouSetSlide6,
  RepeatWhatWorksSlide4,
  StartSimpleSlide1,
  StructureComplexWorkSlide2,
  SuggestedNextActionsSlide3,
} from './slides';

/** /product/workflows — sections in reading order. */
export function ProductWorkflowsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductWorkflowsHeroSlide embedded={embedded} />}
    >
      <StartSimpleSlide1 embedded={embedded} />
      <StructureComplexWorkSlide2 embedded={embedded} />
      <SuggestedNextActionsSlide3 embedded={embedded} />
      <RepeatWhatWorksSlide4 embedded={embedded} />
      <LaunchANewServiceSlide5 embedded={embedded} />
      <ProgressWithinTheBoundariesYouSetSlide6 embedded={embedded} />
      <FromAgreementToVerifiedOutcomeSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
