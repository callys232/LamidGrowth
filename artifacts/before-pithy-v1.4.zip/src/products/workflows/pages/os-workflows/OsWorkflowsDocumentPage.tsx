import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ActiveWorkflowsSlide1,
  CommercialDeliveryWorkflowsSlide5,
  CompletedWorkflowsSlide4,
  OsWorkflowsHeroSlide,
  SuggestedWorkflowsSlide3,
  TemplatesSlide2,
} from './slides';

/** /os/workflows — sections in reading order. */
export function OsWorkflowsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsWorkflowsHeroSlide embedded={embedded} />}
    >
      <ActiveWorkflowsSlide1 embedded={embedded} />
      <TemplatesSlide2 embedded={embedded} />
      <SuggestedWorkflowsSlide3 embedded={embedded} />
      <CompletedWorkflowsSlide4 embedded={embedded} />
      <CommercialDeliveryWorkflowsSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
