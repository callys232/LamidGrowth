import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilityRequirementsSlide1,
  DevelopmentNeedsSlide5,
  GapsSlide3,
  OsPeopleHeroSlide,
  PeopleAreMoreThanAScoreSlide8,
  PrepareATeamForANewOperatingModelSlide7,
  RoleRequirementsSlide6,
  StrengthsSlide2,
  TeamAlignmentSlide4,
} from './slides';

/** /os/people — sections in reading order. */
export function OsPeopleDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsPeopleHeroSlide embedded={embedded} />}
    >
      <CapabilityRequirementsSlide1 embedded={embedded} />
      <StrengthsSlide2 embedded={embedded} />
      <GapsSlide3 embedded={embedded} />
      <TeamAlignmentSlide4 embedded={embedded} />
      <DevelopmentNeedsSlide5 embedded={embedded} />
      <RoleRequirementsSlide6 embedded={embedded} />
      <PrepareATeamForANewOperatingModelSlide7 embedded={embedded} />
      <PeopleAreMoreThanAScoreSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
