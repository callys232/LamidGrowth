import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilitiesSlide5,
  IntegrationsSlide7,
  MembersSlide1,
  OnboardANewBusinessUnitSlide9,
  OsAdminHeroSlide,
  PlansSlide4,
  PoliciesSlide6,
  RolesSlide3,
  SupportSlide8,
  TeamsSlide2,
} from './slides';

/** /os/admin — sections in reading order. */
export function OsAdminDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsAdminHeroSlide embedded={embedded} />}
    >
      <MembersSlide1 embedded={embedded} />
      <TeamsSlide2 embedded={embedded} />
      <RolesSlide3 embedded={embedded} />
      <PlansSlide4 embedded={embedded} />
      <CapabilitiesSlide5 embedded={embedded} />
      <PoliciesSlide6 embedded={embedded} />
      <IntegrationsSlide7 embedded={embedded} />
      <SupportSlide8 embedded={embedded} />
      <OnboardANewBusinessUnitSlide9 embedded={embedded} />
    </DocumentPageLayout>
  );
}
