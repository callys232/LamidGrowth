import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AlignStrategyAndDeliverySlide8,
  CapabilitySlide3,
  GovernanceSlide7,
  InsightsSlide6,
  OsOrganizationHeroSlide,
  PrioritiesSlide1,
  RhythmSlide4,
  TeamsSlide2,
  WorkflowsSlide5,
} from './slides';

/** /os/organization — sections in reading order. */
export function OsOrganizationDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsOrganizationHeroSlide embedded={embedded} />}
    >
      <PrioritiesSlide1 embedded={embedded} />
      <TeamsSlide2 embedded={embedded} />
      <CapabilitySlide3 embedded={embedded} />
      <RhythmSlide4 embedded={embedded} />
      <WorkflowsSlide5 embedded={embedded} />
      <InsightsSlide6 embedded={embedded} />
      <GovernanceSlide7 embedded={embedded} />
      <AlignStrategyAndDeliverySlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
