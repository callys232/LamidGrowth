import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AlignAMultiTeamTransformationSlide5,
  GovernanceSlide4,
  MultiTeamWorkSlide3,
  OrganizationalRhythmSlide2,
  ProductOrganizationsHeroSlide,
  ScaleTheCapabilityPreserveTheCoherenceSlide6,
  SharedContextSlide1,
} from './slides';

/** /product/organizations — sections in reading order. */
export function ProductOrganizationsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductOrganizationsHeroSlide embedded={embedded} />}
    >
      <SharedContextSlide1 embedded={embedded} />
      <OrganizationalRhythmSlide2 embedded={embedded} />
      <MultiTeamWorkSlide3 embedded={embedded} />
      <GovernanceSlide4 embedded={embedded} />
      <AlignAMultiTeamTransformationSlide5 embedded={embedded} />
      <ScaleTheCapabilityPreserveTheCoherenceSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
