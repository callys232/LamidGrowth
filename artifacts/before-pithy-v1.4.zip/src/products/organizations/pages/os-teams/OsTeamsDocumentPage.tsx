import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ActiveWorkSlide5,
  CapabilitySlide4,
  CoordinateTwoDependentTeamsSlide7,
  MembersRolesSlide2,
  OsTeamsHeroSlide,
  PrioritiesSlide3,
  RhythmSlide6,
  TeamOverviewSlide1,
} from './slides';

/** /os/teams — sections in reading order. */
export function OsTeamsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsTeamsHeroSlide embedded={embedded} />}
    >
      <TeamOverviewSlide1 embedded={embedded} />
      <MembersRolesSlide2 embedded={embedded} />
      <PrioritiesSlide3 embedded={embedded} />
      <CapabilitySlide4 embedded={embedded} />
      <ActiveWorkSlide5 embedded={embedded} />
      <RhythmSlide6 embedded={embedded} />
      <CoordinateTwoDependentTeamsSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
