import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilityPatternsSlide3,
  CrossTeamBlockersSlide2,
  ExecutionRhythmSlide4,
  OsOrganizationRhythmHeroSlide,
  ReviewSlide5,
  RunAMonthlyOperatingReviewSlide6,
  SharedPrioritiesSlide1,
} from './slides';

/** /os/organization/rhythm — sections in reading order. */
export function OsOrganizationRhythmDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsOrganizationRhythmHeroSlide embedded={embedded} />}
    >
      <SharedPrioritiesSlide1 embedded={embedded} />
      <CrossTeamBlockersSlide2 embedded={embedded} />
      <CapabilityPatternsSlide3 embedded={embedded} />
      <ExecutionRhythmSlide4 embedded={embedded} />
      <ReviewSlide5 embedded={embedded} />
      <RunAMonthlyOperatingReviewSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
