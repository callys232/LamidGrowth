import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  DeploymentReadinessSlide6,
  EnterpriseAdministrationSlide4,
  EnterpriseArchitectureSlide1,
  EnterpriseHeroSlide,
  EvaluateTrustControlSlide7,
  GovernanceArchitectureSlide2,
  IntegrationArchitectureSlide3,
  MultiUnitDeploymentSlide5,
} from './slides';

/** /enterprise — sections in reading order. */
export function EnterpriseDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<EnterpriseHeroSlide embedded={embedded} />}
    >
      <EnterpriseArchitectureSlide1 embedded={embedded} />
      <GovernanceArchitectureSlide2 embedded={embedded} />
      <IntegrationArchitectureSlide3 embedded={embedded} />
      <EnterpriseAdministrationSlide4 embedded={embedded} />
      <MultiUnitDeploymentSlide5 embedded={embedded} />
      <DeploymentReadinessSlide6 embedded={embedded} />
      <EvaluateTrustControlSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
