import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  DailyRhythmSlide1,
  ImportantAlertsSlide5,
  OsNotificationsHeroSlide,
  ProductUpdatesSlide6,
  QuietChangeSummariesSlide7,
  TeamActivitySlide4,
  WeeklyReviewSlide2,
  WorkflowUpdatesSlide3,
} from './slides';

/** /os/notifications — sections in reading order. */
export function OsNotificationsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsNotificationsHeroSlide embedded={embedded} />}
    >
      <DailyRhythmSlide1 embedded={embedded} />
      <WeeklyReviewSlide2 embedded={embedded} />
      <WorkflowUpdatesSlide3 embedded={embedded} />
      <TeamActivitySlide4 embedded={embedded} />
      <ImportantAlertsSlide5 embedded={embedded} />
      <ProductUpdatesSlide6 embedded={embedded} />
      <QuietChangeSummariesSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
