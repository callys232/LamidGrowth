import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiDataUseSlide6,
  MemorySlide4,
  PersonalAndOrganizationalContextSlide3,
  RetentionExportAndDeletionSlide5,
  ReviewYourDataFootprintSlide7,
  TrustPrivacyHeroSlide,
  WhatInformationIsUsedSlide1,
  WhyItIsUsedSlide2,
} from './slides';

/** /trust/privacy — sections in reading order. */
export function TrustPrivacyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<TrustPrivacyHeroSlide embedded={embedded} />}
    >
      <WhatInformationIsUsedSlide1 embedded={embedded} />
      <WhyItIsUsedSlide2 embedded={embedded} />
      <PersonalAndOrganizationalContextSlide3 embedded={embedded} />
      <MemorySlide4 embedded={embedded} />
      <RetentionExportAndDeletionSlide5 embedded={embedded} />
      <AiDataUseSlide6 embedded={embedded} />
      <ReviewYourDataFootprintSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
