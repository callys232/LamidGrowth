import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ActionSlide2,
  ActorSlide1,
  ContextSlide4,
  OsAuditHeroSlide,
  RelatedObjectWorkflowSlide6,
  ResultSlide5,
  TimeSlide3,
  TraceCommercialApprovalAndReleaseSlide7,
} from './slides';

/** /os/audit — sections in reading order. */
export function OsAuditDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsAuditHeroSlide embedded={embedded} />}
    >
      <ActorSlide1 embedded={embedded} />
      <ActionSlide2 embedded={embedded} />
      <TimeSlide3 embedded={embedded} />
      <ContextSlide4 embedded={embedded} />
      <ResultSlide5 embedded={embedded} />
      <RelatedObjectWorkflowSlide6 embedded={embedded} />
      <TraceCommercialApprovalAndReleaseSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
