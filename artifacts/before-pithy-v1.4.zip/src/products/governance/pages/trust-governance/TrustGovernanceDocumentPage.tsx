import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiGovernanceSlide5,
  ConnectedGovernanceClearResponsibilitiesSlide10,
  ContinuousIntelligenceGovernanceSlide6,
  ExperienceGovernanceSlide1,
  GovernAConsequentialWorkflowSlide9,
  OrganizationalGovernanceSlide3,
  OverrideReversalSlide8,
  PersistentProgressionGovernanceSlide7,
  PlatformGovernanceSlide4,
  ProductGovernanceSlide2,
  TrustGovernanceHeroSlide,
} from './slides';

/** /trust/governance — sections in reading order. */
export function TrustGovernanceDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<TrustGovernanceHeroSlide embedded={embedded} />}
    >
      <ExperienceGovernanceSlide1 embedded={embedded} />
      <ProductGovernanceSlide2 embedded={embedded} />
      <OrganizationalGovernanceSlide3 embedded={embedded} />
      <PlatformGovernanceSlide4 embedded={embedded} />
      <AiGovernanceSlide5 embedded={embedded} />
      <ContinuousIntelligenceGovernanceSlide6 embedded={embedded} />
      <PersistentProgressionGovernanceSlide7 embedded={embedded} />
      <OverrideReversalSlide8 embedded={embedded} />
      <GovernAConsequentialWorkflowSlide9 embedded={embedded} />
      <ConnectedGovernanceClearResponsibilitiesSlide10 embedded={embedded} />
    </DocumentPageLayout>
  );
}
