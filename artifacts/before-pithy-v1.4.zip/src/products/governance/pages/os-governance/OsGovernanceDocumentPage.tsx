import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AdministrativeControlsSlide6,
  AiPoliciesSlide1,
  CapabilityAvailabilitySlide3,
  DataPoliciesSlide4,
  OsGovernanceHeroSlide,
  PermissionsSlide2,
  SeparateObservationProgressionAndCommitmentSlide7,
  WorkflowApprovalsSlide5,
} from './slides';

/** /os/governance — sections in reading order. */
export function OsGovernanceDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsGovernanceHeroSlide embedded={embedded} />}
    >
      <AiPoliciesSlide1 embedded={embedded} />
      <PermissionsSlide2 embedded={embedded} />
      <CapabilityAvailabilitySlide3 embedded={embedded} />
      <DataPoliciesSlide4 embedded={embedded} />
      <WorkflowApprovalsSlide5 embedded={embedded} />
      <AdministrativeControlsSlide6 embedded={embedded} />
      <SeparateObservationProgressionAndCommitmentSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
