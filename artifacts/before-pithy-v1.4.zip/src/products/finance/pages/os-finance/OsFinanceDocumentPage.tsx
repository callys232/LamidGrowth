import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AnalysisIsNotFinancialAuthoritySlide9,
  AssumptionsSlide7,
  CashPositionSlide1,
  DecisionImpactSlide6,
  ForecastSlide3,
  OsFinanceHeroSlide,
  PricingSlide5,
  RunwaySlide2,
  ScenarioComparisonSlide4,
  TestAHiringPlanSlide8,
} from './slides';

/** /os/finance — sections in reading order. */
export function OsFinanceDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsFinanceHeroSlide embedded={embedded} />}
    >
      <CashPositionSlide1 embedded={embedded} />
      <RunwaySlide2 embedded={embedded} />
      <ForecastSlide3 embedded={embedded} />
      <ScenarioComparisonSlide4 embedded={embedded} />
      <PricingSlide5 embedded={embedded} />
      <DecisionImpactSlide6 embedded={embedded} />
      <AssumptionsSlide7 embedded={embedded} />
      <TestAHiringPlanSlide8 embedded={embedded} />
      <AnalysisIsNotFinancialAuthoritySlide9 embedded={embedded} />
    </DocumentPageLayout>
  );
}
