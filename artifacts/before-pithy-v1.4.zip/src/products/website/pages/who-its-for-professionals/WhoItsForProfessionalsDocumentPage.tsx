import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BuildRelevantCapabilitySlide2,
  CreateAProfessionalRhythmSlide3,
  MakeStrongerDecisionsSlide1,
  StepIntoALargerRoleSlide4,
  WhoItsForProfessionalsHeroSlide,
  YourContextGrowsWithYouSlide5,
} from './slides';

/** /who-its-for/professionals — sections in reading order. */
export function WhoItsForProfessionalsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForProfessionalsHeroSlide embedded={embedded} />}
    >
      <MakeStrongerDecisionsSlide1 embedded={embedded} />
      <BuildRelevantCapabilitySlide2 embedded={embedded} />
      <CreateAProfessionalRhythmSlide3 embedded={embedded} />
      <StepIntoALargerRoleSlide4 embedded={embedded} />
      <YourContextGrowsWithYouSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
