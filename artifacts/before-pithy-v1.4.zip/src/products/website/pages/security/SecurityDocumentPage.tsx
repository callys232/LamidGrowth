import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiToolUseSafetySlide6,
  AuthorizationBoundariesSlide2,
  CommercialPaymentBoundariesSlide7,
  DataFilesSecretsSlide4,
  EvidenceSlide9,
  IdentityAccountProtectionSlide1,
  IntegrationsApisWebhooksSlide5,
  MonitoringIncidentResponseResilienceSlide8,
  RateLimitingAbusePreventionSlide3,
  SecurityEvaluationSlide10,
  SecurityHeroSlide,
} from './slides';

/** /security — sections in reading order. */
export function SecurityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<SecurityHeroSlide embedded={embedded} />}
    >
      <IdentityAccountProtectionSlide1 embedded={embedded} />
      <AuthorizationBoundariesSlide2 embedded={embedded} />
      <RateLimitingAbusePreventionSlide3 embedded={embedded} />
      <DataFilesSecretsSlide4 embedded={embedded} />
      <IntegrationsApisWebhooksSlide5 embedded={embedded} />
      <AiToolUseSafetySlide6 embedded={embedded} />
      <CommercialPaymentBoundariesSlide7 embedded={embedded} />
      <MonitoringIncidentResponseResilienceSlide8 embedded={embedded} />
      <EvidenceSlide9 embedded={embedded} />
      <SecurityEvaluationSlide10 embedded={embedded} />
    </DocumentPageLayout>
  );
}
