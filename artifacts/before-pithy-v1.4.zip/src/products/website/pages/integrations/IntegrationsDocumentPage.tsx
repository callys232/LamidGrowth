import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ConnectCrmAndFinanceContextSlide3,
  ControlTheConnectionSlide2,
  IntegrationCategoriesSlide1,
  IntegrationsHeroSlide,
  ReduceFragmentationWithoutCreatingANewSiloSlide4,
} from './slides';

/** /integrations — sections in reading order. */
export function IntegrationsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<IntegrationsHeroSlide embedded={embedded} />}
    >
      <IntegrationCategoriesSlide1 embedded={embedded} />
      <ControlTheConnectionSlide2 embedded={embedded} />
      <ConnectCrmAndFinanceContextSlide3 embedded={embedded} />
      <ReduceFragmentationWithoutCreatingANewSiloSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
