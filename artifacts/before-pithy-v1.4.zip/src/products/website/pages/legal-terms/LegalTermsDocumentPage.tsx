import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AcceptableUseAndThirdPartyServicesSlide6,
  AiAssistedOutputsSlide5,
  EligibilityAndAccountsSlide1,
  LegalTermsHeroSlide,
  PlansAndPaymentSlide3,
  ServiceScopeSlide2,
  SuspensionLiabilityDisputesAndChangesSlide7,
  UserContentAndDataSlide4,
} from './slides';

/** /legal/terms — sections in reading order. */
export function LegalTermsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<LegalTermsHeroSlide embedded={embedded} />}
    >
      <EligibilityAndAccountsSlide1 embedded={embedded} />
      <ServiceScopeSlide2 embedded={embedded} />
      <PlansAndPaymentSlide3 embedded={embedded} />
      <UserContentAndDataSlide4 embedded={embedded} />
      <AiAssistedOutputsSlide5 embedded={embedded} />
      <AcceptableUseAndThirdPartyServicesSlide6 embedded={embedded} />
      <SuspensionLiabilityDisputesAndChangesSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
