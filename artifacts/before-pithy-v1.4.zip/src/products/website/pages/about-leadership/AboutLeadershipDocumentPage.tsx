import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AboutLeadershipHeroSlide,
  AdvisorsAndContributorsSlide4,
  BuiltToScaleWithTheCompanySlide5,
  ExperienceWithContextSlide3,
  FounderLedTodaySlide1,
  ResponsibilityBeforeTitleSlide2,
} from './slides';

/** /about/leadership — sections in reading order. */
export function AboutLeadershipDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<AboutLeadershipHeroSlide embedded={embedded} />}
    >
      <FounderLedTodaySlide1 embedded={embedded} />
      <ResponsibilityBeforeTitleSlide2 embedded={embedded} />
      <ExperienceWithContextSlide3 embedded={embedded} />
      <AdvisorsAndContributorsSlide4 embedded={embedded} />
      <BuiltToScaleWithTheCompanySlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
