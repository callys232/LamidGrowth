import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BusinessClaritySlide1,
  ExecutionSlide5,
  FinancialContextSlide2,
  OneFounderManyContextsOneOperatingSystemSlide7,
  OpportunitySlide3,
  PrepareForAFundingDecisionSlide6,
  TeamCapabilitySlide4,
  WhoItsForFoundersHeroSlide,
} from './slides';

/** /who-its-for/founders — sections in reading order. */
export function WhoItsForFoundersDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForFoundersHeroSlide embedded={embedded} />}
    >
      <BusinessClaritySlide1 embedded={embedded} />
      <FinancialContextSlide2 embedded={embedded} />
      <OpportunitySlide3 embedded={embedded} />
      <TeamCapabilitySlide4 embedded={embedded} />
      <ExecutionSlide5 embedded={embedded} />
      <PrepareForAFundingDecisionSlide6 embedded={embedded} />
      <OneFounderManyContextsOneOperatingSystemSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
