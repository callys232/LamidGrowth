import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CompleteYourFirstDecisionCycleSlide5,
  HelpGettingStartedHeroSlide,
  Step1ChooseYourContextSlide1,
  Step2SetAnObjectiveSlide2,
  Step3UseTheCoreOperatingCycleSlide3,
  Step4ReviewProgressSlide4,
} from './slides';

/** /help/getting-started — sections in reading order. */
export function HelpGettingStartedDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HelpGettingStartedHeroSlide embedded={embedded} />}
    >
      <Step1ChooseYourContextSlide1 embedded={embedded} />
      <Step2SetAnObjectiveSlide2 embedded={embedded} />
      <Step3UseTheCoreOperatingCycleSlide3 embedded={embedded} />
      <Step4ReviewProgressSlide4 embedded={embedded} />
      <CompleteYourFirstDecisionCycleSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
