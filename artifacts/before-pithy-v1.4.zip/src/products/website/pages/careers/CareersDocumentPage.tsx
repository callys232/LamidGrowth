import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BuildTechnologyPeopleCanUseWithConfidenceSlide4,
  CareersHeroSlide,
  HowWeWorkSlide1,
  WhatWeBuildSlide2,
  WhatWeValueSlide3,
} from './slides';

/** /careers — sections in reading order. */
export function CareersDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<CareersHeroSlide embedded={embedded} />}
    >
      <HowWeWorkSlide1 embedded={embedded} />
      <WhatWeBuildSlide2 embedded={embedded} />
      <WhatWeValueSlide3 embedded={embedded} />
      <BuildTechnologyPeopleCanUseWithConfidenceSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
