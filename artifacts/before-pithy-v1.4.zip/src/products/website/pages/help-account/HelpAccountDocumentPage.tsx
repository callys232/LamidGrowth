import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AccountSlide1,
  HelpAccountHeroSlide,
  PlansBillingSlide3,
  ResolveAnAccessIssueSlide4,
  WorkspacesSlide2,
} from './slides';

/** /help/account — sections in reading order. */
export function HelpAccountDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HelpAccountHeroSlide embedded={embedded} />}
    >
      <AccountSlide1 embedded={embedded} />
      <WorkspacesSlide2 embedded={embedded} />
      <PlansBillingSlide3 embedded={embedded} />
      <ResolveAnAccessIssueSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
