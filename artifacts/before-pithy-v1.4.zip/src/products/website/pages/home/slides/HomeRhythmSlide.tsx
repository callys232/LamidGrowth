import { HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeRhythmSlide() {
  return (
    <HomeSection section={6} label="PROGRESS, WITH INTENTION" className="home-rhythm-section">
      <HomeFeatureList section={6} to={6} className="home-rhythm-timeline" />
    </HomeSection>
  );
}
