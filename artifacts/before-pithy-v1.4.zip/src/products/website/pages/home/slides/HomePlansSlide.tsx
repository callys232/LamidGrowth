import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomePlansSlide() {
  return (
    <HomeSection section={10} label="YOUR STARTING POINT" className="home-plans-section">
      <HomeFeatureList section={10} to={7} className="home-plan-list" />
      <div className="home-section-end">
        <HomeCopy section={10} from={7} />
      </div>
    </HomeSection>
  );
}
