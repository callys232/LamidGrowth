import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeExperienceSlide() {
  return (
    <HomeSection
      section={3}
      label="AN EXPERIENCE THAT GROWS WITH YOU"
      className="home-experience-section"
    >
      <HomeFeatureList section={3} to={6} className="home-depth-list" />
      <div className="home-section-end">
        <HomeCopy section={3} from={6} />
      </div>
    </HomeSection>
  );
}
