import { ShieldCheck } from 'lucide-react';
import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeGovernanceSlide() {
  return (
    <HomeSection section={7} label="04 / HUMAN CONTROL" className="home-governance-section">
      <div className="home-governance-emblem" aria-hidden="true">
        <ShieldCheck size={52} strokeWidth={1} />
      </div>
      <HomeFeatureList section={7} to={6} className="home-governance-list" />
      <div className="home-governance-summary">
        <HomeCopy section={7} from={6} />
      </div>
    </HomeSection>
  );
}
