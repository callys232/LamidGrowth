import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';

export function HomeOperatingCycleSlide() {
  return (
    <HomeSection section={0} label="01 / THE OPERATING CYCLE" className="home-cycle-section">
      <HomeFeatureList section={0} to={6} className="home-cycle-cards" />
      <div className="home-cycle-summary">
        <HomeCopy section={0} from={6} />
      </div>
    </HomeSection>
  );
}
