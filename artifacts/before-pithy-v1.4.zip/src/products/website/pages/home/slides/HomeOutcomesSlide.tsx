import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeOutcomesSlide() {
  return (
    <HomeSection section={4} label="THE WORK THAT MATTERS" className="home-outcomes-section">
      <HomeFeatureList section={4} to={6} className="home-outcome-grid" />
      <div className="home-section-end">
        <HomeCopy section={4} from={6} />
      </div>
    </HomeSection>
  );
}
