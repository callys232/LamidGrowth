import { HomeCopy, HomeSection } from '../components/HomeSection';
export function HomeExpansionSlide() {
  return (
    <HomeSection section={8} label="ONE SYSTEM. ROOM TO GROW." className="home-expansion-section">
      <div className="home-expansion-copy">
        <HomeCopy section={8} from={2} />
      </div>
    </HomeSection>
  );
}
