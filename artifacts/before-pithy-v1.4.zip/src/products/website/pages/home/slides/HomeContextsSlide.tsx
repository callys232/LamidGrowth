import { HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeContextsSlide() {
  return (
    <HomeSection
      section={2}
      label="03 / BUILT AROUND YOUR CONTEXT"
      className="home-contexts-section"
    >
      <HomeFeatureList section={2} to={10} className="home-context-grid" />
    </HomeSection>
  );
}
