import { HomeCopy, HomeSection } from '../components/HomeSection';
export function HomeSimplicitySlide() {
  return (
    <HomeSection section={9} label="LESS FRAGMENTATION" className="home-simplicity-section">
      <div className="home-simplicity-copy">
        <HomeCopy section={9} from={2} />
      </div>
    </HomeSection>
  );
}
