import { Sparkles, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';

export function HomeCompanionSlide() {
  return (
    <HomeSection section={1} label="02 / YOUR THINKING PARTNER" className="home-companion-section">
      <div className="home-split-layout">
        <div className="home-companion-illustration">
          <span className="home-eyebrow">
            <Sparkles size={17} /> LAMID ONE COMPANION
          </span>
          <p className="home-example-label">An example starting point</p>
          <div className="home-example-message">
            I have an idea.
            <br />
            Help me find a clear direction.
          </div>
          <div className="home-example-answer">
            <Sparkles size={20} />
            <div>
              <strong>Start with what matters.</strong>
              <p>What would a meaningful outcome look like?</p>
            </div>
          </div>
          <Link to="/start">
            Find your starting point <ArrowUpRight size={17} />
          </Link>
        </div>
        <div className="home-companion-copy">
          <HomeCopy section={1} from={2} to={3} />
          <HomeFeatureList section={1} from={3} to={7} />
          <HomeCopy section={1} from={8} />
        </div>
      </div>
      <details className="home-detail">
        <summary>How context carries forward</summary>
        <HomeCopy section={1} from={7} to={8} />
      </details>
    </HomeSection>
  );
}
