import { ArrowDown, ShieldCheck } from 'lucide-react';
import { CopyLine } from '../../../../../shared/content/CopyLine';
import { WorkspacePreview } from '../components/WorkspacePreview';
import content from '../content.json';

export function HomeHeroSlide() {
  const [title, description, promise, actions, continuity, control] = content.hero.paragraphs;
  const emphasis = title.text.indexOf('Growth');
  return (
    <>
      <section className="home-premium-hero">
        <div className="home-container">
          <span className="home-eyebrow">
            <span className="home-red-dot" /> HUMAN JUDGMENT. CONNECTED CAPABILITY.
          </span>
          <h1 data-source-paragraph={title.sourceParagraph}>
            {emphasis >= 0 ? (
              <>
                {title.text.slice(0, emphasis)}
                <br />
                <em>{title.text.slice(emphasis)}</em>
              </>
            ) : (
              title.text
            )}
          </h1>
          <p className="home-hero-description" data-source-paragraph={description.sourceParagraph}>
            {description.text}
          </p>
          <CopyLine text={actions.text} paragraph={actions.sourceParagraph} />
          <p className="home-hero-assurance">
            <ShieldCheck size={15} />
            <span data-source-paragraph={control.sourceParagraph}>{control.text}</span>
          </p>
          <div className="home-product-introduction">
            <p data-source-paragraph={promise.sourceParagraph}>{promise.text}</p>
            <span aria-hidden="true">
              <ArrowDown size={17} /> A look inside
            </span>
          </div>
          <WorkspacePreview />
        </div>
      </section>
      <div className="home-continuity home-container">
        <span className="home-eyebrow">A CONTINUOUS THREAD</span>
        <p data-source-paragraph={continuity.sourceParagraph}>{continuity.text}</p>
      </div>
      <nav className="home-section-nav" aria-label="Explore this page">
        <div className="home-container">
          <span>Discover LAMID ONE</span>
          <a href="#section-170">How it works</a>
          <a href="#section-179">Your Companion</a>
          <a href="#section-189">Your context</a>
          <a href="#section-234">Human control</a>
        </div>
      </nav>
    </>
  );
}
