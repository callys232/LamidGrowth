import { OrbitVisual } from '../../../../../shared/visuals/Orbit';
import { HomeCopy, HomeFeatureList, HomeSection } from '../components/HomeSection';
export function HomeIntelligenceSlide() {
  return (
    <HomeSection section={5} label="CONNECTED INTELLIGENCE" className="home-intelligence-section">
      <div className="home-split-layout">
        <div className="home-intelligence-visual">
          <OrbitVisual small />
        </div>
        <HomeFeatureList section={5} to={8} className="home-intelligence-list" />
      </div>
      <div className="home-section-end">
        <HomeCopy section={5} from={8} />
      </div>
    </HomeSection>
  );
}
