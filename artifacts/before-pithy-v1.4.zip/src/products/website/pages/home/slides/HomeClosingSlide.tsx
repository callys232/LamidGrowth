import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { HomeCopy, HomeSection } from '../components/HomeSection';
export function HomeClosingSlide() {
  return (
    <HomeSection
      section={11}
      label="YOUR NEXT CHAPTER STARTS HERE"
      className="home-closing-section"
    >
      <HomeCopy section={11} from={2} to={4} />
      <Link className="home-enterprise-link" to="/demo/request">
        <span data-source-paragraph={271}>
          Evaluating LAMID ONE for an organization? Request an Organizational Demo.
        </span>
        <ArrowUpRight size={17} />
      </Link>
    </HomeSection>
  );
}
