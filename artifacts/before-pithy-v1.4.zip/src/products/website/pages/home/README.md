# Homepage

Route: `/`. Start with [HomeDocumentPage.tsx](./HomeDocumentPage.tsx) to see the sections in reading order.

| Edit                                                                | File or folder                                                |
| ------------------------------------------------------------------- | ------------------------------------------------------------- |
| Source wording and metadata                                         | [content.json](./content.json)                                |
| Section order                                                       | [HomeDocumentPage.tsx](./HomeDocumentPage.tsx)                |
| Hero and its primary actions                                        | [HomeHeroSlide.tsx](./slides/HomeHeroSlide.tsx)               |
| Interactive example and keyboard tabs                               | [WorkspacePreview.tsx](./components/WorkspacePreview.tsx)     |
| Operating cycle, Companion, contexts, governance and other sections | [slides](./slides)                                            |
| Common section heading and feature-list layout                      | [HomeSection.tsx](./components/HomeSection.tsx)               |
| Footer links and source markers                                     | [HomeFooter.tsx](./components/HomeFooter.tsx)                 |
| Homepage spacing, typography, colors and responsive rules           | [home.css](./home.css)                                        |
| Design rationale and reference review                               | [Homepage UI study](../../../../../docs/HOMEPAGE_UI_STUDY.md) |

The homepage uses individual files in `slides/`; simpler document pages use a single `slides.tsx` file of named sections. The `embedded` rendering remains available through the shared document components.

The preview is explicitly illustrative. Its tabs change the displayed example without making API calls. “Explore the workspace” creates a real isolated sample through the existing demo endpoint. Source-copy paragraphs retain their original markers; the longer Companion continuity explanation is available in a disclosure. Navigation and footer links use existing routes.

The earlier unrouted marketing design is preserved in the pre-refactor source backup under `artifacts/`. It is not the active homepage.
