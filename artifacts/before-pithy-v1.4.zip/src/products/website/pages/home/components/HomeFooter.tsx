import { Link } from 'react-router-dom';
import { Brand } from '../../../../../shared/ui/Brand';
import content from '../content.json';

const routes = [
  ['/product', '/how-it-works', '/product/companion', '/demo', '/pricing'],
  [
    '/who-its-for/individuals',
    '/who-its-for/professionals',
    '/who-its-for/creators',
    '/who-its-for/founders',
    '/who-its-for/teams',
    '/who-its-for/smes',
    '/who-its-for/enterprises',
    '/who-its-for/institutions',
  ],
  ['/insights', '/guides', '/case-studies', '/research', '/help', '/developers'],
  ['/about', '/about/story', '/about/leadership', '/responsible-ai', '/careers', '/contact'],
  [
    '/security',
    '/trust/privacy',
    '/trust/governance',
    '/legal/privacy',
    '/legal/terms',
    '/accessibility',
  ],
];
export function HomeFooter() {
  const paragraphs = content.sections[11].paragraphs;
  return (
    <footer className="home-footer">
      <div className="home-container">
        <span className="sr-only" data-source-paragraph={272}>
          GLOBAL FOOTER
        </span>
        <div className="home-footer-brand">
          <Brand />
          <p data-source-paragraph={273}>
            {paragraphs.find((p) => p.sourceParagraph === 273)?.text}
          </p>
          <p data-source-paragraph={274}>
            {paragraphs.find((p) => p.sourceParagraph === 274)?.text}
          </p>
        </div>
        <div className="home-footer-columns">
          {paragraphs
            .filter((p) => p.sourceParagraph >= 275)
            .map((p, index) => {
              const [group, ...rest] = p.text.split(': ');
              const links = rest.join(': ').split(' | ');
              return (
                <div key={p.sourceParagraph} data-source-paragraph={p.sourceParagraph}>
                  <h3>{group}:</h3>{' '}
                  {links.map((label, i) => (
                    <span key={label}>
                      {i > 0 && <span className="sr-only">{' | '}</span>}
                      <Link to={routes[index][i]}>{label}</Link>
                    </span>
                  ))}
                </div>
              );
            })}
        </div>
        <div className="home-footer-bottom">
          <span>© {new Date().getFullYear()} LAMID ONE</span>
          <span>Progress, with intention.</span>
          <a href="#top">Back to top ↑</a>
        </div>
      </div>
    </footer>
  );
}
