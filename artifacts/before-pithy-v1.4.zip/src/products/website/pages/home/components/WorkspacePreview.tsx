import {
  ArrowRight,
  Check,
  Compass,
  Layers3,
  ListChecks,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useRef, useState, type KeyboardEvent } from 'react';
import { DemoAccessSlide } from '../../../slides/DemoAccessSlide';

const previews = [
  {
    name: 'Clarity',
    icon: Compass,
    label: 'DEFINE THE OUTCOME',
    title: 'Make the next chapter a clear one.',
    description: 'Bring the objective, the context, and what success looks like into one view.',
    rows: [
      'Launch the next chapter of my work',
      'Understand the constraints',
      'Define a meaningful outcome',
    ],
    status: 'Objective defined',
  },
  {
    name: 'Capability',
    icon: Layers3,
    label: 'PREPARE THE NEXT STEP',
    title: 'See what the work requires.',
    description: 'Keep useful knowledge and capability requirements connected to the objective.',
    rows: [
      'Review the source notes',
      'Identify the knowledge gap',
      'Prepare a practical next action',
    ],
    status: 'Context connected',
  },
  {
    name: 'Consistency',
    icon: ListChecks,
    label: 'MOVE WITH INTENTION',
    title: 'Turn the decision into progress.',
    description:
      'Keep the next action visible, review the outcome, and carry the learning forward.',
    rows: ['Prepare the first action', 'Review before completion', 'Record what changed'],
    status: 'Ready for review',
  },
];

/** An interactive illustration, not a live account or a simulated completed workflow. */
export function WorkspacePreview() {
  const [selected, setSelected] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const preview = previews[selected];
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === 'ArrowRight') next = (index + 1) % previews.length;
    else if (event.key === 'ArrowLeft') next = (index + previews.length - 1) % previews.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = previews.length - 1;
    else return;
    event.preventDefault();
    setSelected(next);
    tabs.current[next]?.focus();
  }
  return (
    <div className="home-workspace-preview" aria-label="Interactive workspace example">
      <div className="home-preview-topbar">
        <span>
          <span className="home-preview-mark" aria-hidden="true">
            ◐
          </span>{' '}
          LAMID ONE <span className="home-preview-caption">/ Workspace example</span>
        </span>
        <span className="home-preview-label">Illustrative content</span>
      </div>
      <div className="home-preview-body">
        <div className="home-preview-sidebar">
          <span className="home-eyebrow">YOUR OPERATING CYCLE</span>
          <div role="tablist" aria-label="Explore the operating cycle">
            {previews.map((item, index) => (
              <button
                key={item.name}
                ref={(node) => {
                  tabs.current[index] = node;
                }}
                type="button"
                role="tab"
                id={`preview-tab-${index}`}
                aria-selected={selected === index}
                aria-controls="workspace-preview-panel"
                tabIndex={selected === index ? 0 : -1}
                onClick={() => setSelected(index)}
                onKeyDown={(event) => navigate(event, index)}
              >
                <item.icon size={17} />
                {item.name}
                <ArrowRight size={14} />
              </button>
            ))}
          </div>
          <div className="home-preview-sidebar-note">
            <ShieldCheck size={20} />
            <p>
              Your judgment.
              <br />
              At every important step.
            </p>
          </div>
        </div>
        <div
          className="home-preview-panel"
          role="tabpanel"
          tabIndex={0}
          id="workspace-preview-panel"
          aria-labelledby={`preview-tab-${selected}`}
        >
          <div className="home-preview-panel-heading">
            <span className="home-eyebrow">{preview.label}</span>
            <span className="home-preview-status">
              <span />
              {preview.status}
            </span>
          </div>
          <h3>{preview.title}</h3>
          <p>{preview.description}</p>
          <div className="home-preview-tasks">
            {preview.rows.map((row, index) => (
              <div key={row}>
                <span className={`home-preview-check ${index === 0 ? 'is-complete' : ''}`}>
                  {index === 0 && <Check size={12} />}
                </span>
                <span>{row}</span>
                <span className="home-preview-task-kind">
                  {index === 0 ? 'Context' : index === 1 ? 'Consider' : 'Next step'}
                </span>
              </div>
            ))}
          </div>
          <div className="home-preview-companion">
            <Sparkles size={17} />
            <p>Bring your context. Choose your next move.</p>
          </div>
        </div>
      </div>
      <div className="home-preview-bottom">
        <span>Start with a sample workspace. Make it real when you’re ready.</span>
        <DemoAccessSlide />
      </div>
    </div>
  );
}
