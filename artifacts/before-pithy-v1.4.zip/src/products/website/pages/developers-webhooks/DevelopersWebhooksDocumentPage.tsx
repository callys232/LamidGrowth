import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BuildForReliableTraceableDeliverySlide4,
  DeliverySlide2,
  DevelopersWebhooksHeroSlide,
  EventModelSlide1,
  NotifyAnExternalSystemAfterApprovalSlide3,
} from './slides';

/** /developers/webhooks — sections in reading order. */
export function DevelopersWebhooksDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<DevelopersWebhooksHeroSlide embedded={embedded} />}
    >
      <EventModelSlide1 embedded={embedded} />
      <DeliverySlide2 embedded={embedded} />
      <NotifyAnExternalSystemAfterApprovalSlide3 embedded={embedded} />
      <BuildForReliableTraceableDeliverySlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
