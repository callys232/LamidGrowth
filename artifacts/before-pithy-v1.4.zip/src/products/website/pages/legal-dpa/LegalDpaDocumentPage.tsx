import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AuditAndProcessingDetailsSlide6,
  ConfidentialityAndSecuritySlide2,
  LegalDpaHeroSlide,
  RightsAndIncidentAssistanceSlide4,
  RolesAndInstructionsSlide1,
  SubprocessorsSlide3,
  TransfersReturnAndDeletionSlide5,
} from './slides';

/** /legal/dpa — sections in reading order. */
export function LegalDpaDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<LegalDpaHeroSlide embedded={embedded} />}
    >
      <RolesAndInstructionsSlide1 embedded={embedded} />
      <ConfidentialityAndSecuritySlide2 embedded={embedded} />
      <SubprocessorsSlide3 embedded={embedded} />
      <RightsAndIncidentAssistanceSlide4 embedded={embedded} />
      <TransfersReturnAndDeletionSlide5 embedded={embedded} />
      <AuditAndProcessingDetailsSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
