import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ContinuitySlide3,
  GovernanceSlide4,
  InstitutionalClaritySlide1,
  ResponsibleAiSlide5,
  StrengthenAMultiYearTransformationSlide6,
  TechnologyShouldStrengthenTheInstitutionNotBlurItsResponsibilitySlide7,
  WhoItsForInstitutionsHeroSlide,
  WorkforceCapabilitySlide2,
} from './slides';

/** /who-its-for/institutions — sections in reading order. */
export function WhoItsForInstitutionsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForInstitutionsHeroSlide embedded={embedded} />}
    >
      <InstitutionalClaritySlide1 embedded={embedded} />
      <WorkforceCapabilitySlide2 embedded={embedded} />
      <ContinuitySlide3 embedded={embedded} />
      <GovernanceSlide4 embedded={embedded} />
      <ResponsibleAiSlide5 embedded={embedded} />
      <StrengthenAMultiYearTransformationSlide6 embedded={embedded} />
      <TechnologyShouldStrengthenTheInstitutionNotBlurItsResponsibilitySlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
