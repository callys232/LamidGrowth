import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CaseStudiesSlide3,
  DevelopersSlide6,
  GuidesSlide2,
  HelpSlide5,
  ImproveDecisionQualitySlide7,
  InsightsSlide1,
  ResearchSlide4,
  ResourcesHeroSlide,
} from './slides';

/** /resources — sections in reading order. */
export function ResourcesDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ResourcesHeroSlide embedded={embedded} />}
    >
      <InsightsSlide1 embedded={embedded} />
      <GuidesSlide2 embedded={embedded} />
      <CaseStudiesSlide3 embedded={embedded} />
      <ResearchSlide4 embedded={embedded} />
      <HelpSlide5 embedded={embedded} />
      <DevelopersSlide6 embedded={embedded} />
      <ImproveDecisionQualitySlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
