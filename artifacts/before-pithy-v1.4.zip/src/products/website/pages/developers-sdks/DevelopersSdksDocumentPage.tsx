import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  DevelopersSdksHeroSlide,
  ListenForWorkflowCompletionSlide2,
  SdkAreasSlide1,
  SupportedVersionsSlide4,
  VersioningSlide3,
} from './slides';

/** /developers/sdks — sections in reading order. */
export function DevelopersSdksDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<DevelopersSdksHeroSlide embedded={embedded} />}
    >
      <SdkAreasSlide1 embedded={embedded} />
      <ListenForWorkflowCompletionSlide2 embedded={embedded} />
      <VersioningSlide3 embedded={embedded} />
      <SupportedVersionsSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
