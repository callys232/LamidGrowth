import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  HowInformationIsUsedSlide2,
  InformationWeCollectSlide1,
  InternationalTransfersAndRetentionSlide4,
  LegalPrivacyHeroSlide,
  SecurityChangesAndContactSlide6,
  SourcesAndSharingSlide3,
  YourRightsAndChoicesSlide5,
} from './slides';

/** /legal/privacy — sections in reading order. */
export function LegalPrivacyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<LegalPrivacyHeroSlide embedded={embedded} />}
    >
      <InformationWeCollectSlide1 embedded={embedded} />
      <HowInformationIsUsedSlide2 embedded={embedded} />
      <SourcesAndSharingSlide3 embedded={embedded} />
      <InternationalTransfersAndRetentionSlide4 embedded={embedded} />
      <YourRightsAndChoicesSlide5 embedded={embedded} />
      <SecurityChangesAndContactSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
