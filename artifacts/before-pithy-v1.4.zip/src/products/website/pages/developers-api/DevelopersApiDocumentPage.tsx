import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ApiPrinciplesSlide1,
  AuthorizationIsPartOfTheApiContractSlide3,
  CoreDomainsSlide2,
  DevelopersApiHeroSlide,
  StartWithTheContractSlide4,
} from './slides';

/** /developers/api — sections in reading order. */
export function DevelopersApiDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<DevelopersApiHeroSlide embedded={embedded} />}
    >
      <ApiPrinciplesSlide1 embedded={embedded} />
      <CoreDomainsSlide2 embedded={embedded} />
      <AuthorizationIsPartOfTheApiContractSlide3 embedded={embedded} />
      <StartWithTheContractSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
