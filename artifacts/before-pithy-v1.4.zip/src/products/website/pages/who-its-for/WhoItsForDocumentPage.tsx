import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CreatorSlide3,
  EnterprisesSlide7,
  FounderSlide4,
  IndividualSlide1,
  InstitutionSlide8,
  OneMasterPropositionSlide9,
  ProfessionalSlide2,
  SmeSlide6,
  TeamSlide5,
  WhoItsForHeroSlide,
} from './slides';

/** /who-its-for — sections in reading order. */
export function WhoItsForDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForHeroSlide embedded={embedded} />}
    >
      <IndividualSlide1 embedded={embedded} />
      <ProfessionalSlide2 embedded={embedded} />
      <CreatorSlide3 embedded={embedded} />
      <FounderSlide4 embedded={embedded} />
      <TeamSlide5 embedded={embedded} />
      <SmeSlide6 embedded={embedded} />
      <EnterprisesSlide7 embedded={embedded} />
      <InstitutionSlide8 embedded={embedded} />
      <OneMasterPropositionSlide9 embedded={embedded} />
    </DocumentPageLayout>
  );
}
