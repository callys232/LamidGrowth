import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BusinessSlide4,
  EnterpriseInstitutionSlide5,
  ExpandTheOsNotACollectionOfSeparateProductsSlide7,
  GrowWithoutReplatformingSlide6,
  PersonalSlide1,
  PricingHeroSlide,
  ProfessionalSlide2,
  TeamSlide3,
} from './slides';

/** /pricing — sections in reading order. */
export function PricingDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<PricingHeroSlide embedded={embedded} />}
    >
      <PersonalSlide1 embedded={embedded} />
      <ProfessionalSlide2 embedded={embedded} />
      <TeamSlide3 embedded={embedded} />
      <BusinessSlide4 embedded={embedded} />
      <EnterpriseInstitutionSlide5 embedded={embedded} />
      <GrowWithoutReplatformingSlide6 embedded={embedded} />
      <ExpandTheOsNotACollectionOfSeparateProductsSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
