import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CoordinateAnEnterpriseTransformationSlide6,
  EnterpriseDepthWithoutEnterpriseClutterSlide7,
  GovernGrowthWithoutSlowingTheWorkSlide4,
  MultiTeamExecutionSlide2,
  OrganizationalCapabilitySlide3,
  SharedOrganizationalContextSlide1,
  WhoItsForEnterprisesHeroSlide,
  WorkAcrossTheSystemsYouAlreadyUseSlide5,
} from './slides';

/** /who-its-for/enterprises — sections in reading order. */
export function WhoItsForEnterprisesDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForEnterprisesHeroSlide embedded={embedded} />}
    >
      <SharedOrganizationalContextSlide1 embedded={embedded} />
      <MultiTeamExecutionSlide2 embedded={embedded} />
      <OrganizationalCapabilitySlide3 embedded={embedded} />
      <GovernGrowthWithoutSlowingTheWorkSlide4 embedded={embedded} />
      <WorkAcrossTheSystemsYouAlreadyUseSlide5 embedded={embedded} />
      <CoordinateAnEnterpriseTransformationSlide6 embedded={embedded} />
      <EnterpriseDepthWithoutEnterpriseClutterSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
