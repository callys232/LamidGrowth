import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ApisSlide1,
  AuthenticationPermissionsSlide4,
  DevelopersHeroSlide,
  EventsWebhooksSlide3,
  ExtendThePlatformWithoutExtendingAuthoritySlide6,
  PartnerAndIndustryExtensionsSlide5,
  SdksSlide2,
} from './slides';

/** /developers — sections in reading order. */
export function DevelopersDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<DevelopersHeroSlide embedded={embedded} />}
    >
      <ApisSlide1 embedded={embedded} />
      <SdksSlide2 embedded={embedded} />
      <EventsWebhooksSlide3 embedded={embedded} />
      <AuthenticationPermissionsSlide4 embedded={embedded} />
      <PartnerAndIndustryExtensionsSlide5 embedded={embedded} />
      <ExtendThePlatformWithoutExtendingAuthoritySlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
