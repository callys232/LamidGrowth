import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ChooseAContextSlide1,
  DemoHeroSlide,
  GoDeeperSlide4,
  MeetTheCompanionSlide3,
  OneDemoDifferentRelevantDepthSlide6,
  PlanATeamExpansionSlide5,
  SeeTheCoreOperatingCycleSlide2,
} from './slides';

/** /demo — sections in reading order. */
export function DemoDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<DemoHeroSlide embedded={embedded} />}
    >
      <ChooseAContextSlide1 embedded={embedded} />
      <SeeTheCoreOperatingCycleSlide2 embedded={embedded} />
      <MeetTheCompanionSlide3 embedded={embedded} />
      <GoDeeperSlide4 embedded={embedded} />
      <PlanATeamExpansionSlide5 embedded={embedded} />
      <OneDemoDifferentRelevantDepthSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
