import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AccessibilityHeroSlide,
  AccessibilityStatusSlide4,
  KeyboardAndAssistiveTechnologySlide1,
  MotionAndInteractionSlide3,
  ReportAnAccessibilityIssueSlide5,
  VisualAccessibilitySlide2,
} from './slides';

/** /accessibility — sections in reading order. */
export function AccessibilityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<AccessibilityHeroSlide embedded={embedded} />}
    >
      <KeyboardAndAssistiveTechnologySlide1 embedded={embedded} />
      <VisualAccessibilitySlide2 embedded={embedded} />
      <MotionAndInteractionSlide3 embedded={embedded} />
      <AccessibilityStatusSlide4 embedded={embedded} />
      <ReportAnAccessibilityIssueSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
