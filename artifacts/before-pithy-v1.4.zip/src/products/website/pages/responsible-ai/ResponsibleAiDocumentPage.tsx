import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiSafetyIncludesTheSystemsAroundTheModelSlide10,
  ContextPrivacySlide4,
  EvaluationSlide6,
  ExplainabilitySlide2,
  HumanAgencySlide1,
  HumanOverrideSlide8,
  MemoryContinuityControlSlide5,
  NoPermissionExpandsItselfSlide7,
  ProgressionDoesNotEqualUnlimitedAuthoritySlide9,
  ResponsibleAiHeroSlide,
  UncertaintySlide3,
} from './slides';

/** /responsible-ai — sections in reading order. */
export function ResponsibleAiDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ResponsibleAiHeroSlide embedded={embedded} />}
    >
      <HumanAgencySlide1 embedded={embedded} />
      <ExplainabilitySlide2 embedded={embedded} />
      <UncertaintySlide3 embedded={embedded} />
      <ContextPrivacySlide4 embedded={embedded} />
      <MemoryContinuityControlSlide5 embedded={embedded} />
      <EvaluationSlide6 embedded={embedded} />
      <NoPermissionExpandsItselfSlide7 embedded={embedded} />
      <HumanOverrideSlide8 embedded={embedded} />
      <ProgressionDoesNotEqualUnlimitedAuthoritySlide9 embedded={embedded} />
      <AiSafetyIncludesTheSystemsAroundTheModelSlide10 embedded={embedded} />
    </DocumentPageLayout>
  );
}
