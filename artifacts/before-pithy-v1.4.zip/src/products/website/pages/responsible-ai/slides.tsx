import { DocumentHeroSlide } from '../../../../shared/content/slides/DocumentHeroSlide';
import { DocumentSectionSlide } from '../../../../shared/content/slides/DocumentSectionSlide';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';

export function ResponsibleAiHeroSlide({ embedded = false }: DocumentPageProps) {
  return <DocumentHeroSlide page={content} embedded={embedded} />;
}

/** Human Agency */
export function HumanAgencySlide1({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[0]}
      index={0}
      last={false}
      embedded={embedded}
    />
  );
}

/** Explainability */
export function ExplainabilitySlide2({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[1]}
      index={1}
      last={false}
      embedded={embedded}
    />
  );
}

/** Uncertainty */
export function UncertaintySlide3({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[2]}
      index={2}
      last={false}
      embedded={embedded}
    />
  );
}

/** Context & Privacy */
export function ContextPrivacySlide4({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[3]}
      index={3}
      last={false}
      embedded={embedded}
    />
  );
}

/** Memory & Continuity Control */
export function MemoryContinuityControlSlide5({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[4]}
      index={4}
      last={false}
      embedded={embedded}
    />
  );
}

/** Evaluation */
export function EvaluationSlide6({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[5]}
      index={5}
      last={false}
      embedded={embedded}
    />
  );
}

/** No Permission Expands Itself */
export function NoPermissionExpandsItselfSlide7({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[6]}
      index={6}
      last={false}
      embedded={embedded}
    />
  );
}

/** Human Override */
export function HumanOverrideSlide8({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[7]}
      index={7}
      last={false}
      embedded={embedded}
    />
  );
}

/** Progression Does Not Equal Unlimited Authority */
export function ProgressionDoesNotEqualUnlimitedAuthoritySlide9({
  embedded = false,
}: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[8]}
      index={8}
      last={false}
      embedded={embedded}
    />
  );
}

/** AI Safety Includes the Systems Around the Model */
export function AiSafetyIncludesTheSystemsAroundTheModelSlide10({
  embedded = false,
}: DocumentPageProps) {
  return (
    <DocumentSectionSlide section={content.sections[9]} index={9} last={true} embedded={embedded} />
  );
}
