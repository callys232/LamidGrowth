import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AlignmentBecomesVisibleInTheWorkSlide6,
  CapabilitySlide2,
  ImproveCrossTeamDeliverySlide5,
  RhythmSlide4,
  SharedPrioritiesSlide1,
  WhoItsForTeamsHeroSlide,
  WorkflowsSlide3,
} from './slides';

/** /who-its-for/teams — sections in reading order. */
export function WhoItsForTeamsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForTeamsHeroSlide embedded={embedded} />}
    >
      <SharedPrioritiesSlide1 embedded={embedded} />
      <CapabilitySlide2 embedded={embedded} />
      <WorkflowsSlide3 embedded={embedded} />
      <RhythmSlide4 embedded={embedded} />
      <ImproveCrossTeamDeliverySlide5 embedded={embedded} />
      <AlignmentBecomesVisibleInTheWorkSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
