import { DocumentHeroSlide } from '../../../../shared/content/slides/DocumentHeroSlide';
import { DocumentSectionSlide } from '../../../../shared/content/slides/DocumentSectionSlide';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';

export function AboutStoryHeroSlide({ embedded = false }: DocumentPageProps) {
  return <DocumentHeroSlide page={content} embedded={embedded} />;
}

/** The Observation */
export function TheObservationSlide1({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[0]}
      index={0}
      last={false}
      embedded={embedded}
    />
  );
}

/** What Experience Revealed */
export function WhatExperienceRevealedSlide2({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[1]}
      index={1}
      last={false}
      embedded={embedded}
    />
  );
}

/** The Design Response */
export function TheDesignResponseSlide3({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[2]}
      index={2}
      last={false}
      embedded={embedded}
    />
  );
}

/** The Result */
export function TheResultSlide4({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[3]}
      index={3}
      last={false}
      embedded={embedded}
    />
  );
}

/** Human and Intelligent - Working as One. */
export function HumanAndIntelligentWorkingAsOneSlide5({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide section={content.sections[4]} index={4} last={true} embedded={embedded} />
  );
}
