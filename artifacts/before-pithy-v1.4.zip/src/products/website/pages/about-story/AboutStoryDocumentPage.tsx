import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AboutStoryHeroSlide,
  HumanAndIntelligentWorkingAsOneSlide5,
  TheDesignResponseSlide3,
  TheObservationSlide1,
  TheResultSlide4,
  WhatExperienceRevealedSlide2,
} from './slides';

/** /about/story — sections in reading order. */
export function AboutStoryDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<AboutStoryHeroSlide embedded={embedded} />}
    >
      <TheObservationSlide1 embedded={embedded} />
      <WhatExperienceRevealedSlide2 embedded={embedded} />
      <TheDesignResponseSlide3 embedded={embedded} />
      <TheResultSlide4 embedded={embedded} />
      <HumanAndIntelligentWorkingAsOneSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
