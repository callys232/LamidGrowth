import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BuildTheBusinessBehindTheWorkSlide3,
  ClarifyTheDirectionSlide1,
  ExecuteWithoutLosingFlexibilitySlide4,
  ExploreOpportunitySlide2,
  StructureSupportsTheWorkItDoesNotReplaceItSlide6,
  TurnAnAudienceIntoASustainableOfferSlide5,
  WhoItsForCreatorsHeroSlide,
} from './slides';

/** /who-its-for/creators — sections in reading order. */
export function WhoItsForCreatorsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForCreatorsHeroSlide embedded={embedded} />}
    >
      <ClarifyTheDirectionSlide1 embedded={embedded} />
      <ExploreOpportunitySlide2 embedded={embedded} />
      <BuildTheBusinessBehindTheWorkSlide3 embedded={embedded} />
      <ExecuteWithoutLosingFlexibilitySlide4 embedded={embedded} />
      <TurnAnAudienceIntoASustainableOfferSlide5 embedded={embedded} />
      <StructureSupportsTheWorkItDoesNotReplaceItSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
