import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AboutHeroSlide,
  MissionSlide3,
  OneSystemInsteadOfMoreFragmentationSlide5,
  OurBeliefSlide1,
  VisionSlide4,
  WhatWeAreBuildingSlide2,
} from './slides';

/** /about — sections in reading order. */
export function AboutDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<AboutHeroSlide embedded={embedded} />}
    >
      <OurBeliefSlide1 embedded={embedded} />
      <WhatWeAreBuildingSlide2 embedded={embedded} />
      <MissionSlide3 embedded={embedded} />
      <VisionSlide4 embedded={embedded} />
      <OneSystemInsteadOfMoreFragmentationSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
