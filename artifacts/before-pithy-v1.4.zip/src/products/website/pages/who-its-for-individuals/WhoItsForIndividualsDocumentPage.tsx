import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  KeepProgressMovingSlide3,
  MakeACareerDecisionSlide4,
  SetTheFocusSlide1,
  StrengthenCapabilitySlide2,
  WhoItsForIndividualsHeroSlide,
  YourPersonalContextStaysPersonalSlide5,
} from './slides';

/** /who-its-for/individuals — sections in reading order. */
export function WhoItsForIndividualsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForIndividualsHeroSlide embedded={embedded} />}
    >
      <SetTheFocusSlide1 embedded={embedded} />
      <StrengthenCapabilitySlide2 embedded={embedded} />
      <KeepProgressMovingSlide3 embedded={embedded} />
      <MakeACareerDecisionSlide4 embedded={embedded} />
      <YourPersonalContextStaysPersonalSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
