import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  FinancialUnderstandingSlide2,
  ImproveMarginWithoutSlowingGrowthSlide6,
  ModernizationSlide5,
  MoreCapabilityLessFragmentationSlide7,
  OperationsSlide1,
  OpportunitySlide4,
  PeopleSlide3,
  WhoItsForSmesHeroSlide,
} from './slides';

/** /who-its-for/smes — sections in reading order. */
export function WhoItsForSmesDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<WhoItsForSmesHeroSlide embedded={embedded} />}
    >
      <OperationsSlide1 embedded={embedded} />
      <FinancialUnderstandingSlide2 embedded={embedded} />
      <PeopleSlide3 embedded={embedded} />
      <OpportunitySlide4 embedded={embedded} />
      <ModernizationSlide5 embedded={embedded} />
      <ImproveMarginWithoutSlowingGrowthSlide6 embedded={embedded} />
      <MoreCapabilityLessFragmentationSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
