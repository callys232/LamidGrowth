import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AdvertisingAndThirdPartiesSlide3,
  ChangesAndContactSlide6,
  DurationSlide4,
  LegalCookiesHeroSlide,
  NecessaryTechnologiesSlide1,
  PreferencesAndAnalyticsSlide2,
  YourChoicesSlide5,
} from './slides';

/** /legal/cookies — sections in reading order. */
export function LegalCookiesDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<LegalCookiesHeroSlide embedded={embedded} />}
    >
      <NecessaryTechnologiesSlide1 embedded={embedded} />
      <PreferencesAndAnalyticsSlide2 embedded={embedded} />
      <AdvertisingAndThirdPartiesSlide3 embedded={embedded} />
      <DurationSlide4 embedded={embedded} />
      <YourChoicesSlide5 embedded={embedded} />
      <ChangesAndContactSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
