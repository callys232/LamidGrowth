import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ChooseATopicSlide1,
  DescribeTheOutcomeSlide2,
  ShareUsefulContextSlide3,
  SubmitSlide4,
  SupportHeroSlide,
} from './slides';

/** /support — sections in reading order. */
export function SupportDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<SupportHeroSlide embedded={embedded} />}
    >
      <ChooseATopicSlide1 embedded={embedded} />
      <DescribeTheOutcomeSlide2 embedded={embedded} />
      <ShareUsefulContextSlide3 embedded={embedded} />
      <SubmitSlide4 embedded={embedded} />
    </DocumentPageLayout>
  );
}
