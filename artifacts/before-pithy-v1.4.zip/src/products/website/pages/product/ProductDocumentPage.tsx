import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ASimpleOperatingCycleSlide2,
  BeginWithTheObjectiveSlide1,
  CapabilitiesAppearWhenTheWorkRequiresThemSlide6,
  ContinuousIntelligenceKeepsTheOperatingContextCurrentSlide7,
  OneObjectiveSeveralPerspectivesSlide5,
  OneOsDifferentRelevantDepthSlide8,
  ProductHeroSlide,
  SimpleWhereItShouldBeDeepWhereItNeedsToBeSlide3,
  StartWithYourObjectiveSlide4,
} from './slides';

/** /product — sections in reading order. */
export function ProductDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductHeroSlide embedded={embedded} />}
    >
      <BeginWithTheObjectiveSlide1 embedded={embedded} />
      <ASimpleOperatingCycleSlide2 embedded={embedded} />
      <SimpleWhereItShouldBeDeepWhereItNeedsToBeSlide3 embedded={embedded} />
      <StartWithYourObjectiveSlide4 embedded={embedded} />
      <OneObjectiveSeveralPerspectivesSlide5 embedded={embedded} />
      <CapabilitiesAppearWhenTheWorkRequiresThemSlide6 embedded={embedded} />
      <ContinuousIntelligenceKeepsTheOperatingContextCurrentSlide7 embedded={embedded} />
      <OneOsDifferentRelevantDepthSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
