import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilitySlide2,
  ClaritySlide1,
  ConsistencySlide3,
  HowItWorksHeroSlide,
  ImproveCustomerRetentionSlide6,
  OutcomeGrowthSlide4,
  PersistentProgressionSlide7,
  TheCompanionConnectsTheCycleSlide5,
  TheCycleStaysSimpleTheDepthAppearsWhenNeededSlide8,
} from './slides';

/** /how-it-works — sections in reading order. */
export function HowItWorksDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksHeroSlide embedded={embedded} />}
    >
      <ClaritySlide1 embedded={embedded} />
      <CapabilitySlide2 embedded={embedded} />
      <ConsistencySlide3 embedded={embedded} />
      <OutcomeGrowthSlide4 embedded={embedded} />
      <TheCompanionConnectsTheCycleSlide5 embedded={embedded} />
      <ImproveCustomerRetentionSlide6 embedded={embedded} />
      <PersistentProgressionSlide7 embedded={embedded} />
      <TheCycleStaysSimpleTheDepthAppearsWhenNeededSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
