import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CommercialWorkSlide8,
  CurrentPrioritiesSlide1,
  FinancialContextSlide3,
  OperationalClaritySlide2,
  OpportunitiesSlide5,
  OsBusinessHeroSlide,
  PeopleCapabilitySlide4,
  RecentDecisionsSlide7,
  WorkflowsSlide6,
} from './slides';

/** /os/business — sections in reading order. */
export function OsBusinessDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsBusinessHeroSlide embedded={embedded} />}
    >
      <CurrentPrioritiesSlide1 embedded={embedded} />
      <OperationalClaritySlide2 embedded={embedded} />
      <FinancialContextSlide3 embedded={embedded} />
      <PeopleCapabilitySlide4 embedded={embedded} />
      <OpportunitiesSlide5 embedded={embedded} />
      <WorkflowsSlide6 embedded={embedded} />
      <RecentDecisionsSlide7 embedded={embedded} />
      <CommercialWorkSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
