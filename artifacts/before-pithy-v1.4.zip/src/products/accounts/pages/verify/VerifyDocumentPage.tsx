import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ResendVerificationSlide2,
  VerificationShouldResistReuseAndBypassSlide3,
  VerificationStatusSlide1,
  VerifyHeroSlide,
} from './slides';

/** /verify — sections in reading order. */
export function VerifyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<VerifyHeroSlide embedded={embedded} />}
    >
      <VerificationStatusSlide1 embedded={embedded} />
      <ResendVerificationSlide2 embedded={embedded} />
      <VerificationShouldResistReuseAndBypassSlide3 embedded={embedded} />
    </DocumentPageLayout>
  );
}
