import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ActiveWorkSlide4,
  InsightsSlide6,
  NeedsYourJudgmentSlide5,
  OsHeroSlide,
  ProgressSlide3,
  ResumeTheMostImportantWorkSlide8,
  RhythmSlide7,
  SinceYourLastSessionSlide1,
  TodaySlide2,
} from './slides';

/** /os — sections in reading order. */
export function OsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsHeroSlide embedded={embedded} />}
    >
      <SinceYourLastSessionSlide1 embedded={embedded} />
      <TodaySlide2 embedded={embedded} />
      <ProgressSlide3 embedded={embedded} />
      <ActiveWorkSlide4 embedded={embedded} />
      <NeedsYourJudgmentSlide5 embedded={embedded} />
      <InsightsSlide6 embedded={embedded} />
      <RhythmSlide7 embedded={embedded} />
      <ResumeTheMostImportantWorkSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
