import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AssumptionsSlide6,
  ChooseBetweenTwoGrowthPathsSlide8,
  OpportunitySlide1,
  OsOpportunitiesHeroSlide,
  PathwaySlide7,
  PotentialImpactSlide3,
  RequiredCapabilitySlide4,
  TradeOffsSlide5,
  WhyItMattersSlide2,
} from './slides';

/** /os/opportunities — sections in reading order. */
export function OsOpportunitiesDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsOpportunitiesHeroSlide embedded={embedded} />}
    >
      <OpportunitySlide1 embedded={embedded} />
      <WhyItMattersSlide2 embedded={embedded} />
      <PotentialImpactSlide3 embedded={embedded} />
      <RequiredCapabilitySlide4 embedded={embedded} />
      <TradeOffsSlide5 embedded={embedded} />
      <AssumptionsSlide6 embedded={embedded} />
      <PathwaySlide7 embedded={embedded} />
      <ChooseBetweenTwoGrowthPathsSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
