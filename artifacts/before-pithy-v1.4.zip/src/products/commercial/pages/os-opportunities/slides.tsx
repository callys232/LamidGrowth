import { DocumentHeroSlide } from '../../../../shared/content/slides/DocumentHeroSlide';
import { DocumentSectionSlide } from '../../../../shared/content/slides/DocumentSectionSlide';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';

export function OsOpportunitiesHeroSlide({ embedded = false }: DocumentPageProps) {
  return <DocumentHeroSlide page={content} embedded={embedded} />;
}

/** Opportunity */
export function OpportunitySlide1({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[0]}
      index={0}
      last={false}
      embedded={embedded}
    />
  );
}

/** Why It Matters */
export function WhyItMattersSlide2({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[1]}
      index={1}
      last={false}
      embedded={embedded}
    />
  );
}

/** Potential Impact */
export function PotentialImpactSlide3({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[2]}
      index={2}
      last={false}
      embedded={embedded}
    />
  );
}

/** Required Capability */
export function RequiredCapabilitySlide4({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[3]}
      index={3}
      last={false}
      embedded={embedded}
    />
  );
}

/** Trade-Offs */
export function TradeOffsSlide5({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[4]}
      index={4}
      last={false}
      embedded={embedded}
    />
  );
}

/** Assumptions */
export function AssumptionsSlide6({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[5]}
      index={5}
      last={false}
      embedded={embedded}
    />
  );
}

/** Pathway */
export function PathwaySlide7({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide
      section={content.sections[6]}
      index={6}
      last={false}
      embedded={embedded}
    />
  );
}

/** Choose Between Two Growth Paths */
export function ChooseBetweenTwoGrowthPathsSlide8({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentSectionSlide section={content.sections[7]} index={7} last={true} embedded={embedded} />
  );
}
