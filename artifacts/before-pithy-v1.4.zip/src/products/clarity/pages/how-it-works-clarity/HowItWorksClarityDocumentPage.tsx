import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  BetterActionStartsWithBetterUnderstandingSlide6,
  DecideWhatToFixFirstSlide5,
  HowItWorksClarityHeroSlide,
  ReduceNoiseSlide1,
  RevealPatternsSlide3,
  SetThePrioritySlide4,
  UnderstandContextSlide2,
} from './slides';

/** /how-it-works/clarity — sections in reading order. */
export function HowItWorksClarityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksClarityHeroSlide embedded={embedded} />}
    >
      <ReduceNoiseSlide1 embedded={embedded} />
      <UnderstandContextSlide2 embedded={embedded} />
      <RevealPatternsSlide3 embedded={embedded} />
      <SetThePrioritySlide4 embedded={embedded} />
      <DecideWhatToFixFirstSlide5 embedded={embedded} />
      <BetterActionStartsWithBetterUnderstandingSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
