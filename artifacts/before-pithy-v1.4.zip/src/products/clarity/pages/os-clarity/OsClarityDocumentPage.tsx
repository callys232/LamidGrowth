import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AddContextSlide2,
  DefineTheObjectiveSlide1,
  OsClarityHeroSlide,
  SetThePrioritySlide4,
  SurfaceAssumptionsSlide3,
  TurnAmbiguityIntoADecisionFrameSlide5,
} from './slides';

/** /os/clarity — sections in reading order. */
export function OsClarityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsClarityHeroSlide embedded={embedded} />}
    >
      <DefineTheObjectiveSlide1 embedded={embedded} />
      <AddContextSlide2 embedded={embedded} />
      <SurfaceAssumptionsSlide3 embedded={embedded} />
      <SetThePrioritySlide4 embedded={embedded} />
      <TurnAmbiguityIntoADecisionFrameSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
