import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ContextBeforeAnswersSlide2,
  ContextYouControlSlide6,
  FromUnderstandingToActionSlide3,
  GuidanceWithoutPressureSlide5,
  PrepareAHiringDecisionSlide4,
  ProductCompanionHeroSlide,
  StartWithIntentSlide1,
} from './slides';

/** /product/companion — sections in reading order. */
export function ProductCompanionDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductCompanionHeroSlide embedded={embedded} />}
    >
      <StartWithIntentSlide1 embedded={embedded} />
      <ContextBeforeAnswersSlide2 embedded={embedded} />
      <FromUnderstandingToActionSlide3 embedded={embedded} />
      <PrepareAHiringDecisionSlide4 embedded={embedded} />
      <GuidanceWithoutPressureSlide5 embedded={embedded} />
      <ContextYouControlSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
