import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ChangeContextWithoutChangingProductSlide5,
  EnterpriseInstitutionSlide4,
  FounderSmeSlide3,
  PersonalSlide1,
  ProductExperienceHeroSlide,
  ProfessionalCreatorSlide2,
  TheContextChangesTheSystemRemainsOneSlide6,
} from './slides';

/** /product/experience — sections in reading order. */
export function ProductExperienceDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductExperienceHeroSlide embedded={embedded} />}
    >
      <PersonalSlide1 embedded={embedded} />
      <ProfessionalCreatorSlide2 embedded={embedded} />
      <FounderSmeSlide3 embedded={embedded} />
      <EnterpriseInstitutionSlide4 embedded={embedded} />
      <ChangeContextWithoutChangingProductSlide5 embedded={embedded} />
      <TheContextChangesTheSystemRemainsOneSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
