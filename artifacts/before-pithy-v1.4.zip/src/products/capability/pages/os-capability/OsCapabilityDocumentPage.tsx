import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AvailableNowSlide2,
  BuildAccessDelegateSlide4,
  CloseTheCriticalGapFirstSlide5,
  GapsSlide3,
  OsCapabilityHeroSlide,
  RequirementsSlide1,
} from './slides';

/** /os/capability — sections in reading order. */
export function OsCapabilityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsCapabilityHeroSlide embedded={embedded} />}
    >
      <RequirementsSlide1 embedded={embedded} />
      <AvailableNowSlide2 embedded={embedded} />
      <GapsSlide3 embedded={embedded} />
      <BuildAccessDelegateSlide4 embedded={embedded} />
      <CloseTheCriticalGapFirstSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
