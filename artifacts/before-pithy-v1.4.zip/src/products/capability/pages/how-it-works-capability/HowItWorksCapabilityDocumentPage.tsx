import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilityDoesNotHaveToBeBuiltAloneSlide6,
  CapabilityIsMoreThanSkillSlide1,
  HowItWorksCapabilityHeroSlide,
  OrganizationalCapabilitySlide4,
  PersonalCapabilitySlide2,
  PrepareForANewGrowthStageSlide5,
  TeamCapabilitySlide3,
} from './slides';

/** /how-it-works/capability — sections in reading order. */
export function HowItWorksCapabilityDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksCapabilityHeroSlide embedded={embedded} />}
    >
      <CapabilityIsMoreThanSkillSlide1 embedded={embedded} />
      <PersonalCapabilitySlide2 embedded={embedded} />
      <TeamCapabilitySlide3 embedded={embedded} />
      <OrganizationalCapabilitySlide4 embedded={embedded} />
      <PrepareForANewGrowthStageSlide5 embedded={embedded} />
      <CapabilityDoesNotHaveToBeBuiltAloneSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
