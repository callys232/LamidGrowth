import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AdjustSlide4,
  BuildARhythmSlide2,
  ConsistencyKeepsImportantWorkMovingWithoutBlockingAdaptationSlide6,
  HowItWorksConsistencyHeroSlide,
  ImproveASalesProcessSlide5,
  MoveTheNextActionSlide1,
  ReviewTheResultSlide3,
} from './slides';

/** /how-it-works/consistency — sections in reading order. */
export function HowItWorksConsistencyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksConsistencyHeroSlide embedded={embedded} />}
    >
      <MoveTheNextActionSlide1 embedded={embedded} />
      <BuildARhythmSlide2 embedded={embedded} />
      <ReviewTheResultSlide3 embedded={embedded} />
      <AdjustSlide4 embedded={embedded} />
      <ImproveASalesProcessSlide5 embedded={embedded} />
      <ConsistencyKeepsImportantWorkMovingWithoutBlockingAdaptationSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
