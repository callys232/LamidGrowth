import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AdaptationSlide4,
  CommitmentSlide2,
  ConvertTheDecisionIntoAWorkingCommitmentSlide5,
  NextActionSlide1,
  OsConsistencyHeroSlide,
  RhythmSlide3,
} from './slides';

/** /os/consistency — sections in reading order. */
export function OsConsistencyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsConsistencyHeroSlide embedded={embedded} />}
    >
      <NextActionSlide1 embedded={embedded} />
      <CommitmentSlide2 embedded={embedded} />
      <RhythmSlide3 embedded={embedded} />
      <AdaptationSlide4 embedded={embedded} />
      <ConvertTheDecisionIntoAWorkingCommitmentSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
