import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CapabilitySlide2,
  ClaritySlide1,
  ConsistencySlide3,
  OsTodayHeroSlide,
  ReflectionSlide4,
  ResolveTodaySPrioritySlide5,
} from './slides';

/** /os/today — sections in reading order. */
export function OsTodayDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsTodayHeroSlide embedded={embedded} />}
    >
      <ClaritySlide1 embedded={embedded} />
      <CapabilitySlide2 embedded={embedded} />
      <ConsistencySlide3 embedded={embedded} />
      <ReflectionSlide4 embedded={embedded} />
      <ResolveTodaySPrioritySlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
