import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  ChooseYourNextProfessionalMoveSlide1,
  MoveFromCommercialIntentToVerifiedDeliverySlide6,
  PlanTheNextStageOfTheBusinessSlide3,
  ProductIntelligenceHeroSlide,
  SpecialistDepthUnderneathSlide5,
  StrengthenOrganizationalAlignmentSlide4,
  TurnAnIdeaIntoAViableDirectionSlide2,
} from './slides';

/** /product/intelligence — sections in reading order. */
export function ProductIntelligenceDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<ProductIntelligenceHeroSlide embedded={embedded} />}
    >
      <ChooseYourNextProfessionalMoveSlide1 embedded={embedded} />
      <TurnAnIdeaIntoAViableDirectionSlide2 embedded={embedded} />
      <PlanTheNextStageOfTheBusinessSlide3 embedded={embedded} />
      <StrengthenOrganizationalAlignmentSlide4 embedded={embedded} />
      <SpecialistDepthUnderneathSlide5 embedded={embedded} />
      <MoveFromCommercialIntentToVerifiedDeliverySlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
