import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  HowItWorksRhythmHeroSlide,
  OrganizationSlide4,
  SeeProgressInAnEvolvingContextNotJustAsAScoreSlide6,
  ThisMonthSlide3,
  ThisWeekSlide2,
  TodaySlide1,
  TurnAStrategicPriorityIntoAWorkingCadenceSlide5,
} from './slides';

/** /how-it-works/rhythm — sections in reading order. */
export function HowItWorksRhythmDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<HowItWorksRhythmHeroSlide embedded={embedded} />}
    >
      <TodaySlide1 embedded={embedded} />
      <ThisWeekSlide2 embedded={embedded} />
      <ThisMonthSlide3 embedded={embedded} />
      <OrganizationSlide4 embedded={embedded} />
      <TurnAStrategicPriorityIntoAWorkingCadenceSlide5 embedded={embedded} />
      <SeeProgressInAnEvolvingContextNotJustAsAScoreSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
