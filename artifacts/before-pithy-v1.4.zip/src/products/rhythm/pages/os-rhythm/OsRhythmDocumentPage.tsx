import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  CarryLearningForwardSlide5,
  HistorySlide4,
  OsRhythmHeroSlide,
  ThisMonthSlide3,
  ThisWeekSlide2,
  TodaySlide1,
} from './slides';

/** /os/rhythm — sections in reading order. */
export function OsRhythmDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsRhythmHeroSlide embedded={embedded} />}
    >
      <TodaySlide1 embedded={embedded} />
      <ThisWeekSlide2 embedded={embedded} />
      <ThisMonthSlide3 embedded={embedded} />
      <HistorySlide4 embedded={embedded} />
      <CarryLearningForwardSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
