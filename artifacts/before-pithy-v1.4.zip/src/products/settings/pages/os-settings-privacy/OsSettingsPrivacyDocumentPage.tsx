import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiDataPermissionsSlide6,
  BackgroundUpdatesSlide7,
  ConnectedSourcesSlide5,
  DeleteDataSlide3,
  ExportDataSlide2,
  OsSettingsPrivacyHeroSlide,
  RetentionSlide4,
  ViewDataSlide1,
} from './slides';

/** /os/settings/privacy — sections in reading order. */
export function OsSettingsPrivacyDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsSettingsPrivacyHeroSlide embedded={embedded} />}
    >
      <ViewDataSlide1 embedded={embedded} />
      <ExportDataSlide2 embedded={embedded} />
      <DeleteDataSlide3 embedded={embedded} />
      <RetentionSlide4 embedded={embedded} />
      <ConnectedSourcesSlide5 embedded={embedded} />
      <AiDataPermissionsSlide6 embedded={embedded} />
      <BackgroundUpdatesSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
