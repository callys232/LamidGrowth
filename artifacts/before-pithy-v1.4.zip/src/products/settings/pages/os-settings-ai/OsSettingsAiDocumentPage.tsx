import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AiPersonalizationSlide5,
  ContinuousContextSlide7,
  DeleteRememberedContextSlide3,
  ExplanationPreferencesSlide6,
  MemorySlide1,
  OsSettingsAiHeroSlide,
  RememberedContextSlide2,
  SuggestionPreferencesSlide4,
} from './slides';

/** /os/settings/ai — sections in reading order. */
export function OsSettingsAiDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsSettingsAiHeroSlide embedded={embedded} />}
    >
      <MemorySlide1 embedded={embedded} />
      <RememberedContextSlide2 embedded={embedded} />
      <DeleteRememberedContextSlide3 embedded={embedded} />
      <SuggestionPreferencesSlide4 embedded={embedded} />
      <AiPersonalizationSlide5 embedded={embedded} />
      <ExplanationPreferencesSlide6 embedded={embedded} />
      <ContinuousContextSlide7 embedded={embedded} />
    </DocumentPageLayout>
  );
}
