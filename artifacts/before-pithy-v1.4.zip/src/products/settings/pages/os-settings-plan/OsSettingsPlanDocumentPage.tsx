import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AvailableCapabilitiesSlide2,
  CurrentPlanSlide1,
  LimitsSlide4,
  OrganizationRequirementsSlide6,
  OsSettingsPlanHeroSlide,
  UpgradeOptionsSlide5,
  UsageSlide3,
} from './slides';

/** /os/settings/plan — sections in reading order. */
export function OsSettingsPlanDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsSettingsPlanHeroSlide embedded={embedded} />}
    >
      <CurrentPlanSlide1 embedded={embedded} />
      <AvailableCapabilitiesSlide2 embedded={embedded} />
      <UsageSlide3 embedded={embedded} />
      <LimitsSlide4 embedded={embedded} />
      <UpgradeOptionsSlide5 embedded={embedded} />
      <OrganizationRequirementsSlide6 embedded={embedded} />
    </DocumentPageLayout>
  );
}
