import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  GroupsTeamsSlide5,
  InvitationsSlide3,
  MembersSlide1,
  OsSettingsMembersHeroSlide,
  PermissionsSlide4,
  RolesSlide2,
} from './slides';

/** /os/settings/members — sections in reading order. */
export function OsSettingsMembersDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsSettingsMembersHeroSlide embedded={embedded} />}
    >
      <MembersSlide1 embedded={embedded} />
      <RolesSlide2 embedded={embedded} />
      <InvitationsSlide3 embedded={embedded} />
      <PermissionsSlide4 embedded={embedded} />
      <GroupsTeamsSlide5 embedded={embedded} />
    </DocumentPageLayout>
  );
}
