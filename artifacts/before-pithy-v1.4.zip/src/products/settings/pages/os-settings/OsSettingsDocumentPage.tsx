import { DocumentPageLayout } from '../../../../shared/content/DocumentPageLayout';
import type { DocumentPageProps } from '../../../../shared/content/types';
import content from './content.json';
import {
  AccountSlide1,
  AiMemorySlide2,
  BillingSlide7,
  MembersSlide6,
  NotificationsSlide4,
  OsSettingsHeroSlide,
  PlanUsageSlide8,
  PrivacySlide3,
  WorkspaceSlide5,
} from './slides';

/** /os/settings — sections in reading order. */
export function OsSettingsDocumentPage({ embedded = false }: DocumentPageProps) {
  return (
    <DocumentPageLayout
      page={content}
      embedded={embedded}
      hero={<OsSettingsHeroSlide embedded={embedded} />}
    >
      <AccountSlide1 embedded={embedded} />
      <AiMemorySlide2 embedded={embedded} />
      <PrivacySlide3 embedded={embedded} />
      <NotificationsSlide4 embedded={embedded} />
      <WorkspaceSlide5 embedded={embedded} />
      <MembersSlide6 embedded={embedded} />
      <BillingSlide7 embedded={embedded} />
      <PlanUsageSlide8 embedded={embedded} />
    </DocumentPageLayout>
  );
}
