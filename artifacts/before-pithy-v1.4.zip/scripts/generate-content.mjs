import { readFileSync, writeFileSync } from 'node:fs';
import { writeProductContent } from './lib/page-content.mjs';
const routes = JSON.parse(
  readFileSync('document-study/route-inventory.json', 'utf8').replace(/^\uFEFF/, ''),
);
const lines = readFileSync('document-study/website.txt', 'utf8')
  .replace(/^\uFEFF/, '')
  .split(/\r?\n/)
  .filter(Boolean)
  .map((line) => line.replace(/^\[\d+\]\s*/, ''));
const content = routes.map((route, index) => {
  const start = route.source_paragraph - 1;
  const end = routes[index + 1]
    ? routes[index + 1].source_paragraph - 1
    : lines.findIndex((line) => line.startsWith('APPENDIX - FINAL LAUNCH'));
  const raw = lines.slice(start, end);
  const hero = raw.indexOf('HERO');
  const sections = [];
  let current = { label: 'HERO', paragraphs: [] };
  for (let i = hero + 1; i < raw.length; i++) {
    const line = raw[i];
    if (/^SECTION(?:\s|$)/.test(line)) {
      if (current.paragraphs.length) sections.push(current);
      current = { label: line, paragraphs: [] };
    } else current.paragraphs.push({ text: line, sourceParagraph: start + i + 1 });
  }
  if (current.paragraphs.length) sections.push(current);
  const blocks = sections.map((block) => ({
    ...block,
    title: block.paragraphs[0]?.text || '',
    body: block.paragraphs.slice(1).map((p) => p.text),
  }));
  return {
    ...route,
    title: blocks[0]?.title || route.name,
    description: blocks[0]?.body[0] || '',
    hero: blocks[0],
    sections: blocks.slice(1),
    blocks,
  };
});
writeProductContent(content);
writeFileSync('src/content/pages.json', JSON.stringify(content, null, 2));
writeFileSync(
  'src/content/routes.json',
  JSON.stringify(
    routes.map(({ route, page, name, gates }) => ({ route, page, name, gated: gates.length > 0 })),
    null,
    2,
  ),
);
console.log(`Generated ${content.length} complete pages without paragraph or section limits.`);
