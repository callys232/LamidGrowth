import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { loadPageManifest, readProductPages } from '../scripts/lib/page-content.mjs';
test('product-owned pages preserve every original paragraph without clipping or prefix filtering', () => {
  const lines = readFileSync('document-study/website.txt', 'utf8')
    .replace(/^\uFEFF/, '')
    .split(/\r?\n/)
    .filter(Boolean)
    .map((x) => x.replace(/^\[\d+\]\s*/, ''));
  const pages = readProductPages();
  assert.equal(pages.length, 98);
  for (const [index, page] of pages.entries()) {
    const start = page.source_paragraph - 1;
    const end = pages[index + 1]
      ? pages[index + 1].source_paragraph - 1
      : lines.indexOf('APPENDIX - FINAL LAUNCH ACCEPTANCE CHECK');
    const block = lines.slice(start, end);
    const expected = block
      .slice(block.indexOf('HERO') + 1)
      .filter((x) => !/^SECTION(?:\s|$)/.test(x));
    assert.deepEqual(
      [page.hero, ...page.sections].flatMap((b) => b.paragraphs.map((p) => p.text)),
      expected,
      page.route,
    );
  }
});

test('every document route resolves to a unique named product page and matching content', () => {
  const manifest = loadPageManifest();
  const original = JSON.parse(readFileSync('src/content/routes.json', 'utf8'));
  assert.deepEqual(
    manifest.map((entry) => entry.route),
    original.map((entry) => entry.route),
  );
  assert.equal(new Set(manifest.map((entry) => entry.component)).size, manifest.length);
  for (const entry of manifest) {
    const page = JSON.parse(readFileSync(entry.content, 'utf8'));
    assert.equal(page.route, entry.route);
    assert.ok(entry.component.startsWith(`src/products/${entry.product}/pages/`));
    assert.ok(readFileSync(entry.component, 'utf8').includes(`function ${entry.exportName}(`));
  }
});
