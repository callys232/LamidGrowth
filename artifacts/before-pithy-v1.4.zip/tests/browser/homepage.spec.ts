import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('homepage puts its main actions above the fold and its product preview supports keyboard use', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('/');
  const primary = page
    .locator('.home-premium-hero .canonical-ctas')
    .getByRole('link', { name: 'Experience LAMID ONE', exact: true });
  const bounds = (await primary.boundingBox())!;
  expect(bounds.y + bounds.height).toBeLessThan(900);
  await expect(primary).toHaveAttribute('href', '/start');
  const clarity = page.getByRole('tab', { name: 'Clarity', exact: true });
  await clarity.focus();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Capability', exact: true })).toBeFocused();
  await expect(page.getByRole('tabpanel')).toContainText('See what the work requires.');
  await page.keyboard.press('End');
  await expect(page.getByRole('tab', { name: 'Consistency', exact: true })).toHaveAttribute(
    'aria-selected',
    'true',
  );
  await expect(page.getByRole('tabpanel')).toContainText('Turn the decision into progress.');
  await page.keyboard.press('Home');
  await expect(clarity).toHaveAttribute('aria-selected', 'true');
  await page.getByText('How context carries forward', { exact: true }).click();
  await expect(page.locator('.home-detail')).toHaveAttribute('open', '');
  const scan = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  expect(scan.violations.map((v) => ({ id: v.id, targets: v.nodes.map((n) => n.target) }))).toEqual(
    [],
  );
});

test('homepage fits narrow screens and the preview remains usable', async ({ page }) => {
  for (const width of [320, 390, 768]) {
    await page.setViewportSize({ width, height: 844 });
    await page.goto('/');
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
    await page.getByRole('tab', { name: 'Consistency', exact: true }).click();
    await expect(page.getByRole('tabpanel')).toContainText('Turn the decision into progress.');
    await expect(
      page.getByRole('button', { name: 'Explore the workspace', exact: true }),
    ).toBeVisible();
  }
});
