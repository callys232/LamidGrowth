import {
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronRight,
  Pause,
  Play,
  Plus,
  ShieldCheck,
  Target,
} from 'lucide-react';
import type { ReactNode } from 'react';
import { useState } from 'react';
import { useWorkspace } from '../components/WorkspaceShell';
import { Button, Eyebrow, Modal, dateLabel } from '../components/ui';
import type { Action, Objective, Status } from '../types';
import { MotionSurface } from './Motion';
import { useLocation } from 'react-router-dom';
import { sourcePage } from './CanonicalCopy';

export function PageHeading({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  const source = sourcePage(useLocation().pathname);
  return (
    <MotionSurface className="page-heading">
      <div>
        <Eyebrow>{eyebrow}</Eyebrow>
        <h1>{source?.title || title}</h1>
        <p>{source?.description || description}</p>
      </div>
      {children}
    </MotionSurface>
  );
}
export function StatusPill({ status }: { status: string }) {
  return (
    <span className={`status-pill status-${status.toLowerCase().replaceAll(' ', '-')}`}>
      <span />
      {status}
    </span>
  );
}
export function ObjectiveCard({ objective }: { objective: Objective }) {
  const { state, newAction } = useWorkspace();
  const actions = state.actions.filter((a) => a.objectiveId === objective.id);
  const done = actions.filter((a) => a.status === 'Done').length;
  const percent = actions.length ? Math.round((done / actions.length) * 100) : 0;
  return (
    <article className="objective-card">
      <div className="objective-card-top">
        <span className={`priority priority-${objective.priority.toLowerCase()}`}>
          {objective.priority} priority
        </span>
        <span>{objective.context}</span>
      </div>
      <h3>{objective.title}</h3>
      <p>{objective.description || 'Add actions to turn this objective into progress.'}</p>
      <div className="objective-progress">
        <span>
          {done} of {actions.length} actions complete
        </span>
        <strong>{percent}%</strong>
      </div>
      <progress
        value={done}
        max={actions.length || 1}
        aria-label={`${objective.title}: ${percent}% complete`}
      />
      <div className="objective-card-bottom">
        <span>
          <CalendarDays size={13} />
          {dateLabel(objective.targetDate)}
        </span>
        <button
          className="text-button"
          disabled={objective.status === 'Complete'}
          onClick={() => newAction(objective.id)}
        >
          Next action <Plus size={14} />
        </button>
      </div>
    </article>
  );
}
export function ActionRow({ action }: { action: Action }) {
  const { state } = useWorkspace();
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        className="action-row"
        data-active={open}
        aria-haspopup="dialog"
        onClick={() => setOpen(true)}
      >
        <span className={`action-check ${action.status === 'Done' ? 'complete' : ''}`}>
          {action.status === 'Done' ? (
            <Check size={13} />
          ) : action.status === 'In progress' ? (
            <span />
          ) : null}
        </span>
        <span className="action-row-title">
          <strong>{action.title}</strong>
          <small>{state.objectives.find((o) => o.id === action.objectiveId)?.title}</small>
        </span>
        <StatusPill status={action.status} />
        <span className="action-date">{dateLabel(action.dueDate)}</span>
        <ChevronRight size={15} />
      </button>
      {open && <ActionDetail action={action} onClose={() => setOpen(false)} />}
    </>
  );
}
export function ActionDetail({ action, onClose }: { action: Action; onClose: () => void }) {
  const { state, updateAction } = useWorkspace();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function move(status: Status, decision?: 'approve' | 'return') {
    setBusy(true);
    try {
      await updateAction(action, status, decision);
      onClose();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title={action.title} onClose={onClose}>
      <div className="detail-meta">
        <StatusPill status={action.status} />
        <span>Version {action.version}</span>
      </div>
      <p className="detail-objective">
        <Target size={15} />
        {state.objectives.find((o) => o.id === action.objectiveId)?.title}
      </p>
      <div className="detail-note">
        <Eyebrow>NOTES & ACCEPTANCE CRITERIA</Eyebrow>
        <p>
          {action.notes ||
            'No additional criteria recorded. Review the objective before completing this action.'}
        </p>
      </div>
      <dl className="detail-list">
        <div>
          <dt>Owner</dt>
          <dd>{action.owner}</dd>
        </div>
        <div>
          <dt>Due</dt>
          <dd>{dateLabel(action.dueDate)}</dd>
        </div>
        <div>
          <dt>Review</dt>
          <dd>{action.requiresApproval ? 'Explicit approval required' : 'Owner completion'}</dd>
        </div>
      </dl>
      {action.status === 'Needs review' && (
        <div className="review-callout">
          <ShieldCheck size={19} />
          <p>
            Review the notes and confirm the work meets your expectations. Your decision is recorded
            against version {action.version}.
          </p>
        </div>
      )}
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      <div className="modal-actions action-detail-buttons">
        {action.status === 'Planned' && (
          <Button disabled={busy} onClick={() => void move('In progress')}>
            Start action <Play size={15} />
          </Button>
        )}
        {action.status === 'In progress' && (
          <Button
            disabled={busy}
            onClick={() => void move(action.requiresApproval ? 'Needs review' : 'Done')}
          >
            {action.requiresApproval ? 'Submit for review' : 'Mark complete'}
            <Check size={15} />
          </Button>
        )}
        {action.status === 'Needs review' && state.permissions.includes('review:decide') && (
          <>
            <Button
              variant="secondary"
              disabled={busy}
              onClick={() => void move('In progress', 'return')}
            >
              Return for changes
            </Button>
            <Button disabled={busy} onClick={() => void move('Done', 'approve')}>
              Approve completion <Check size={15} />
            </Button>
          </>
        )}
        {['Planned', 'In progress', 'Needs review'].includes(action.status) && (
          <Button variant="ghost" disabled={busy} onClick={() => void move('Paused')}>
            <Pause size={14} /> Pause
          </Button>
        )}
        {action.status === 'Paused' && (
          <Button disabled={busy} onClick={() => void move('Planned')}>
            Resume planning <Play size={15} />
          </Button>
        )}
        {action.status === 'Done' && (
          <p className="success-note">
            <CheckCircle2 size={18} /> Complete. This action is preserved in your history.
          </p>
        )}
      </div>
    </Modal>
  );
}
