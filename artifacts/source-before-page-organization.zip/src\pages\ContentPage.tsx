import { useState, type ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CanonicalCopy, sourcePage } from '../components/CanonicalCopy';
import { Cta, Button } from '../components/ui';
import { Footer, PublicHeader } from './Marketing';
import { pageTheme } from '../pageThemes';
import { api } from '../api';
import pages from '../content/pages.json';
import { Link } from 'react-router-dom';

export function ContentPage({ children }: { children?: ReactNode }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState('');
  const page = sourcePage(pathname);
  async function demo() {
    setBusy(true);
    try {
      await api('/auth/demo', {});
      navigate('/os');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PublicHeader />
      <main id="main" className="content-page" data-page-theme={pageTheme(pathname)}>
        {page ? (
          <CanonicalCopy path={pathname} />
        ) : (
          <section className="section-wrap">
            <h1>Page not found</h1>
            <Cta to="/">Return home</Cta>
          </section>
        )}
        {pathname === '/' && (
          <section className="section-wrap canonical-controls">
            <Button onClick={demo} disabled={busy}>
              Explore the workspace
            </Button>
            {error && <p role="alert">{error}</p>}
          </section>
        )}
        {children && (
          <section id="working-controls" className="canonical-controls">
            {children}
          </section>
        )}
        {pathname === '/help' && (
          <section className="section-wrap canonical-controls">
            <label>
              Search Help
              <input
                className="canonical-search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                aria-label="Search help topics"
              />
            </label>
            <ul>
              {pages
                .filter(
                  (p) =>
                    p.route.startsWith('/help/') &&
                    `${p.title} ${p.description}`.toLowerCase().includes(query.toLowerCase()),
                )
                .map((p) => (
                  <li key={p.route}>
                    <Link to={p.route}>{p.title}</Link>
                  </li>
                ))}
            </ul>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
