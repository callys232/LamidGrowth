import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Compass,
  Layers3,
  Minus,
  MoveUpRight,
  Play,
  Plus,
  ShieldCheck,
} from 'lucide-react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { MotionSurface } from '../components/Motion';
import { AnimatePresence, m, useReducedMotion } from 'motion/react';
import { OrbitVisual } from '../components/Orbit';
import { Brand, Button, Cta, Eyebrow } from '../components/ui';

export { PublicHeader } from '../components/PublicHeader';
import { PublicHeader } from '../components/PublicHeader';

export function Footer() {
  return (
    <footer className="public-footer">
      <div className="footer-top">
        <div>
          <Brand light />
          <p>
            Human judgment and AI capability.
            <br />
            Working as one.
          </p>
        </div>
        {[
          [
            'Explore',
            ['The product', '/product'],
            ['How it works', '/how-it-works'],
            ['Your context', '/who-its-for'],
          ],
          [
            'Learn',
            ['Our story', '/about'],
            ['Getting started', '/help/getting-started'],
            ['Help center', '/help'],
          ],
          [
            'Trust',
            ['Human control', '/trust/governance'],
            ['Privacy & data', '/trust/privacy'],
            ['Accessibility', '/accessibility'],
          ],
        ].map(([title, ...links]) => (
          <div className="footer-column" key={title as string}>
            <h3>{title}</h3>
            {(links as string[][]).map(([label, route]) => (
              <Link key={route} to={route}>
                {label}
              </Link>
            ))}
          </div>
        ))}
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} LAMID ONE</span>
        <span>Progress, with intention.</span>
        <a href="#top">Back to top ↑</a>
      </div>
    </footer>
  );
}

export function Home() {
  const reduced = useReducedMotion();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [faq, setFaq] = useState<number | null>(0);
  async function demo() {
    setBusy(true);
    try {
      await api('/auth/demo', {});
      navigate('/os');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PublicHeader />
      <main id="main" className="marketing-home">
        <section className="home-hero">
          <MotionSurface className="hero-copy">
            <Eyebrow>
              <span className="live-dot" /> THE CONTINUOUS HUMAN–AI GROWTH OS
            </Eyebrow>
            <h1>
              Think clearly.
              <br />
              Move with purpose.
              <br />
              <em>Grow as one.</em>
            </h1>
            <p className="hero-description">
              Your context. Your decisions. Your next chapter.
              <br className="desktop-break" /> One connected space to turn what matters
              <br className="desktop-break" /> into meaningful progress.
            </p>
            <div className="hero-actions">
              <Cta to="/start">Find your starting point</Cta>
              <button className="text-button" onClick={demo} disabled={busy}>
                <span className="play-circle">
                  <Play size={12} fill="currentColor" />
                </span>
                {busy ? 'Opening workspace…' : 'Explore the workspace'}
              </button>
            </div>
            {error && (
              <p role="alert" className="form-error">
                {error}
              </p>
            )}
            <div className="hero-note">
              <ShieldCheck size={15} />
              <span>Your judgment stays at the center.</span>
            </div>
          </MotionSurface>
          <OrbitVisual />
        </section>
        <div className="intro-band">
          <span>
            ONE SYSTEM. <strong>YOUR EVOLVING CONTEXT.</strong>
          </span>
          <div>
            <span>For yourself</span>
            <span>For your work</span>
            <span>For your team</span>
            <span>
              For what’s next <ArrowUpRight size={14} />
            </span>
          </div>
        </div>
        <section className="cycle-section section-wrap" id="how-it-works">
          <div className="section-heading">
            <div>
              <Eyebrow>LESS FRAGMENTATION. MORE FORWARD.</Eyebrow>
              <h2>
                A clearer way
                <br />
                to <em>move forward.</em>
              </h2>
            </div>
            <p>
              Good progress isn’t a single breakthrough.
              <br />
              It’s a connected cycle of understanding,
              <br />
              capability, and consistent action.
            </p>
          </div>
          <div className="cycle-grid">
            {[
              {
                n: '01',
                icon: Compass,
                title: 'Find your clarity',
                description:
                  'Make sense of the situation. Bring priorities, assumptions, and possibilities into focus.',
                path: 'clarity',
                caption: 'Understand what matters',
                color: 'sage',
              },
              {
                n: '02',
                icon: Layers3,
                title: 'Build your capability',
                description:
                  'See what the next step requires. Connect the knowledge, people, and support to move forward.',
                path: 'capability',
                caption: 'Know what comes next',
                color: 'sand',
              },
              {
                n: '03',
                icon: MoveUpRight,
                title: 'Create your consistency',
                description:
                  'Turn a good decision into a workable rhythm. Review, learn, and adjust as your context evolves.',
                path: 'consistency',
                caption: 'Keep important work moving',
                color: 'blue',
              },
            ].map((item) => (
              <Link
                className={`cycle-card ${item.color}`}
                to={`/how-it-works/${item.path}`}
                key={item.n}
              >
                <div className="cycle-card-top">
                  <item.icon size={24} strokeWidth={1.25} />
                  <span>{item.n}</span>
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <div className="cycle-card-bottom">
                  <span>{item.caption}</span>
                  <ArrowUpRight size={19} />
                </div>
              </Link>
            ))}
          </div>
          <div className="growth-caption">
            <span className="growth-line" />
            <span>
              Clarity + capability + consistency <ArrowRight size={14} />{' '}
              <strong>Growth, over time.</strong>
            </span>
            <span className="growth-line" />
          </div>
        </section>
        <section className="workspace-showcase section-wrap">
          <div className="showcase-copy">
            <Eyebrow>MEET YOUR OPERATING SPACE</Eyebrow>
            <h2>
              Everything connected.
              <br />
              <em>Nothing lost.</em>
            </h2>
            <p>
              Return to a clear picture of your work. See what moved, what changed, and what needs
              your judgment—then take the next step.
            </p>
            <ul className="check-list">
              <li>
                <Check size={16} /> Context that carries forward
              </li>
              <li>
                <Check size={16} /> Decisions connected to action
              </li>
              <li>
                <Check size={16} /> A rhythm that makes progress visible
              </li>
            </ul>
            <Button variant="light" onClick={demo} disabled={busy}>
              Step inside the workspace <ArrowUpRight size={16} />
            </Button>
            <small className="sample-note">Explore with clearly labeled sample data.</small>
          </div>
          <div className="workspace-preview" aria-label="Illustrative workspace preview">
            <div className="preview-top">
              <span className="preview-logo">◐ LAMID ONE</span>
              <span>
                YOUR WORK, IN CONTEXT <span className="live-dot" />
              </span>
            </div>
            <div className="preview-content">
              <div className="preview-greeting">
                <Eyebrow>YOUR NEXT CHAPTER</Eyebrow>
                <h3>
                  A little clearer.
                  <br />A step further.
                </h3>
                <span className="preview-avatar">AM</span>
              </div>
              <div className="preview-focus">
                <div>
                  <span className="tag">YOUR FOCUS</span>
                  <h4>Launch our advisory practice</h4>
                  <p>One clear offer. Three meaningful conversations.</p>
                </div>
                <div className="mini-progress">
                  1<span>/ 3</span>
                </div>
              </div>
              <div className="preview-row">
                <span className="check-dot">
                  <Check size={12} />
                </span>
                <span>Protect time for focused work</span>
                <span>Complete</span>
              </div>
              <div className="preview-row">
                <span className="pending-dot" />
                <span>Draft the service offer</span>
                <span>In progress</span>
              </div>
              <div className="preview-review">
                <span className="gold-dot" />
                <div>
                  <strong>Your judgment, needed.</strong>
                  <small>Review customer interview questions</small>
                </div>
                <ArrowUpRight size={16} />
              </div>
            </div>
            <div className="preview-bottom">
              <span className="live-dot" /> Your context is connected.
              <span>Illustrative workspace</span>
            </div>
          </div>
        </section>
        <section className="contexts-section section-wrap">
          <div className="section-heading">
            <div>
              <Eyebrow>START WHERE YOU ARE</Eyebrow>
              <h2>
                One OS.
                <br />
                <em>Your kind of progress.</em>
              </h2>
            </div>
            <p>
              Start with the work in front of you.
              <br />
              Expand your context as your
              <br />
              ambition and responsibilities grow.
            </p>
          </div>
          <div className="context-grid">
            {[
              ['01', 'For yourself', 'Find clarity. Make room for what matters.', 'individuals'],
              ['02', 'For your work', 'Strengthen your judgment and capability.', 'professionals'],
              [
                '03',
                'For your business',
                'Connect the moving parts. Build with intent.',
                'founders',
              ],
              ['04', 'For your team', 'Shared understanding. Coordinated action.', 'teams'],
            ].map(([n, title, description, path]) => (
              <Link to={`/who-its-for/${path}`} key={n} className="context-card">
                <span>{n}</span>
                <h3>{title}</h3>
                <p>{description}</p>
                <ArrowUpRight size={20} />
              </Link>
            ))}
          </div>
        </section>
        <section className="trust-strip section-wrap">
          <ShieldCheck size={32} strokeWidth={1.2} />
          <div>
            <h3>Capability grows. Control stays with you.</h3>
            <p>Clear context, visible decisions, and human review where it matters.</p>
          </div>
          <Link to="/trust/governance">
            Explore the principles <ArrowUpRight size={16} />
          </Link>
        </section>
        <section className="faq-section section-wrap">
          <div>
            <Eyebrow>A LITTLE MORE CLARITY</Eyebrow>
            <h2>
              Before your
              <br />
              <em>next chapter.</em>
            </h2>
          </div>
          <div>
            {[
              [
                'What is LAMID ONE?',
                'A connected operating space for your objectives, context, decisions, and actions. The operating cycle brings clarity, capability, and consistency together so learning carries into the next step.',
              ],
              [
                'Where should I start?',
                'Choose the context that fits your work today, then define one objective. You can explore a sample workspace first, or create an account and begin with an empty workspace.',
              ],
              [
                'Can I use it with my team?',
                'The product is designed to extend into shared contexts. This initial build supports a single owner per workspace. Shared membership and delegated permissions are part of the planned enterprise expansion.',
              ],
              [
                'Does AI act on my behalf?',
                'This build uses a guided planning Companion and does not run AI or external actions. You control the actions you create, and actions marked for review require an explicit approval before completion.',
              ],
            ].map(([question, answer], i) => (
              <div className="faq-item" key={question}>
                <button
                  onClick={() => setFaq(faq === i ? null : i)}
                  aria-expanded={faq === i}
                  aria-controls={`faq-${i}`}
                >
                  {question}
                  {faq === i ? <Minus size={18} /> : <Plus size={18} />}
                </button>
                <AnimatePresence initial={false}>
                  {faq === i && (
                    <m.p
                      key={i}
                      id={`faq-${i}`}
                      initial={reduced ? false : { opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: reduced ? 0 : 0.22 }}
                      style={{ overflow: 'hidden' }}
                    >
                      {answer}
                    </m.p>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </section>
        <section className="closing-section">
          <Eyebrow>YOUR NEXT CHAPTER STARTS HERE</Eyebrow>
          <h2>
            Make space for
            <br />
            <em>meaningful progress.</em>
          </h2>
          <Cta to="/start">Start with your context</Cta>
          <span>One objective. One next step. A clearer way forward.</span>
        </section>
      </main>
      <Footer />
    </>
  );
}
