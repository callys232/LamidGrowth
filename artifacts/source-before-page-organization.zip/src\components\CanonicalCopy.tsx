import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import pages from '../content/pages.json';
import { OrbitVisual } from './Orbit';

export function sourcePage(path: string) {
  return (
    pages.find((p) => p.route === path) ||
    (path.startsWith('/os/workflows/')
      ? pages.find((p) => p.route === '/os/workflows/[id]')
      : undefined)
  );
}
const destinations: Record<string, string> = {
  'Experience LAMID ONE': '/start',
  'See How It Works': '/how-it-works',
  'Explore the Companion': '/product/companion',
  'Experience the Companion': '/os/companion',
  'View Plans': '/pricing',
  'Responsible AI': '/responsible-ai',
  'Create Account': '/signup',
  'Sign In': '/login',
  'Read Our Story': '/about/story',
  'Choose Your Context': '/start',
  'See the Operating Model': '/how-it-works',
  'Explore Integrations': '/integrations',
  'View SDKs': '/developers/sdks',
  'Read Webhook Docs': '/developers/webhooks',
  'Search Help': '/help',
  'Start the Guide': '/help/getting-started',
  'Browse Account Help': '/help/account',
  'Contact Security': '/contact',
  'Contact Accessibility': '/contact',
  'See the OS in Action': '/demo',
  'See LAMID ONE in Action': '/demo',
  'See Workflow Capability': '/product/workflows',
  'Explore LAMID ONE for Organizations': '/product/organizations',
  'Start With Clarity': '/how-it-works/clarity',
  'Experience Clarity': '/os/clarity',
  'Explore Capability': '/how-it-works/capability',
  'Build Your Rhythm': '/how-it-works/rhythm',
  'Explore the Rhythm': '/how-it-works/rhythm',
  'Start With LAMID ONE': '/start',
  'Explore LAMID ONE for Professionals': '/start',
  'Explore LAMID ONE for Creators': '/start',
  'Explore LAMID ONE for Founders': '/start',
  'Explore LAMID ONE for Teams': '/start',
  'Explore LAMID ONE for SMEs': '/start',
  'Explore LAMID ONE for Enterprise': '/enterprise',
  'Explore LAMID ONE for Institutions': '/enterprise',
  'Request an Organizational Demo': '/demo/request',
  'Talk to Our Team': '/enterprise/contact',
  Security: '/security',
  'Privacy & Data': '/trust/privacy',
  Governance: '/trust/governance',
  'Read Our AI Principles': '/responsible-ai',
  'View Data Controls': '/os/settings/privacy',
  'Explore Enterprise Platform & Deployment': '/enterprise',
  'View Plan Details': '/pricing',
  'Request a Conversation': '/enterprise/contact',
  'Explore Resources': '/resources',
  'Browse Insights': '/insights',
  'Browse Guides': '/guides',
  'Browse Case Studies': '/case-studies',
  'Explore Research': '/research',
  'Browse Product Guides': '/help/product',
  'Contact Support': '/support',
  'Read the Developer Docs': '/developers',
  'View API Reference': '/developers/api',
  'View Changelog': '/developers/changelog',
  'Explore LAMID ONE': '/product',
  'Explore Careers': '/careers',
  'Contact Media': '/press',
  'Continue to Capability': '/os/capability',
  'Continue to Consistency': '/os/consistency',
  'Enter LAMID ONE': '/os',
  'Continue to LAMID ONE': '/os',
};
function CopyLine({ text, paragraph }: { text: string; paragraph: number }) {
  if (/^(CTA:|Links?:)/.test(text)) {
    return (
      <div className="canonical-ctas" data-source-paragraph={paragraph}>
        {text
          .replace(/^(CTA:|Links?:)\s*/, '')
          .split('|')
          .map((raw, i) => {
            const label = raw.trim();
            const to = destinations[label];
            return to ? (
              <Link className="button button-primary" key={i} to={to}>
                {label}
              </Link>
            ) : (
              <span className="canonical-cta-label" key={i}>
                {label}
              </span>
            );
          })}
      </div>
    );
  }
  return <p data-source-paragraph={paragraph}>{text}</p>;
}
export function CanonicalCopy({ path, embedded = false }: { path: string; embedded?: boolean }) {
  const page = sourcePage(path);
  const [active, setActive] = useState('');
  useEffect(() => {
    setActive('');
    if (embedded || !page) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length) setActive(visible[0].target.id);
      },
      { rootMargin: '-80px 0px -55% 0px', threshold: 0 },
    );
    document
      .querySelectorAll('[data-section-anchor]')
      .forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, [page, embedded]);
  if (!page) return null;
  const Title = embedded ? 'h2' : 'h1';
  return (
    <div
      className={`canonical-copy ${embedded ? '' : 'showcase-copy'}`}
      data-source-page={page.page}
    >
      {page.gates.length > 0 && (
        <aside className="canonical-preview">
          Document preview — the complete specified copy is shown below. It does not establish that
          planned services, policies or certifications are available in this development build.
        </aside>
      )}
      <section className="content-hero section-wrap">
        <div>
          <div className="eyebrow">{page.name}</div>
          <Title data-source-paragraph={page.hero.paragraphs[0].sourceParagraph}>
            {page.title}
          </Title>
          {page.hero.paragraphs.slice(1).map((p) => (
            <CopyLine key={p.sourceParagraph} text={p.text} paragraph={p.sourceParagraph} />
          ))}
        </div>
        {!embedded && <OrbitVisual small />}
      </section>
      {!embedded && page.sections.length > 1 && (
        <nav className="section-index" aria-label="On this page">
          <span className="section-index-label">On this page</span>
          <div className="section-index-links">
            {page.sections.map((section, i) => {
              const id = `section-${section.paragraphs[0].sourceParagraph}`;
              return (
                <a
                  key={id}
                  href={`#${id}`}
                  aria-current={active === id ? 'location' : undefined}
                  onClick={() => setActive(id)}
                >
                  <span aria-hidden="true">{String(i + 1).padStart(2, '0')}</span>
                  {section.title}
                </a>
              );
            })}
          </div>
        </nav>
      )}
      <section className="editorial-sections section-wrap">
        {page.sections.map((section, i) => {
          const dense =
            section.paragraphs.length > 5 ||
            section.paragraphs.reduce((n, p) => n + p.text.length, 0) > 900;
          const closing =
            i === page.sections.length - 1 &&
            section.paragraphs.some((p) => p.text.startsWith('CTA:'));
          const layout = closing
            ? 'showcase-closing'
            : dense
              ? 'showcase-feature'
              : 'showcase-card';
          return (
            <article
              className={`editorial-section ${!embedded ? layout : i === 2 ? 'dark-section' : ''} ${!embedded && closing ? 'dark-section' : ''}`}
              id={`section-${section.paragraphs[0].sourceParagraph}`}
              data-section-anchor={!embedded ? '' : undefined}
              key={section.paragraphs[0].sourceParagraph}
            >
              <div className="section-heading">
                <span className="editorial-number">{String(i + 1).padStart(2, '0')}</span>
                <h2 data-source-paragraph={section.paragraphs[0].sourceParagraph}>
                  {section.title}
                </h2>
              </div>
              <div className="section-body">
                {section.paragraphs.slice(1).map((p) => (
                  <CopyLine key={p.sourceParagraph} text={p.text} paragraph={p.sourceParagraph} />
                ))}
              </div>
            </article>
          );
        })}
      </section>
    </div>
  );
}
