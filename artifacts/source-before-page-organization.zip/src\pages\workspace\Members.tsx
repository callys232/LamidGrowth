import { useEffect, useState, type FormEvent } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading } from '../../components/WorkspaceParts';
import { Button, Empty, Field } from '../../components/ui';

interface Member {
  userId: string;
  name: string;
  email: string;
  role: string;
  status: string;
}
export function Members() {
  const { state, notify } = useWorkspace();
  const [members, setMembers] = useState<Member[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const canManage = state.permissions.includes('members:manage');
  async function load() {
    setMembers(await api<Member[]>('/admin/members'));
  }
  useEffect(() => {
    if (!canManage) return;
    let active = true;
    api<Member[]>('/admin/members')
      .then((data) => {
        if (active) setMembers(data);
      })
      .catch((error: Error) => {
        if (active) setError(error.message);
      });
    return () => {
      active = false;
    };
  }, [canManage]);
  async function add(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    setBusy(true);
    setError('');
    try {
      await api('/admin/members', { email: new FormData(form).get('email'), role: 'member' });
      form.reset();
      await load();
      notify('Member added to this workspace.');
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function change(member: Member) {
    setBusy(true);
    setError('');
    try {
      await api(
        `/admin/members/${member.userId}`,
        { status: member.status === 'active' ? 'disabled' : 'active' },
        'PATCH',
      );
      await load();
      notify('Workspace access updated.');
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow="PEOPLE & ACCESS"
        title="People in this workspace"
        description="Manage membership and keep each person's access clear."
      />
      {!canManage ? (
        <Empty title="Managed by your workspace owner">
          Ask your workspace owner to manage membership.
        </Empty>
      ) : (
        <>
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          <section className="panel settings-card">
            <h2>
              Members · {members.filter((m) => m.status === 'active').length} /{' '}
              {state.workspace.member_limit}
            </h2>
            <p>
              Owners manage settings, exports, and review decisions. Members can create and update
              work. Disabling membership removes access to this workspace only.
            </p>
            {members.map((member) => (
              <div className="audit-event" key={member.userId}>
                <div>
                  <strong>{member.name}</strong>
                  <p>
                    {member.email} · {member.role} · {member.status}
                  </p>
                </div>
                {member.role !== 'owner' && state.workspace.tier === 'enterprise' && (
                  <Button variant="secondary" disabled={busy} onClick={() => void change(member)}>
                    {member.status === 'active' ? 'Disable access' : 'Restore access'}
                  </Button>
                )}
              </div>
            ))}
          </section>
          {state.workspace.tier === 'enterprise' ? (
            <section className="panel settings-card">
              <h2>Add an existing account</h2>
              <p>
                The person must already have a LAMID ONE account. They can select this workspace
                after being added.
              </p>
              <form onSubmit={add}>
                <Field label="Account email">
                  <input name="email" type="email" required maxLength={254} />
                </Field>
                <Button type="submit" disabled={busy}>
                  Add member
                </Button>
              </form>
            </section>
          ) : (
            <p>Shared membership is available in enterprise workspaces.</p>
          )}
        </>
      )}
    </>
  );
}
