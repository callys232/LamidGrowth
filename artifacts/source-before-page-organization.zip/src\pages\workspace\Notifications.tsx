import { useEffect, useState } from 'react';
import { api } from '../../api';
import { PageHeading } from '../../components/WorkspaceParts';
import { Button, Empty } from '../../components/ui';

interface Notice {
  id: string;
  message: string;
  createdAt: string;
  readAt: string | null;
}
export function Notifications() {
  const [items, setItems] = useState<Notice[]>([]);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    api<Notice[]>('/notifications')
      .then((items) => {
        if (active) setItems(items);
      })
      .catch((error: Error) => {
        if (active) setError(error.message);
      });
    return () => {
      active = false;
    };
  }, []);
  return (
    <>
      <PageHeading
        eyebrow="NOTIFICATIONS"
        title="Your review reminders"
        description="Reminders created by your authorized workflows."
      />
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {!items.length && (
        <Empty title="No reminders yet">
          Workflow reminders will appear here when their approved step completes.
        </Empty>
      )}
      {items.map((item) => (
        <section className="panel settings-card" key={item.id}>
          <h2>{item.message}</h2>
          <p>{new Date(item.createdAt).toLocaleString()}</p>
          {item.readAt ? (
            <p>Read</p>
          ) : (
            <Button
              onClick={() => {
                void api(`/notifications/${item.id}`, { read: true }, 'PATCH')
                  .then(() =>
                    setItems((items) =>
                      items.map((notice) =>
                        notice.id === item.id
                          ? { ...notice, readAt: new Date().toISOString() }
                          : notice,
                      ),
                    ),
                  )
                  .catch((error: Error) => setError(error.message));
              }}
            >
              Mark as read
            </Button>
          )}
        </section>
      ))}
    </>
  );
}
