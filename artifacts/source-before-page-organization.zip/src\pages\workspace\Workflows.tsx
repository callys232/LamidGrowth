import { useEffect, useRef, useState, type FormEvent } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading, StatusPill } from '../../components/WorkspaceParts';
import { Button, Empty, Field } from '../../components/ui';

interface Step {
  id: string;
  toolId: string;
  state: string;
  attempts: number;
  input: { title?: string; notes?: string; message?: string };
  output: {
    observedAt: string;
    result: { completed?: number; total?: number; action?: { title: string } };
  } | null;
}
interface Run {
  id: string;
  title: string;
  state: string;
  version: number;
  objective_id: string;
  steps: Step[];
  reason: string;
  start_at: number;
  expires_at: number;
}
const labels: Record<string, string> = {
  'context.snapshot': 'Review objective context',
  'capability.review': 'Review capability requirements',
  'action.prepare': 'Prepare a next action',
  'progress.snapshot': 'Record progress evidence',
  'review.reminder': 'Create a review reminder',
};
export function Workflows() {
  const { state, refresh, notify } = useWorkspace();
  const [runs, setRuns] = useState<Run[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const requests = useRef(0);
  const mutating = useRef(false);
  const canManage = state.permissions.includes('workspace:manage');
  async function load() {
    const sequence = ++requests.current;
    const data = await api<Run[]>('/workflows');
    if (sequence === requests.current) setRuns(data);
  }
  useEffect(() => {
    let active = true;
    let pending = false;
    const poll = async () => {
      if (pending || mutating.current) return;
      pending = true;
      const sequence = ++requests.current;
      try {
        const data = await api<Run[]>('/workflows');
        if (active && sequence === requests.current) setRuns(data);
      } catch (error) {
        if (active) setError((error as Error).message);
      } finally {
        pending = false;
      }
    };
    void poll();
    const timer = setInterval(() => {
      if (!document.hidden) void poll();
    }, 4000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = event.currentTarget;
    const data = new FormData(form);
    const nextAction = String(data.get('nextAction')).trim();
    const steps = [
      { id: 'context', toolId: 'context.snapshot', input: {}, dependsOn: [] },
      { id: 'capability', toolId: 'capability.review', input: {}, dependsOn: ['context'] },
      ...(nextAction
        ? [
            {
              id: 'action',
              toolId: 'action.prepare',
              input: { title: nextAction },
              dependsOn: ['capability'],
            },
          ]
        : []),
      {
        id: 'progress',
        toolId: 'progress.snapshot',
        input: {},
        dependsOn: [nextAction ? 'action' : 'capability'],
      },
      {
        id: 'reminder',
        toolId: 'review.reminder',
        input: { message: String(data.get('reminder')) },
        dependsOn: ['progress'],
      },
    ];
    try {
      await api('/workflows', {
        title: data.get('title'),
        objectiveId: data.get('objectiveId'),
        steps,
        ...(data.get('startAt')
          ? { startAt: new Date(String(data.get('startAt'))).toISOString() }
          : {}),
        expiresAt: new Date(Date.now() + Number(data.get('days')) * 86400000).toISOString(),
      });
      form.reset();
      await load();
      notify('Workflow saved. Review its steps before starting.');
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function command(run: Run, command: string) {
    setBusy(true);
    mutating.current = true;
    ++requests.current;
    setError('');
    try {
      await api(
        `/workflows/${run.id}`,
        {
          version: run.version,
          command,
          ...(command === 'approve'
            ? { objectiveVersion: state.objectives.find((o) => o.id === run.objective_id)?.version }
            : {}),
        },
        'PATCH',
      );
      await load();
      await refresh();
    } catch (error) {
      setError((error as Error).message);
      await load().catch(() => {});
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
      mutating.current = false;
    }
  }
  return (
    <>
      <PageHeading
        eyebrow="WORKFLOWS"
        title="Work that carries forward"
        description="Schedule a bounded sequence, review each change, and see what happened."
      />
      <p>
        Workflows continue while the application server is running. Each change waits for your
        approval. Pausing or cancelling stops future steps; completed changes remain in your
        workspace.
      </p>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {canManage && state.objectives.some((o) => o.status !== 'Complete') && (
        <details className="panel settings-card">
          <summary>Create a workflow</summary>
          <form onSubmit={create}>
            <Field label="Workflow name">
              <input name="title" required maxLength={500} />
            </Field>
            <Field label="Connected objective">
              <select name="objectiveId">
                {state.objectives
                  .filter((o) => o.status !== 'Complete')
                  .map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.title}
                    </option>
                  ))}
              </select>
            </Field>
            <Field label="Next action to prepare (optional)">
              <input name="nextAction" maxLength={500} />
            </Field>
            <Field label="Review reminder">
              <input
                name="reminder"
                required
                maxLength={500}
                defaultValue="Review the outcome and decide what comes next."
              />
            </Field>
            <Field label="Scheduled start (optional)">
              <input name="startAt" type="datetime-local" />
            </Field>
            <Field label="Authorization expires after">
              <select name="days">
                <option value="1">1 day</option>
                <option value="7">7 days</option>
                <option value="30">30 days</option>
              </select>
            </Field>
            <p>
              The sequence reviews recorded context and requirements, optionally prepares an action,
              records a progress snapshot, and creates a reminder. Context reviews use your recorded
              inputs.
            </p>
            <Button type="submit" disabled={busy}>
              Save workflow draft
            </Button>
          </form>
        </details>
      )}
      {!runs.length && (
        <Empty title="No workflows yet">
          Create an objective, then schedule its next operating cycle.
        </Empty>
      )}
      {runs.map((run) => (
        <section className="panel settings-card" key={run.id}>
          <h2>{run.title}</h2>
          <StatusPill status={run.state.replaceAll('_', ' ')} />
          <p>{state.objectives.find((o) => o.id === run.objective_id)?.title}</p>
          <details>
            <summary>Review current objective context</summary>
            <p>{state.objectives.find((o) => o.id === run.objective_id)?.description}</p>
            <p>
              Success:{' '}
              {state.objectives.find((o) => o.id === run.objective_id)?.success || 'Not recorded'}
            </p>
            <p>
              Constraints:{' '}
              {state.objectives.find((o) => o.id === run.objective_id)?.constraints ||
                'Not recorded'}
            </p>
          </details>
          <p>
            Starts {new Date(run.start_at).toLocaleString()} · Expires{' '}
            {new Date(run.expires_at).toLocaleString()}
          </p>
          {run.reason && <p role="status">{run.reason}</p>}
          <ol>
            {run.steps.map((step) => (
              <li key={step.id}>
                <strong>{labels[step.toolId] || step.toolId}</strong> · {step.state}
                {step.input.title && <p>Action: {step.input.title}</p>}
                {step.input.notes && <p>{step.input.notes}</p>}
                {step.input.message && <p>Reminder: {step.input.message}</p>}
                {step.output && (
                  <p>
                    Recorded {new Date(step.output.observedAt).toLocaleString()}
                    {step.output.result.total !== undefined &&
                      ` · ${step.output.result.completed} of ${step.output.result.total} actions complete`}
                    {step.output.result.action && ` · Created “${step.output.result.action.title}”`}
                  </p>
                )}
              </li>
            ))}
          </ol>
          {canManage && (
            <div className="modal-actions">
              {run.state === 'draft' && (
                <Button disabled={busy} onClick={() => void command(run, 'start')}>
                  Start workflow
                </Button>
              )}
              {run.state === 'needs_approval' && (
                <Button disabled={busy} onClick={() => void command(run, 'approve')}>
                  Approve next step
                </Button>
              )}
              {['running', 'needs_approval'].includes(run.state) && (
                <Button
                  variant="secondary"
                  disabled={busy}
                  onClick={() => void command(run, 'pause')}
                >
                  Pause workflow
                </Button>
              )}
              {run.state === 'paused' && (
                <Button disabled={busy} onClick={() => void command(run, 'resume')}>
                  Resume workflow
                </Button>
              )}
              {run.state === 'failed' && (
                <Button disabled={busy} onClick={() => void command(run, 'retry')}>
                  Retry failed step
                </Button>
              )}
              {!['completed', 'cancelled', 'expired'].includes(run.state) && (
                <Button
                  variant="secondary"
                  disabled={busy}
                  onClick={() => void command(run, 'cancel')}
                >
                  Cancel workflow
                </Button>
              )}
            </div>
          )}
        </section>
      ))}
    </>
  );
}
