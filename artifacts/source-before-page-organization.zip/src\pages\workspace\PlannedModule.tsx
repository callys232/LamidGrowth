import { ArrowRight } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Empty } from '../../components/ui';

import { PageHeading } from '../../components/WorkspaceParts';
export function PlannedModule() {
  const location = useLocation();
  return (
    <>
      <PageHeading
        eyebrow="PRODUCT ROADMAP"
        title="This part of the journey is ahead."
        description="This surface is included in the product specification and has not been implemented yet."
      />
      <Empty
        title="Build on the working foundation."
        action={
          <Link className="button button-primary" to="/os">
            Return to your workspace <ArrowRight size={15} />
          </Link>
        }
      >
        You can use objectives, action tracking, guided planning, review, and activity history
        today. Requested surface: {location.pathname}.
      </Empty>
    </>
  );
}
