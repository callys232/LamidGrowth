import { useEffect, useState, type FormEvent } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading } from '../../components/WorkspaceParts';
import { Button, Empty, Field, Modal } from '../../components/ui';

interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  objectiveId: string | null;
  sourceType: 'note' | 'text-file';
  sourceName: string;
  classification: 'workspace' | 'confidential';
  version: number;
  observedAt: string;
  contentHash: string;
}
export function Knowledge() {
  const { state } = useWorkspace();
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [total, setTotal] = useState(0),
    [offset, setOffset] = useState(0);
  const [query, setQuery] = useState(''),
    [error, setError] = useState('');
  const [selected, setSelected] = useState<KnowledgeItem | 'new' | null>(null);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    let active = true;
    const timer = setTimeout(() => {
      api<{ items: KnowledgeItem[]; total: number }>(
        `/knowledge?q=${encodeURIComponent(query)}&offset=${offset}`,
      )
        .then((data) => {
          if (active) {
            setItems(data.items);
            setTotal(data.total);
            setError('');
          }
        })
        .catch((error: Error) => {
          if (active) setError(error.message);
        });
    }, 200);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [query, offset, revision]);
  return (
    <>
      <PageHeading
        eyebrow="KNOWLEDGE"
        title="Context you can inspect"
        description="Keep source notes and text documents connected to your objectives."
      >
        <Button onClick={() => setSelected('new')}>Add knowledge</Button>
      </PageHeading>
      <p>
        Knowledge is shared with active members of this workspace. Classification labels describe
        sensitivity; they do not create separate access permissions.
      </p>
      <Field label="Search knowledge">
        <input
          value={query}
          maxLength={200}
          onChange={(e) => {
            setQuery(e.target.value);
            setOffset(0);
          }}
        />
      </Field>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {!items.length && (
        <Empty title="No matching knowledge">Add a note or import a small text document.</Empty>
      )}
      {items.map((item) => (
        <section className="panel settings-card" key={item.id}>
          <h2>{item.title}</h2>
          <p>
            {item.content.slice(0, 300)}
            {item.content.length > 300 ? '…' : ''}
          </p>
          <p>
            {item.sourceName || 'Workspace note'} · {item.classification} · Version {item.version} ·{' '}
            {new Date(item.observedAt).toLocaleString()}
          </p>
          {item.objectiveId && (
            <p>Objective: {state.objectives.find((o) => o.id === item.objectiveId)?.title}</p>
          )}
          <Button variant="secondary" onClick={() => setSelected(item)}>
            Read and edit
          </Button>
        </section>
      ))}
      <div className="modal-actions">
        <Button
          variant="secondary"
          disabled={!offset}
          onClick={() => setOffset(Math.max(0, offset - 50))}
        >
          Previous
        </Button>
        <span>{total} records</span>
        <Button
          variant="secondary"
          disabled={offset + 50 >= total}
          onClick={() => setOffset(offset + 50)}
        >
          Next
        </Button>
      </div>
      {selected && (
        <KnowledgeEditor
          item={selected === 'new' ? undefined : selected}
          onClose={() => setSelected(null)}
          onSaved={() => {
            setSelected(null);
            setRevision((n) => n + 1);
          }}
        />
      )}
    </>
  );
}

function KnowledgeEditor({
  item,
  onClose,
  onSaved,
}: {
  item?: KnowledgeItem;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { state } = useWorkspace();
  const [content, setContent] = useState(item?.content || '');
  const [sourceName, setSourceName] = useState(item?.sourceName || '');
  const [sourceType, setSourceType] = useState(item?.sourceType || 'note');
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const [deleting, setDeleting] = useState(false);
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      await api(
        item ? `/knowledge/${item.id}` : '/knowledge',
        {
          ...data,
          content,
          sourceType,
          sourceName,
          objectiveId: data.objectiveId || null,
          ...(item ? { version: item.version } : {}),
        },
        item ? 'PATCH' : 'POST',
      );
      onSaved();
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title={item ? 'Review knowledge' : 'Add workspace knowledge'} onClose={onClose} wide>
      <form onSubmit={save}>
        <Field label="Knowledge title">
          <input name="title" required maxLength={200} defaultValue={item?.title} />
        </Field>
        <Field label="Import plain text (optional)">
          <input
            type="file"
            accept=".txt,.md,.csv,text/plain,text/markdown,text/csv"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              if (!file) return;
              if (!/\.(txt|md|csv)$/i.test(file.name) || file.size > 20000) {
                setError('Choose a TXT, MD, or CSV file no larger than 20 KB.');
                return;
              }
              try {
                const text = await file.text();
                if (text.includes('\u0000') || text.includes('\ufffd'))
                  throw new Error('Use a UTF-8 text file.');
                setContent(text);
                setSourceName(file.name);
                setSourceType('text-file');
                setError('');
              } catch (error) {
                setError((error as Error).message);
              }
            }}
          />
        </Field>
        <Field label="Knowledge content">
          <textarea
            rows={10}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
            maxLength={20000}
          />
        </Field>
        <Field label="Connected objective">
          <select name="objectiveId" defaultValue={item?.objectiveId || ''}>
            <option value="">Workspace context</option>
            {state.objectives.map((o) => (
              <option key={o.id} value={o.id}>
                {o.title}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Classification">
          <select name="classification" defaultValue={item?.classification || 'workspace'}>
            <option value="workspace">Workspace</option>
            <option value="confidential">Confidential</option>
          </select>
        </Field>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <div className="modal-actions">
          <Button type="submit" disabled={busy}>
            Save knowledge
          </Button>
          {item && (
            <Button variant="secondary" disabled={busy} onClick={() => setDeleting(true)}>
              Delete knowledge
            </Button>
          )}
        </div>
        {deleting && item && (
          <div role="alert">
            <p>
              Delete this knowledge record? Its text will be removed. The activity trail retains the
              record ID.
            </p>
            <Button
              disabled={busy}
              onClick={() => {
                setBusy(true);
                void api(`/knowledge/${item.id}`, { version: item.version }, 'DELETE')
                  .then(onSaved)
                  .catch((error: Error) => setError(error.message))
                  .finally(() => setBusy(false));
              }}
            >
              Confirm deletion
            </Button>
          </div>
        )}
      </form>
    </Modal>
  );
}
