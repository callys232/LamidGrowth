import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
test('generator preserves every page paragraph without clipping or prefix filtering', () => {
  const lines = readFileSync('document-study/website.txt', 'utf8')
    .replace(/^\uFEFF/, '')
    .split(/\r?\n/)
    .filter(Boolean)
    .map((x) => x.replace(/^\[\d+\]\s*/, ''));
  const pages = JSON.parse(readFileSync('src/content/pages.json', 'utf8'));
  assert.equal(pages.length, 98);
  for (const [index, page] of pages.entries()) {
    const start = page.source_paragraph - 1;
    const end = pages[index + 1]
      ? pages[index + 1].source_paragraph - 1
      : lines.indexOf('APPENDIX - FINAL LAUNCH ACCEPTANCE CHECK');
    const block = lines.slice(start, end);
    const expected = block
      .slice(block.indexOf('HERO') + 1)
      .filter((x) => !/^SECTION(?:\s|$)/.test(x));
    assert.deepEqual(
      page.blocks.flatMap((b) => b.paragraphs.map((p) => p.text)),
      expected,
      page.route,
    );
  }
});
