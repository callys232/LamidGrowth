import { ArrowUpRight, LoaderCircle, Orbit, X } from 'lucide-react';
import type { ReactNode } from 'react';
import { Children, cloneElement, isValidElement, useEffect, useId, useRef } from 'react';
import { Link } from 'react-router-dom';
import { m, useReducedMotion } from 'motion/react';
import { MotionSurface } from './Motion';
export function Brand({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <Link className={`brand ${light ? 'brand-light' : ''}`} to="/" aria-label="LAMID ONE home">
      <span className="brand-mark">
        <span />
      </span>
      <span>
        LAMID <b>ONE</b>
        {!compact && <small>HUMAN JUDGMENT. INFINITE POSSIBILITY.</small>}
      </span>
    </Link>
  );
}
export function Eyebrow({ children }: { children: ReactNode }) {
  return <div className="eyebrow">{children}</div>;
}
export function Button({
  children,
  onClick,
  variant = 'primary',
  disabled = false,
  type = 'button',
  className = '',
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'light';
  disabled?: boolean;
  type?: 'button' | 'submit';
  className?: string;
}) {
  const reduced = useReducedMotion();
  return (
    <m.button
      type={type}
      className={`button button-${variant} ${className}`}
      onClick={onClick}
      disabled={disabled}
      whileTap={reduced || disabled ? undefined : { scale: 0.985 }}
    >
      {children}
    </m.button>
  );
}
export function Cta({
  children,
  to,
  secondary = false,
}: {
  children: ReactNode;
  to: string;
  secondary?: boolean;
}) {
  return (
    <Link className={`button button-${secondary ? 'secondary' : 'primary'}`} to={to}>
      {children}
      <ArrowUpRight size={16} />
    </Link>
  );
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" size={28} />
      <span>Bringing your context together…</span>
    </div>
  );
}
export function Empty({
  title,
  children,
  action,
}: {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <Orbit size={32} strokeWidth={1} />
      <h3>{title}</h3>
      <p>{children}</p>
      {action}
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    dialog?.showModal();
    return () => {
      dialog?.close();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={`modal ${wide ? 'modal-wide' : ''}`}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      aria-label={title}
    >
      <MotionSurface className="modal-inner">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="icon-button" onClick={onClose} aria-label="Close dialog">
            <X size={20} />
          </button>
        </div>
        {children}
      </MotionSurface>
    </dialog>
  );
}
export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  const id = useId();
  const attach = (nodes: ReactNode): ReactNode =>
    Children.map(nodes, (child) => {
      if (
        !isValidElement<{ children?: ReactNode; id?: string; 'aria-describedby'?: string }>(child)
      )
        return child;
      if (['input', 'textarea', 'select'].includes(String(child.type)))
        return cloneElement(child, { id, 'aria-describedby': hint ? `${id}-hint` : undefined });
      return child.props.children ? cloneElement(child, {}, attach(child.props.children)) : child;
    });
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {attach(children)}
      {hint && <small id={`${id}-hint`}>{hint}</small>}
    </div>
  );
}
export const contexts = [
  'Individual',
  'Professional',
  'Creator',
  'Founder',
  'Team',
  'SME',
  'Enterprise',
  'Institution',
] as const;
export function dateLabel(value: string) {
  if (!value) return 'No date';
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(
    new Date(`${value}T12:00:00`),
  );
}
