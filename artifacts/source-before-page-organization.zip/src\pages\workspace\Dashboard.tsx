import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  GitBranch,
  Plus,
  ShieldCheck,
  Sparkles,
  Target,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Empty, Eyebrow } from '../../components/ui';

import { ActionRow, ObjectiveCard, PageHeading } from '../../components/WorkspaceParts';
export function Dashboard() {
  const { state, newObjective, newAction } = useWorkspace();
  const pending = state.actions.filter((a) => a.status === 'Needs review');
  const done = state.actions.filter((a) => a.status === 'Done').length;
  const active = state.objectives.filter((o) => o.status === 'Active');
  const next = state.actions.filter((a) => a.status !== 'Done' && a.status !== 'Paused');
  return (
    <>
      <PageHeading
        eyebrow={new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' })
          .format(new Date())
          .toUpperCase()}
        title={`A little clearer, ${state.user.name.split(' ')[0]}.`}
        description="Here’s where things stand. Let’s make the next step count."
      >
        <Button onClick={newObjective}>
          <Plus size={16} /> New objective
        </Button>
      </PageHeading>
      <section className="dashboard-intro">
        <div className="focus-panel">
          <div className="focus-copy">
            <Eyebrow>
              <span className="live-dot" /> YOUR NEXT CHAPTER
            </Eyebrow>
            <h2>
              {active.length
                ? 'Meaningful progress.\nOne clear step at a time.'
                : 'Every next chapter\nstarts with a clear intent.'}
            </h2>
            <p>
              {active.length
                ? `You’re working toward ${active.length} ${active.length === 1 ? 'objective' : 'objectives'}. Keep your priorities close, and your next action closer.`
                : 'Bring an objective into focus. Connect the context, define success, and make your next move.'}
            </p>
            <Link to="/os/companion" className="button button-light">
              <Sparkles size={15} /> Think it through with Companion <ArrowUpRight size={15} />
            </Link>
          </div>
          <div className="focus-orbit" aria-hidden="true">
            <div />
            <div />
            <div />
            <span>ONE</span>
            <i />
          </div>
          <span className="focus-footnote">YOUR CONTEXT. YOUR DIRECTION.</span>
        </div>
        <div className="judgment-panel">
          <div>
            <span className="judgment-icon">
              <ShieldCheck size={20} />
            </span>
            <span className="tag">HUMAN JUDGMENT</span>
          </div>
          <h3>
            {pending.length ? 'Your perspective\nmakes the difference.' : 'You’re in control.'}
          </h3>
          <p>
            {pending.length
              ? `${pending.length} ${pending.length === 1 ? 'action is' : 'actions are'} ready for your review. A small decision can unlock the next step.`
              : 'Nothing is waiting for approval. Keep building at your own pace.'}
          </p>
          <Link to="/os/governance">
            {pending.length ? 'Review what needs you' : 'See your activity'}
            <ArrowRight size={17} />
          </Link>
        </div>
      </section>
      <div className="stat-grid">
        {[
          {
            label: 'Active objectives',
            value: active.length,
            detail: 'A direction worth moving toward',
            icon: Target,
          },
          {
            label: 'Actions in motion',
            value: state.actions.filter((a) => a.status === 'In progress').length,
            detail: 'Intent, turning into execution',
            icon: GitBranch,
          },
          {
            label: 'Actions completed',
            value: done,
            detail: 'Each step builds on the last',
            icon: CheckCircle2,
          },
          {
            label: 'Reflections recorded',
            value: state.reviews.length,
            detail: 'Learning that carries forward',
            icon: CalendarDays,
          },
        ].map(({ label, value, detail, icon: Icon }) => (
          <div className="stat-card" key={label}>
            <div>
              <span>{label}</span>
              <Icon size={17} />
            </div>
            <strong>{value.toString().padStart(2, '0')}</strong>
            <small>{detail}</small>
          </div>
        ))}
      </div>
      <section className="dashboard-section">
        <div className="panel-heading">
          <div>
            <h2>Your focus</h2>
            <span>The outcomes behind your work.</span>
          </div>
          <Link to="/os/clarity">
            All objectives <ArrowUpRight size={15} />
          </Link>
        </div>
        {active.length ? (
          <div className="objective-grid">
            {active.slice(0, 3).map((o) => (
              <ObjectiveCard key={o.id} objective={o} />
            ))}
          </div>
        ) : (
          <Empty
            title="What matters to you right now?"
            action={
              <Button onClick={newObjective}>
                <Plus size={15} /> Create your first objective
              </Button>
            }
          >
            Start with one meaningful outcome. The rest can take shape around it.
          </Empty>
        )}
      </section>
      <div className="dashboard-bottom">
        <section className="panel next-actions">
          <div className="panel-heading">
            <div>
              <h2>Make your next move</h2>
              <span>Small steps. Connected to the bigger picture.</span>
            </div>
            <button className="icon-button" aria-label="Add action" onClick={() => newAction()}>
              <Plus size={19} />
            </button>
          </div>
          {next.length ? (
            next.slice(0, 4).map((a) => <ActionRow key={a.id} action={a} />)
          ) : (
            <Empty title="A little room to begin">
              Add an action to move an objective forward.
            </Empty>
          )}
          <Link className="panel-bottom-link" to="/os/consistency">
            See all your actions <ArrowRight size={15} />
          </Link>
        </section>
        <section className="rhythm-nudge">
          <div className="rhythm-nudge-icon">
            <CalendarDays size={23} />
          </div>
          <Eyebrow>BUILD YOUR RHYTHM</Eyebrow>
          <h3>
            A moment to reflect.
            <br />
            <em>A better next week.</em>
          </h3>
          <p>
            What moved forward? What did you learn? Carry the useful parts into your next cycle.
          </p>
          <Link to="/os/rhythm">
            Start a reflection <ArrowRight size={16} />
          </Link>
        </section>
      </div>
    </>
  );
}
