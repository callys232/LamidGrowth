import { ArrowUpRight, Plus } from 'lucide-react';
import { useState } from 'react';
import { ObjectiveEditor } from '../../components/ObjectiveEditor';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Empty } from '../../components/ui';

import { ObjectiveCard, PageHeading } from '../../components/WorkspaceParts';
export function Clarity() {
  const { state, newObjective } = useWorkspace();
  const [filter, setFilter] = useState('All');
  const [selectedId, setSelected] = useState<string | null>(null);
  const selected = state.objectives.find((objective) => objective.id === selectedId);
  return (
    <>
      <PageHeading
        eyebrow="CLARITY · UNDERSTAND WHAT MATTERS"
        title="Give your ambition a direction."
        description="Bring objectives, context, and the conditions for success into one view."
      >
        <Button onClick={newObjective}>
          <Plus size={16} /> New objective
        </Button>
      </PageHeading>
      <div className="view-toolbar">
        <div className="segmented">
          {['All', 'High', 'Medium', 'Low'].map((x) => (
            <button
              className={filter === x ? 'selected' : ''}
              onClick={() => setFilter(x)}
              key={x}
              aria-pressed={filter === x}
            >
              {x === 'All' ? 'All objectives' : `${x} priority`}
            </button>
          ))}
        </div>
        <span>{state.objectives.length} objectives</span>
      </div>
      <div className="objective-grid clarity-grid">
        {state.objectives
          .filter((o) => filter === 'All' || o.priority === filter)
          .map((o) => (
            <div key={o.id}>
              <ObjectiveCard objective={o} />
              <button className="objective-context-link" onClick={() => setSelected(o.id)}>
                View context & success criteria <ArrowUpRight size={14} />
              </button>
            </div>
          ))}
      </div>
      {!state.objectives.length && (
        <Empty
          title="Clarity begins with a question."
          action={<Button onClick={newObjective}>Define your first objective</Button>}
        >
          What would meaningful progress look like for you?
        </Empty>
      )}
      {state.objectives.length > 0 &&
        !state.objectives.some((o) => filter === 'All' || o.priority === filter) && (
          <Empty title="No objectives at this priority">
            Choose another priority to see your work.
          </Empty>
        )}
      {selected && <ObjectiveEditor objective={selected} onClose={() => setSelected(null)} />}
    </>
  );
}
