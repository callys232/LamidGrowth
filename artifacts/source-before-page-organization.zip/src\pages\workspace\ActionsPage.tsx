import { CalendarDays, Plus, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Empty, dateLabel } from '../../components/ui';
import type { Status } from '../../types';

import { ActionDetail, ActionRow, PageHeading, StatusPill } from '../../components/WorkspaceParts';
export function ActionsPage({
  today = false,
  workflows = false,
}: {
  today?: boolean;
  workflows?: boolean;
}) {
  const { state, newAction } = useWorkspace();
  const [filter, setFilter] = useState('All');
  const [view, setView] = useState<'list' | 'board'>(workflows ? 'board' : 'list');
  const [selectedId, setSelected] = useState<string | null>(null);
  const selected = state.actions.find((action) => action.id === selectedId);
  const currentDate = new Date().toLocaleDateString('en-CA');
  const actions = state.actions.filter(
    (a) =>
      (!today ||
        a.status === 'Needs review' ||
        (a.status !== 'Done' && a.status !== 'Paused' && a.dueDate && a.dueDate <= currentDate)) &&
      (filter === 'All' || a.status === filter),
  );
  const statuses: Status[] = ['Planned', 'In progress', 'Needs review', 'Done', 'Paused'];
  return (
    <>
      <PageHeading
        eyebrow={
          today
            ? 'TODAY · A DELIBERATE NEXT STEP'
            : workflows
              ? 'WORKFLOWS · WORK AROUND THE OUTCOME'
              : 'CONSISTENCY · INTENT INTO ACTION'
        }
        title={
          today
            ? 'Make room for what matters.'
            : workflows
              ? 'See how the work moves.'
              : 'Keep the important work moving.'
        }
        description={
          today
            ? 'Your due actions and anything waiting for your judgment.'
            : 'Clear ownership, connected objectives, and visible review. One action at a time.'
        }
      >
        <Button onClick={() => newAction()}>
          <Plus size={16} /> Add action
        </Button>
      </PageHeading>
      <div className="view-toolbar">
        <label className="inline-select">
          Status
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option>All</option>
            {statuses.map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </label>
        <div className="segmented">
          <button
            onClick={() => setView('list')}
            className={view === 'list' ? 'selected' : ''}
            aria-pressed={view === 'list'}
          >
            List
          </button>
          <button
            onClick={() => setView('board')}
            className={view === 'board' ? 'selected' : ''}
            aria-pressed={view === 'board'}
          >
            Board
          </button>
        </div>
      </div>
      {actions.length === 0 ? (
        <Empty
          title={today ? 'A little breathing room.' : 'Your next move starts here.'}
          action={
            <Button variant="secondary" onClick={() => newAction()}>
              Add an action <Plus size={15} />
            </Button>
          }
        >
          {today
            ? 'No actions are due or waiting for review. You can plan your next step.'
            : 'No actions match this view. Add a step or change the status filter.'}
        </Empty>
      ) : view === 'list' ? (
        <section className="panel action-list">
          {actions.map((a) => (
            <ActionRow action={a} key={a.id} />
          ))}
        </section>
      ) : (
        <div className="kanban">
          {statuses
            .filter((status) => filter === 'All' || status === filter)
            .map((status) => (
              <section className="kanban-column" key={status}>
                <div className="kanban-heading">
                  <StatusPill status={status} />
                  <span>{actions.filter((a) => a.status === status).length}</span>
                </div>
                {actions
                  .filter((a) => a.status === status)
                  .map((action) => (
                    <button
                      className="kanban-card"
                      key={action.id}
                      onClick={() => setSelected(action.id)}
                    >
                      <small>
                        {state.objectives.find((o) => o.id === action.objectiveId)?.title}
                      </small>
                      <h3>{action.title}</h3>
                      <p>{action.notes || 'Open to review this action.'}</p>
                      <div>
                        <span>
                          <CalendarDays size={12} />
                          {dateLabel(action.dueDate)}
                        </span>
                        {action.requiresApproval && <ShieldCheck size={14} />}
                        <span className="avatar avatar-tiny">{action.owner[0]}</span>
                      </div>
                    </button>
                  ))}
                {!actions.some((a) => a.status === status) && (
                  <p className="kanban-empty">Room for what comes next.</p>
                )}
              </section>
            ))}
        </div>
      )}
      {selected && <ActionDetail action={selected} onClose={() => setSelected(null)} />}
    </>
  );
}
