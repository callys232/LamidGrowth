import { useEffect, useRef, useState, type FormEvent } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading } from '../../components/WorkspaceParts';
import { Button, Empty, Field, Modal } from '../../components/ui';

interface Job {
  id: string;
  title: string;
  category: string;
  project_type: string;
  description: string;
  deliverables: string;
  budget_min: number;
  budget_max: number;
  currency: string;
  timeline: string;
  client_user_id: string;
}
interface Bid {
  id: string;
  cover_letter: string;
  proposed_amount: number;
  currency: string;
  timeline: string;
}
interface Proposal {
  id: string;
  title: string;
  scope: string;
  deliverables: string;
  amount: number;
  currency: string;
  status: string;
}
interface Options {
  categories: string[];
  projectTypes: string[];
  jobPostCost: number;
  bidCost: number;
}

export function Commercial() {
  const { state } = useWorkspace();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [options, setOptions] = useState<Options | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [view, setView] = useState<'workspace' | 'marketplace'>('workspace');
  const [query, setQuery] = useState('');
  const [offset, setOffset] = useState(0);
  const [error, setError] = useState('');
  const [creating, setCreating] = useState(false);
  const [selected, setSelected] = useState<Job | null>(null);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    let active = true;
    Promise.all([
      api<Options>('/job-options'),
      api<{ balance: number }>('/points'),
      api<Job[]>(
        view === 'workspace'
          ? '/jobs'
          : `/marketplace/jobs?q=${encodeURIComponent(query)}&offset=${offset}`,
      ),
    ])
      .then(([options, points, jobs]) => {
        if (active) {
          setOptions(options);
          setBalance(points.balance);
          setJobs(jobs);
          setError('');
        }
      })
      .catch((error: Error) => {
        if (active) setError(error.message);
      });
    return () => {
      active = false;
    };
  }, [view, query, offset, revision]);
  return (
    <>
      <PageHeading
        eyebrow="COMMERCIAL WORK"
        title="From a clear brief to a proposal"
        description="Post scoped work, compare bids, and prepare proposal drafts."
      >
        <Button onClick={() => setCreating(true)} disabled={!options}>
          Post a job
        </Button>
      </PageHeading>
      <p>
        {balance ?? '…'} development points available. Posting costs {options?.jobPostCost ?? 10};
        bidding costs {options?.bidCost ?? 2}. Points are an internal usage allowance. Proposals are
        drafts and create no contract or payment.
      </p>
      <div className="view-toolbar">
        <div className="segmented">
          <button
            aria-pressed={view === 'workspace'}
            onClick={() => {
              setView('workspace');
              setOffset(0);
            }}
          >
            Workspace posts
          </button>
          <button
            aria-pressed={view === 'marketplace'}
            disabled={state.user.demo}
            onClick={() => {
              setView('marketplace');
              setOffset(0);
            }}
          >
            Open opportunities
          </button>
        </div>
        {view === 'marketplace' && (
          <Field label="Search opportunities">
            <input
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setOffset(0);
              }}
              maxLength={200}
            />
          </Field>
        )}
      </div>
      {state.user.demo && (
        <p>
          Sample posts stay within this sample workspace. Create an account to participate in open
          opportunities.
        </p>
      )}
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {!jobs.length && (
        <Empty title="No matching work yet">
          Start with a clear brief or explore another search.
        </Empty>
      )}
      <div className="objective-grid">
        {jobs.map((job) => (
          <section className="panel settings-card" key={job.id}>
            <span className="tag">{job.category}</span>
            <h2>{job.title}</h2>
            <p>{job.description}</p>
            <p>
              {job.budget_min}–{job.budget_max} {job.currency} · {job.timeline}
            </p>
            <Button variant="secondary" onClick={() => setSelected(job)}>
              View job
            </Button>
          </section>
        ))}
      </div>
      {view === 'marketplace' && (
        <div className="modal-actions">
          <Button
            variant="secondary"
            disabled={offset === 0}
            onClick={() => setOffset(Math.max(0, offset - 50))}
          >
            Previous
          </Button>
          <Button
            variant="secondary"
            disabled={jobs.length < 50}
            onClick={() => setOffset(offset + 50)}
          >
            Next
          </Button>
        </div>
      )}
      {creating && options && (
        <JobForm
          options={options}
          demo={state.user.demo}
          onClose={() => setCreating(false)}
          onSaved={() => {
            setCreating(false);
            setRevision((n) => n + 1);
          }}
        />
      )}
      {selected && (
        <JobDetail
          job={selected}
          owner={selected.client_user_id === state.user.id}
          onClose={() => setSelected(null)}
          onSaved={() => setRevision((n) => n + 1)}
        />
      )}
    </>
  );
}

function JobForm({
  options,
  demo,
  onClose,
  onSaved,
}: {
  options: Options;
  demo: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const key = useRef(crypto.randomUUID());
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      await api(
        '/jobs',
        { ...data, budgetMin: Number(data.budgetMin), budgetMax: Number(data.budgetMax) },
        'POST',
        key.current,
      );
      onSaved();
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="Post a scoped job" onClose={onClose}>
      <p>
        {demo
          ? 'This post stays in your sample workspace.'
          : 'This post will be visible to signed-in accounts in open opportunities.'}{' '}
        Posting uses {options.jobPostCost} points.
      </p>
      <form
        onSubmit={save}
        onChange={() => {
          key.current = crypto.randomUUID();
        }}
      >
        <Field label="Job title">
          <input name="title" required maxLength={500} />
        </Field>
        <Field label="Category">
          <select name="category">
            {options.categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Project type">
          <select name="projectType">
            {options.projectTypes.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Project description">
          <textarea name="description" required minLength={20} maxLength={10000} rows={3} />
        </Field>
        <Field label="Deliverables">
          <textarea name="deliverables" required maxLength={5000} />
        </Field>
        <div className="form-grid">
          <Field label="Minimum budget">
            <input
              name="budgetMin"
              type="number"
              min={0}
              max={100000000}
              required
              defaultValue={0}
            />
          </Field>
          <Field label="Maximum budget">
            <input name="budgetMax" type="number" min={1} max={100000000} required />
          </Field>
        </div>
        <Field label="Currency">
          <input name="currency" defaultValue="USD" pattern="[A-Z]{3}" required maxLength={3} />
        </Field>
        <Field label="Timeline">
          <input name="timeline" required maxLength={200} />
        </Field>
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <Button type="submit" disabled={busy}>
          Post job · {options.jobPostCost} points
        </Button>
      </form>
    </Modal>
  );
}

function JobDetail({
  job,
  owner,
  onClose,
  onSaved,
}: {
  job: Job;
  owner: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [bids, setBids] = useState<Bid[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [bidId, setBidId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const bidKey = useRef(crypto.randomUUID()),
    proposalKey = useRef(crypto.randomUUID());
  useEffect(() => {
    let active = true;
    if (owner)
      Promise.all([
        api<Bid[]>(`/jobs/${job.id}/bids`),
        api<Proposal[]>(`/jobs/${job.id}/proposals`),
      ])
        .then(([bids, proposals]) => {
          if (active) {
            setBids(bids);
            setProposals(proposals);
          }
        })
        .catch((error: Error) => {
          if (active) setError(error.message);
        });
    else
      api<Array<Bid & { job_id: string }>>('/bids/mine')
        .then(async (bids) => {
          const own = bids.find((bid) => bid.job_id === job.id);
          if (own && active) {
            setBidId(own.id);
            const proposals = await api<Proposal[]>(`/jobs/${job.id}/proposals`);
            if (active) setProposals(proposals);
          }
        })
        .catch((error: Error) => {
          if (active) setError(error.message);
        });
    return () => {
      active = false;
    };
  }, [job.id, owner]);
  async function submit(event: FormEvent<HTMLFormElement>, kind: 'bids' | 'proposals') {
    event.preventDefault();
    setBusy(true);
    setError('');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      const result = await api<{ id: string }>(
        `/jobs/${job.id}/${kind}`,
        kind === 'bids'
          ? { ...data, proposedAmount: Number(data.proposedAmount), currency: job.currency }
          : {
              ...data,
              amount: Number(data.amount),
              currency: job.currency,
              ...(bidId ? { bidId } : {}),
            },
        'POST',
        kind === 'bids' ? bidKey.current : proposalKey.current,
      );
      if (kind === 'bids') setBidId(result.id);
      else {
        setProposals(await api<Proposal[]>(`/jobs/${job.id}/proposals`));
        proposalKey.current = crypto.randomUUID();
      }
      setMessage(
        kind === 'bids'
          ? 'Bid submitted. You can now prepare a proposal draft.'
          : 'Proposal draft saved.',
      );
      onSaved();
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title={job.title} onClose={onClose} wide>
      <p>{job.description}</p>
      <h3>Deliverables</h3>
      <p>{job.deliverables}</p>
      <p>
        {job.budget_min}–{job.budget_max} {job.currency} · {job.timeline}
      </p>
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {message && <p role="status">{message}</p>}
      {owner && (
        <>
          <h3>Submitted bids</h3>
          {bids.length ? (
            bids.map((bid) => (
              <article key={bid.id}>
                <p>{bid.cover_letter}</p>
                <p>
                  {bid.proposed_amount} {bid.currency} · {bid.timeline}
                </p>
                <Button variant="secondary" onClick={() => setBidId(bid.id)}>
                  {bidId === bid.id ? 'Selected for proposal' : 'Use this bid in a proposal'}
                </Button>
              </article>
            ))
          ) : (
            <p>No bids submitted yet.</p>
          )}
        </>
      )}
      {!owner && !bidId && (
        <form
          onSubmit={(e) => void submit(e, 'bids')}
          onChange={() => {
            bidKey.current = crypto.randomUUID();
          }}
        >
          <h3>Submit a bid</h3>
          <Field label="Cover letter">
            <textarea name="coverLetter" required minLength={20} maxLength={10000} />
          </Field>
          <Field label={`Proposed amount (${job.currency})`}>
            <input name="proposedAmount" type="number" required min={1} max={100000000} />
          </Field>
          <Field label="Bid timeline">
            <input name="timeline" required maxLength={200} />
          </Field>
          <Button type="submit" disabled={busy}>
            Submit bid · 2 points
          </Button>
        </form>
      )}
      {(owner || bidId) && (
        <details open={Boolean(bidId)}>
          <summary>Prepare proposal draft</summary>
          <form
            onSubmit={(e) => void submit(e, 'proposals')}
            onChange={() => {
              proposalKey.current = crypto.randomUUID();
            }}
          >
            <Field label="Proposal title">
              <input name="title" required maxLength={200} />
            </Field>
            <Field label="Scope">
              <textarea name="scope" required minLength={20} maxLength={10000} />
            </Field>
            <Field label="Proposal deliverables">
              <textarea name="deliverables" required maxLength={5000} />
            </Field>
            <Field label={`Proposal amount (${job.currency})`}>
              <input name="amount" type="number" min={1} max={100000000} required />
            </Field>
            <Field label="Proposal timeline">
              <input name="timeline" required maxLength={200} />
            </Field>
            <Button type="submit" disabled={busy}>
              Save proposal draft
            </Button>
          </form>
        </details>
      )}
      {proposals.length > 0 && (
        <>
          <h3>Proposal drafts</h3>
          {proposals.map((p) => (
            <article key={p.id}>
              <h4>{p.title}</h4>
              <p>{p.scope}</p>
              <p>{p.deliverables}</p>
              <p>
                {p.amount} {p.currency} · {p.status}
              </p>
            </article>
          ))}
        </>
      )}
    </Modal>
  );
}
