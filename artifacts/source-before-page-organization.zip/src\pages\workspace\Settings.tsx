import { Download, ShieldCheck } from 'lucide-react';
import type { FormEvent } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Field, contexts } from '../../components/ui';

import { PageHeading } from '../../components/WorkspaceParts';
export function Settings() {
  const { state, refresh, notify } = useWorkspace();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const canManage = state.permissions.includes('workspace:manage');
  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const data = Object.fromEntries(new FormData(e.currentTarget));
    try {
      await api('/workspace', data, 'PATCH');
      await refresh();
      notify('Workspace settings saved.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow="SETTINGS · YOUR OPERATING CONTEXT"
        title="Make this space your own."
        description="Manage your workspace and understand how your information is used."
      />
      <div className="settings-grid">
        <section className="panel settings-card">
          <h2>Workspace</h2>
          <p>A name and context that fit the work you’re doing.</p>
          <form onSubmit={save}>
            <Field label="Workspace name">
              <input
                name="name"
                defaultValue={state.workspace.name}
                disabled={!canManage}
                required
                maxLength={100}
              />
            </Field>
            <Field label="Starting context">
              <select name="context" defaultValue={state.workspace.context} disabled={!canManage}>
                {contexts.map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </Field>
            {error && (
              <p role="alert" className="form-error">
                {error}
              </p>
            )}
            <Button type="submit" disabled={busy || !canManage}>
              {busy ? 'Saving…' : 'Save changes'}
            </Button>
          </form>
        </section>
        <div>
          <section className="panel settings-card">
            <h2>Your account</h2>
            <dl className="detail-list">
              <div>
                <dt>Name</dt>
                <dd>{state.user.name}</dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>{state.user.email || 'Sample account'}</dd>
              </div>
              <div>
                <dt>Role</dt>
                <dd>Workspace {state.workspace.role}</dd>
              </div>
            </dl>
          </section>
          <section className="panel settings-card">
            <h2>Your data, in view</h2>
            <p>
              Objectives, actions, reflections, and activity are stored in the local application
              database. External AI reviews share only the selected context after workspace opt-in
              and your consent.
            </p>
            {state.permissions.includes('workspace:export') && (
              <a className="button button-secondary" href="/api/export" download>
                <Download size={16} /> Export workspace data
              </a>
            )}
          </section>
          <section className="settings-note">
            <ShieldCheck size={20} />
            <p>
              Workspace owners manage access and review decisions. Enterprise workspaces can add
              existing accounts.
              <Link to="/os/settings/members"> Manage people and access</Link>
              <Link to="/os/settings/notifications"> Review reminders</Link>
              <Link to="/os/settings/ai"> AI and context controls</Link>
            </p>
          </section>
        </div>
      </div>
    </>
  );
}
