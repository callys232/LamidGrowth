import { ArrowRight, Layers3, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Empty, Eyebrow } from '../../components/ui';

import { PageHeading } from '../../components/WorkspaceParts';
export function Capability() {
  const { state, newAction } = useWorkspace();
  return (
    <>
      <PageHeading
        eyebrow="CAPABILITY · WHAT THE NEXT STEP REQUIRES"
        title="Build the conditions for progress."
        description="Review each objective’s constraints and turn the missing support into a practical action."
      />
      <div className="capability-intro">
        <Layers3 size={28} strokeWidth={1.3} />
        <p>
          Capability starts with context. Use the boundaries and success criteria you recorded to
          identify the knowledge, resources, or support the work needs.
        </p>
      </div>
      <div className="capability-grid">
        {state.objectives.map((o) => (
          <section className="panel capability-card" key={o.id}>
            <span className="tag">{o.context}</span>
            <h2>{o.title}</h2>
            <Eyebrow>THE OUTCOME</Eyebrow>
            <p>{o.success || 'No success criteria recorded yet.'}</p>
            <Eyebrow>WHAT TO WORK THROUGH</Eyebrow>
            <p>
              {o.constraints ||
                'No constraints recorded. Consider time, knowledge, resources, and support.'}
            </p>
            <Button variant="secondary" onClick={() => newAction(o.id)}>
              Add a capability-building action <Plus size={15} />
            </Button>
          </section>
        ))}
      </div>
      {state.objectives.length === 0 && (
        <Empty
          title="Start with the work in front of you"
          action={
            <Link className="button button-primary" to="/os/clarity">
              Open Clarity <ArrowRight size={15} />
            </Link>
          }
        >
          Define an objective to understand what the next step requires.
        </Empty>
      )}
    </>
  );
}
