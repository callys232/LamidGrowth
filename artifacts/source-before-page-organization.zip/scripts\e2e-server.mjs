import { createServer } from 'vite';
import { createApp } from '../server/app.mjs';

// Browser tests never reuse the development server or open its account database.
const { app, store, runtime } = createApp({
  filename: ':memory:',
  aiProvider: null,
  rateLimits: { api: { max: 10000 }, auth: { max: 10000 }, mutation: { max: 10000 } },
});
const vite = await createServer({ server: { middlewareMode: true }, appType: 'spa' });
app.use(vite.middlewares);
const server = app.listen(3107, '127.0.0.1');
const worker = setInterval(() => runtime.tick(), 250);
for (const signal of ['SIGTERM', 'SIGINT'])
  process.on(signal, () => {
    clearInterval(worker);
    server.close(async () => {
      await vite.close();
      store.db.close();
      process.exit(0);
    });
  });
