import { ArrowRight, Check, Plus } from 'lucide-react';
import type { FormEvent } from 'react';
import { useState } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Empty, Eyebrow, Field, Modal } from '../../components/ui';

import { PageHeading } from '../../components/WorkspaceParts';
export function Rhythm({ progress = false }: { progress?: boolean }) {
  const { state, refresh, notify } = useWorkspace();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const done = state.actions.filter((a) => a.status === 'Done').length;
  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    setBusy(true);
    try {
      await api('/reviews', data);
      await refresh();
      setOpen(false);
      notify('Reflection saved. Carry the learning forward.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow={progress ? 'GROWTH · THE OUTCOME OVER TIME' : 'RHYTHM · RETURN WITH PERSPECTIVE'}
        title={progress ? 'Make your progress visible.' : 'A rhythm, not a one-time event.'}
        description="See what moved, learn from what changed, and bring a clearer view to the next cycle."
      >
        <Button onClick={() => setOpen(true)}>
          <Plus size={16} /> Record a reflection
        </Button>
      </PageHeading>
      <div className="review-overview">
        <div className="review-stat">
          <Eyebrow>COMPLETED ACTIONS</Eyebrow>
          <strong>
            {done}
            <span> / {state.actions.length}</span>
          </strong>
          <progress value={done} max={state.actions.length || 1} aria-label="Completed actions" />
          <p>Completion is one signal. Your reflection adds the context.</p>
        </div>
        <div>
          <Eyebrow>THE NEXT CYCLE</Eyebrow>
          <h2>{state.reviews[0]?.next || 'What deserves your attention next?'}</h2>
          <p>
            {state.reviews.length
              ? 'From your latest reflection. Revisit it as conditions change.'
              : 'Take a moment to see what you’ve learned before deciding where to go.'}
          </p>
        </div>
      </div>
      <div className="panel-heading">
        <div>
          <h2>Learning that carries forward</h2>
          <span>{state.reviews.length} recorded reflections</span>
        </div>
      </div>
      {state.reviews.length ? (
        <div className="review-grid">
          {state.reviews.map((review) => (
            <article className="panel review-card" key={review.id}>
              <Eyebrow>
                {new Date(review.createdAt).toLocaleDateString('en', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </Eyebrow>
              <h3>What moved forward</h3>
              <p>{review.progressed}</p>
              {review.learned && (
                <>
                  <h3>What I learned</h3>
                  <p>{review.learned}</p>
                </>
              )}
              <div>
                <h3>Carry into the next cycle</h3>
                <p>{review.next}</p>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <Empty
          title="Make room for reflection."
          action={
            <Button variant="secondary" onClick={() => setOpen(true)}>
              Start your first review <ArrowRight size={16} />
            </Button>
          }
        >
          Useful learning is more than a score. Capture what changed and what it means for your next
          step.
        </Empty>
      )}
      {open && (
        <Modal title="Pause. Reflect. Move forward." onClose={() => setOpen(false)}>
          <form onSubmit={save}>
            <Field label="What moved forward?">
              <textarea
                name="progressed"
                maxLength={500}
                rows={3}
                required
                placeholder="The progress worth recognizing…"
              />
            </Field>
            <Field label="What changed or taught you something?">
              <textarea
                name="learned"
                maxLength={5000}
                rows={3}
                placeholder="An assumption, a blocker, a useful insight…"
              />
            </Field>
            <Field label="What will you carry into the next cycle?">
              <textarea
                name="next"
                maxLength={500}
                rows={3}
                required
                placeholder="Your next priority or adjustment…"
              />
            </Field>
            {error && (
              <p className="form-error" role="alert">
                {error}
              </p>
            )}
            <Button type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save reflection'}
              <Check size={16} />
            </Button>
          </form>
        </Modal>
      )}
    </>
  );
}
