import { useEffect, useState } from 'react';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading } from '../../components/WorkspaceParts';
import { Empty } from '../../components/ui';
import { Link } from 'react-router-dom';

interface Snapshot {
  id: string;
  objectiveId: string;
  objectiveVersion: number;
  completed: number;
  total: number;
  createdAt: string;
}
export function Progress() {
  const { state } = useWorkspace();
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    api<Snapshot[]>('/progress')
      .then((items) => {
        if (active) setSnapshots(items);
      })
      .catch((error: Error) => {
        if (active) setError(error.message);
      });
    return () => {
      active = false;
    };
  }, []);
  return (
    <>
      <PageHeading
        eyebrow="PROGRESS"
        title="Evidence over time"
        description="Compare recorded progress with the work in front of you."
      />
      <section className="panel settings-card">
        <h2>Current workspace</h2>
        <p>
          {state.actions.filter((a) => a.status === 'Done').length} of {state.actions.length}{' '}
          actions complete · {state.reviews.length} reflections
        </p>
        <Link to="/os/rhythm">Read and record reflections</Link>
      </section>
      {error && (
        <p role="alert" className="form-error">
          {error}
        </p>
      )}
      {!snapshots.length && (
        <Empty title="Build an evidence history">
          Run an approved progress-recording workflow to capture your first snapshot.{' '}
          <Link to="/os/workflows">Open workflows</Link>
        </Empty>
      )}
      {snapshots.map((snapshot) => (
        <section className="panel settings-card" key={snapshot.id}>
          <h2>
            {state.objectives.find((o) => o.id === snapshot.objectiveId)?.title ||
              'Recorded objective'}
          </h2>
          <p>
            {new Date(snapshot.createdAt).toLocaleString()} · Objective version{' '}
            {snapshot.objectiveVersion}
          </p>
          <progress
            max={snapshot.total || 1}
            value={snapshot.completed}
            aria-label={`${snapshot.completed} of ${snapshot.total} actions complete`}
          />
          <p>
            {snapshot.completed} of {snapshot.total} actions were complete at this observation.
          </p>
        </section>
      ))}
    </>
  );
}
