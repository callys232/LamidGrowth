import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { PageHeading } from '../../components/WorkspaceParts';
import { Button, Empty, Field } from '../../components/ui';

interface Policy {
  configured: boolean;
  enabled: boolean;
  dailyLimit: number;
  version: number;
  provider: string | null;
  model: string | null;
  accountEligible: boolean;
}
interface Review {
  id: string;
  principalId: string;
  objectiveId: string;
  question: string;
  status: string;
  model: string;
  createdAt: string;
  review?: {
    summary: string;
    assumptions: string[];
    suggestions: { title: string; rationale: string }[];
    evidenceIds: string[];
  };
  sources: { id: string; version: number; kind: string }[];
}
export function Intelligence({ settings = false }: { settings?: boolean }) {
  const { state, notify, newAction } = useWorkspace();
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [knowledge, setKnowledge] = useState<{ id: string; title: string; version: number }[]>([]);
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const [objectiveId, setObjectiveId] = useState(state.objectives[0]?.id || '');
  async function load() {
    const [policy, reviews] = await Promise.all([
      api<Policy>('/ai/settings'),
      api<Review[]>('/ai/reviews'),
    ]);
    setPolicy(policy);
    setReviews(reviews);
  }
  useEffect(() => {
    let active = true;
    Promise.all([
      api<Policy>('/ai/settings'),
      api<Review[]>('/ai/reviews'),
      api<{ items: { id: string; title: string; version: number }[] }>('/knowledge'),
    ])
      .then(([policy, reviews, knowledge]) => {
        if (active) {
          setPolicy(policy);
          setReviews(reviews);
          setKnowledge(knowledge.items);
        }
      })
      .catch((error: Error) => {
        if (active) setError(error.message);
      });
    return () => {
      active = false;
    };
  }, []);
  useEffect(() => {
    if (settings) return;
    let active = true;
    const timer = setInterval(() => {
      if (!document.hidden)
        void api<Review[]>('/ai/reviews')
          .then((items) => {
            if (active) setReviews(items);
          })
          .catch(() => {});
    }, 5000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [settings]);
  async function configure(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!policy) return;
    const form = new FormData(event.currentTarget);
    setBusy(true);
    setError('');
    try {
      await api(
        '/ai/settings',
        {
          enabled: form.get('enabled') === 'on',
          dailyLimit: Number(form.get('dailyLimit')),
          version: policy.version,
        },
        'PATCH',
      );
      await load();
      notify('AI review settings saved.');
    } catch (error) {
      setError((error as Error).message);
      await load().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  async function review(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const form = new FormData(event.currentTarget);
    try {
      await api('/ai/reviews', {
        objectiveId,
        objectiveVersion: state.objectives.find((o) => o.id === objectiveId)?.version,
        knowledgeIds: form.getAll('knowledge'),
        question: form.get('question'),
        consent: form.get('consent') === 'on',
        requestKey: crypto.randomUUID(),
      });
      await load();
      notify('Review prepared. Consider its evidence and assumptions before acting.');
    } catch (error) {
      setError((error as Error).message);
      await load().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow={settings ? 'AI & CONTEXT CONTROLS' : 'INTELLIGENCE'}
        title={settings ? 'Control external AI reviews' : 'Review an objective with AI'}
        description="Choose the context to share and keep decisions in your hands."
      />
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {!policy?.configured && (
        <section className="panel settings-card">
          <h2>AI provider not configured</h2>
          <p>
            Your server operator can connect an AI provider.{' '}
            <Link to="/os/companion">Guided planning</Link> remains available.
          </p>
        </section>
      )}
      {policy?.configured && (
        <p>
          Provider: {policy.provider} · Model: {policy.model} ·{' '}
          {policy.enabled ? 'Enabled' : 'Disabled'} · Limit: {policy.dailyLimit} requests per day
        </p>
      )}
      {policy && !policy.accountEligible && (
        <p>
          External AI reviews require a verified account.{' '}
          <Link to="/verify">Verify your account</Link>.
        </p>
      )}
      {settings && policy && state.permissions.includes('workspace:manage') && (
        <section className="panel settings-card">
          <h2>Workspace policy</h2>
          <form key={policy.version} onSubmit={configure}>
            <label className="checkbox-field">
              <input
                name="enabled"
                type="checkbox"
                defaultChecked={policy.enabled}
                disabled={!policy.configured || !policy.accountEligible}
              />
              Allow members to request external AI reviews
            </label>
            <Field label="Daily review limit">
              <input
                name="dailyLimit"
                type="number"
                min={1}
                max={100}
                required
                defaultValue={policy.dailyLimit}
              />
            </Field>
            <p>
              Requests, including failed attempts, count toward this limit. Each request still
              requires the sender's consent. Disabling reviews prevents new requests and discards
              responses from requests still in progress.
            </p>
            <Button type="submit" disabled={busy}>
              Save AI settings
            </Button>
          </form>
        </section>
      )}
      {!settings && policy?.enabled && policy.accountEligible && state.objectives.length > 0 && (
        <section className="panel settings-card">
          <h2>Choose exactly what to share</h2>
          <form onSubmit={review}>
            <Field label="Objective to review">
              <select value={objectiveId} onChange={(e) => setObjectiveId(e.target.value)}>
                {state.objectives.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.title}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Question for the review">
              <textarea name="question" required maxLength={2000} rows={3} />
            </Field>
            <fieldset>
              <legend>Optional knowledge sources (up to five)</legend>
              {knowledge.map((item) => (
                <label className="checkbox-field" key={item.id}>
                  <input type="checkbox" name="knowledge" value={item.id} />
                  {item.title} · Version {item.version}
                </label>
              ))}
            </fieldset>
            <label className="checkbox-field">
              <input type="checkbox" name="consent" required />I agree to send this objective,
              question, and selected sources to {policy.provider} for this review.
            </label>
            <Button type="submit" disabled={busy}>
              {busy ? 'Preparing review…' : 'Request AI review'}
            </Button>
          </form>
        </section>
      )}
      {!settings && <Link to="/os/settings/ai">Manage AI and context controls</Link>}
      {!reviews.length && !settings && (
        <Empty title="No AI reviews yet">
          Reviews appear here after a permitted request. Model suggestions do not create or approve
          actions.
        </Empty>
      )}
      {!settings &&
        reviews.map((item) => (
          <section className="panel settings-card" key={item.id}>
            <h2>{item.question}</h2>
            <p>
              {item.status} · {item.model} · {new Date(item.createdAt).toLocaleString()}
            </p>
            {item.status === 'pending' &&
              (item.principalId === state.user.id || state.workspace.role === 'owner') && (
                <Button
                  variant="secondary"
                  onClick={() => {
                    void api(`/ai/reviews/${item.id}`, { command: 'cancel' }, 'PATCH')
                      .then(load)
                      .catch((error: Error) => setError(error.message));
                  }}
                >
                  Cancel review
                </Button>
              )}
            {item.review && (
              <>
                <p>{item.review.summary}</p>
                <h3>Assumptions to check</h3>
                <ul>
                  {item.review.assumptions.map((assumption, i) => (
                    <li key={i}>{assumption}</li>
                  ))}
                </ul>
                <h3>Suggested next steps</h3>
                {item.review.suggestions.map((suggestion, i) => (
                  <article key={i}>
                    <h4>{suggestion.title}</h4>
                    <p>{suggestion.rationale}</p>
                  </article>
                ))}
                <p>
                  Based on {item.sources.length} selected sources. Recheck current context before
                  deciding.
                </p>
                <Button variant="secondary" onClick={() => newAction(item.objectiveId)}>
                  Define an action after reviewing
                </Button>
              </>
            )}
          </section>
        ))}
    </>
  );
}
