import express from 'express';
import { resolve } from 'node:path';
import { createApp } from './app.mjs';
const production = process.argv.includes('--production');
const { app, store } = createApp({
  filename: process.env.DATABASE_PATH || 'data/lamid.db',
  production,
});
if (production) {
  app.use(express.static(resolve('dist'), { index: false }));
  app.get('/{*path}', (_req, res) => res.sendFile(resolve('dist/index.html')));
} else {
  const { createServer } = await import('vite');
  const vite = await createServer({ server: { middlewareMode: true }, appType: 'spa' });
  app.use(vite.middlewares);
}
const port = Number(process.env.PORT || 3000);
const server = app.listen(port, '127.0.0.1', () =>
  console.log(`LAMID ONE is ready at http://localhost:${port}`),
);
for (const signal of ['SIGINT', 'SIGTERM'])
  process.on(signal, () =>
    server.close(() => {
      store.db.close();
      process.exit(0);
    }),
  );
