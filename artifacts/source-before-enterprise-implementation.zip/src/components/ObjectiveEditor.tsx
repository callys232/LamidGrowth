import type { FormEvent } from 'react';
import { useState } from 'react';
import { api } from '../api';
import type { Objective } from '../types';
import { Button, Field, Modal } from './ui';
import { useWorkspace } from './WorkspaceShell';
export function ObjectiveEditor({
  objective,
  onClose,
}: {
  objective: Objective;
  onClose: () => void;
}) {
  const { refresh, notify } = useWorkspace();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    const data = Object.fromEntries(new FormData(event.currentTarget));
    try {
      await api(`/objectives/${objective.id}`, { ...data, version: objective.version }, 'PATCH');
      await refresh();
      notify('Objective updated. Your context carries forward.');
      onClose();
    } catch (error) {
      setError((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="Keep your objective in context." onClose={onClose}>
      <form onSubmit={save}>
        <Field label="Objective">
          <input name="title" defaultValue={objective.title} required maxLength={500} />
        </Field>
        <Field label="The situation">
          <textarea
            name="description"
            defaultValue={objective.description}
            rows={3}
            maxLength={5000}
          />
        </Field>
        <Field label="Success criteria">
          <textarea name="success" defaultValue={objective.success} rows={2} maxLength={5000} />
        </Field>
        <Field label="Constraints and assumptions">
          <textarea
            name="constraints"
            defaultValue={objective.constraints}
            rows={2}
            maxLength={5000}
          />
        </Field>
        <div className="form-grid">
          <Field label="Priority">
            <select name="priority" defaultValue={objective.priority}>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
          </Field>
          <Field label="Status">
            <select name="status" defaultValue={objective.status}>
              <option>Active</option>
              <option>Paused</option>
              <option>Complete</option>
            </select>
          </Field>
        </div>
        <Field label="Target date">
          <input name="targetDate" type="date" defaultValue={objective.targetDate} />
        </Field>
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <div className="modal-actions">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Save objective'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
