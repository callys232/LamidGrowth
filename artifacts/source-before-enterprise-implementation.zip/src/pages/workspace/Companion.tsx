import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Plus,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Button, Eyebrow, Field } from '../../components/ui';

import { PageHeading } from '../../components/WorkspaceParts';
export function Companion() {
  const { state, refresh, notify } = useWorkspace();
  const [step, setStep] = useState(0);
  const [title, setTitle] = useState('');
  const [context, setContext] = useState('');
  const [success, setSuccess] = useState('');
  const [constraints, setConstraints] = useState('');
  const [next, setNext] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    setError('');
    try {
      await api('/plans', {
        objective: {
          title,
          description: context,
          success,
          constraints,
          priority: 'Medium',
          context: state.workspace.context,
        },
        nextAction: next,
      });
      await refresh();
      setStep(3);
      notify('Your thinking is now connected to your work.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow="COMPANION · SPACE TO THINK"
        title="What are you working through?"
        description="Turn a question into a clearer objective and a deliberate next step."
      />
      <div className="companion-layout">
        <section className="companion-panel">
          <div className="companion-top">
            <span className="companion-symbol">
              <Sparkles size={21} />
            </span>
            <div>
              <strong>Your thinking partner</strong>
              <small>Guided planning · no AI model connected</small>
            </div>
            <span className="tag">YOU LEAD</span>
          </div>
          <div className="companion-conversation">
            {step === 0 && (
              <>
                <div className="companion-message">
                  <h2>Let’s start with what’s on your mind.</h2>
                  <p>
                    A decision, an opportunity, a challenge. It doesn’t have to be perfectly formed.
                  </p>
                </div>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setStep(1);
                  }}
                >
                  <Field label="What do you want to move forward?">
                    <textarea
                      rows={4}
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      maxLength={500}
                      required
                      placeholder="I want to…"
                    />
                  </Field>
                  <div className="suggestion-chips">
                    {[
                      'Bring a business idea into focus',
                      'Make a difficult decision',
                      'Build a more intentional week',
                    ].map((x) => (
                      <button key={x} type="button" onClick={() => setTitle(x)}>
                        {x}
                        <Plus size={12} />
                      </button>
                    ))}
                  </div>
                  <Button type="submit" disabled={!title.trim()}>
                    Bring it into focus <ArrowRight size={16} />
                  </Button>
                </form>
              </>
            )}
            {step === 1 && (
              <>
                <div className="user-message">{title}</div>
                <div className="companion-message">
                  <h2>Give the objective some context.</h2>
                  <p>
                    What is happening, what would success look like, and what boundaries should stay
                    in view?
                  </p>
                </div>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setStep(2);
                  }}
                >
                  <Field label="The situation">
                    <textarea
                      value={context}
                      onChange={(e) => setContext(e.target.value)}
                      rows={3}
                      maxLength={5000}
                      required
                      placeholder="What makes this important now?"
                    />
                  </Field>
                  <Field label="A meaningful outcome">
                    <input
                      value={success}
                      onChange={(e) => setSuccess(e.target.value)}
                      maxLength={5000}
                      required
                      placeholder="I’ll know I’ve made progress when…"
                    />
                  </Field>
                  <Field label="Constraints or assumptions">
                    <input
                      value={constraints}
                      onChange={(e) => setConstraints(e.target.value)}
                      maxLength={5000}
                      placeholder="Time, budget, people, or things to validate"
                    />
                  </Field>
                  <div className="modal-actions">
                    <Button variant="ghost" onClick={() => setStep(0)}>
                      <ArrowLeft size={15} /> Back
                    </Button>
                    <Button type="submit">
                      Choose the next step <ArrowRight size={16} />
                    </Button>
                  </div>
                </form>
              </>
            )}
            {step === 2 && (
              <>
                <div className="companion-message">
                  <h2>Understanding becomes useful through action.</h2>
                  <p>
                    Choose one small, concrete next step. This plan comes from your own inputs;
                    review it before saving.
                  </p>
                </div>
                <div className="plan-summary">
                  <Eyebrow>YOUR OBJECTIVE</Eyebrow>
                  <h3>{title}</h3>
                  <p>{context}</p>
                  <dl>
                    <dt>Success</dt>
                    <dd>{success}</dd>
                    <dt>Keep in view</dt>
                    <dd>{constraints || 'No constraints recorded.'}</dd>
                  </dl>
                </div>
                <Field label="Your next action (optional)">
                  <input
                    value={next}
                    onChange={(e) => setNext(e.target.value)}
                    maxLength={500}
                    placeholder="One action you can take to move this forward"
                  />
                </Field>
                {error && (
                  <p className="form-error" role="alert">
                    {error}
                  </p>
                )}
                <div className="modal-actions">
                  <Button variant="ghost" onClick={() => setStep(1)}>
                    <ArrowLeft size={15} /> Refine
                  </Button>
                  <Button disabled={busy} onClick={() => void save()}>
                    {busy ? 'Saving…' : 'Save my plan'}
                    <Check size={16} />
                  </Button>
                </div>
              </>
            )}
            {step === 3 && (
              <div className="companion-complete">
                <CheckCircle2 size={40} strokeWidth={1.2} />
                <h2>
                  A clearer direction.
                  <br />A concrete next step.
                </h2>
                <p>
                  Your objective is saved in Clarity. Your context will be here when you return.
                </p>
                <Link className="button button-primary" to="/os/clarity">
                  See your objective <ArrowUpRight size={16} />
                </Link>
              </div>
            )}
          </div>
        </section>
        <aside className="companion-context">
          <Eyebrow>YOUR CONTEXT, IN VIEW</Eyebrow>
          <h3>A continuous thread.</h3>
          <p>
            What you bring into this conversation stays connected to the work you choose to create.
          </p>
          <div className="context-step">
            <span className={step >= 0 ? 'current' : ''}>01</span>
            <div>
              <strong>Clarify the objective</strong>
              <small>What matters now?</small>
            </div>
          </div>
          <div className="context-step">
            <span className={step >= 1 ? 'current' : ''}>02</span>
            <div>
              <strong>Understand the situation</strong>
              <small>What shapes your decision?</small>
            </div>
          </div>
          <div className="context-step">
            <span className={step >= 2 ? 'current' : ''}>03</span>
            <div>
              <strong>Make the next move</strong>
              <small>What will you do next?</small>
            </div>
          </div>
          <div className="companion-boundary">
            <ShieldCheck size={20} />
            <strong>Your judgment comes first.</strong>
            <p>
              Nothing is saved until you choose. No external systems are contacted and no work runs
              in the background.
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
