import { Check, Search, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { useWorkspace } from '../../components/WorkspaceShell';
import { Empty } from '../../components/ui';

import { ActionRow, PageHeading } from '../../components/WorkspaceParts';
export function Governance() {
  const { state } = useWorkspace();
  const [filter, setFilter] = useState('');
  const pending = state.actions.filter((a) => a.status === 'Needs review');
  return (
    <>
      <PageHeading
        eyebrow="GOVERNANCE · CLEAR RESPONSIBILITY"
        title="Capability needs accountability."
        description="Review the decisions that need you and trace the work that has changed."
      />
      <div className="governance-summary">
        <ShieldCheck size={28} strokeWidth={1.3} />
        <div>
          <h3>Your authority stays explicit.</h3>
          <p>
            You own this workspace. Actions that require review cannot be completed without an
            explicit decision. No autonomous external actions are enabled.
          </p>
        </div>
        <span className="tag">OWNER CONTROLLED</span>
      </div>
      <section className="dashboard-section">
        <div className="panel-heading">
          <div>
            <h2>Ready for your judgment</h2>
            <span>{pending.length} actions waiting for review</span>
          </div>
        </div>
        <div className="panel">
          {pending.length ? (
            pending.map((a) => <ActionRow key={a.id} action={a} />)
          ) : (
            <Empty title="Nothing waiting on you">
              When an action is submitted for review, it will appear here.
            </Empty>
          )}
        </div>
      </section>
      <div className="panel-heading">
        <div>
          <h2>The activity trail</h2>
          <span>Recorded changes and the person behind each one.</span>
        </div>
        <label className="audit-search">
          <Search size={15} />
          <input
            placeholder="Filter activity…"
            aria-label="Filter activity"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </label>
      </div>
      <section className="panel audit-list">
        {state.audit
          .filter((e) =>
            `${e.action} ${e.detail} ${e.actor}`.toLowerCase().includes(filter.toLowerCase()),
          )
          .map((event) => (
            <div className="audit-event" key={event.id}>
              <span className="audit-event-icon">
                <Check size={14} />
              </span>
              <div>
                <strong>{event.action}</strong>
                <p>{event.detail}</p>
                <small>
                  {event.actor} · {new Date(event.createdAt).toLocaleString()}
                </small>
              </div>
            </div>
          ))}
        {!state.audit.some((e) =>
          `${e.action} ${e.detail} ${e.actor}`.toLowerCase().includes(filter.toLowerCase()),
        ) && <Empty title="No matching activity">Try a different search.</Empty>}
      </section>
    </>
  );
}
