import {
  ArrowLeft,
  ArrowRight,
  BriefcaseBusiness,
  Building2,
  Check,
  Eye,
  EyeOff,
  Landmark,
  Lightbulb,
  Network,
  Rocket,
  UserRound,
  Users,
} from 'lucide-react';
import type { FormEvent } from 'react';
import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { OrbitVisual } from '../components/Orbit';
import { Brand, Button, Eyebrow, Field, contexts } from '../components/ui';
import type { Context } from '../types';
const icons = [
  UserRound,
  BriefcaseBusiness,
  Lightbulb,
  Rocket,
  Users,
  Building2,
  Network,
  Landmark,
];
export function AuthPage({ login = false }: { login?: boolean }) {
  const navigate = useNavigate();
  const [step, setStep] = useState(login ? 1 : 0);
  const [context, setContext] = useState<Context>('Professional');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [visible, setVisible] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const data = new FormData(e.currentTarget);
    try {
      await api(
        login ? '/auth/login' : '/auth/signup',
        login
          ? { email: data.get('email'), password: data.get('password') }
          : {
              name: data.get('name'),
              email: data.get('email'),
              password: data.get('password'),
              context,
            },
      );
      navigate('/os');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function demo() {
    setBusy(true);
    setError('');
    try {
      await api('/auth/demo', {});
      navigate('/os');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <div className="auth-main">
        <Brand />
        <Link to="/" className="back-link">
          <ArrowLeft size={14} /> Back to LAMID ONE
        </Link>
        <div className="auth-content">
          <Eyebrow>
            {login ? 'YOUR CONTEXT IS WAITING' : `YOUR FIRST STEP · ${step + 1} OF 2`}
          </Eyebrow>
          <h2>
            {login ? (
              <>
                Welcome
                <br />
                <em>back.</em>
              </>
            ) : step === 0 ? (
              <>
                Start with
                <br />
                <em>your context.</em>
              </>
            ) : (
              <>
                A space to
                <br />
                <em>make progress.</em>
              </>
            )}
          </h2>
          <p>
            {login
              ? 'Pick up where you left off.'
              : step === 0
                ? 'Where are you starting? Choose what fits your work today.'
                : `Create your account to begin in a ${context.toLowerCase()} context.`}
          </p>
          {!login && step === 0 ? (
            <>
              <div className="context-selector">
                {contexts.map((item, i) => {
                  const Icon = icons[i];
                  return (
                    <button
                      key={item}
                      className={context === item ? 'selected' : ''}
                      onClick={() => setContext(item)}
                      aria-pressed={context === item}
                    >
                      <Icon size={19} strokeWidth={1.5} />
                      <span>{item}</span>
                      {context === item && <Check size={15} />}
                    </button>
                  );
                })}
              </div>
              <Button className="full-width" onClick={() => setStep(1)}>
                Continue <ArrowRight size={16} />
              </Button>
              <p className="auth-footnote">Your context can change as your work grows.</p>
              <div className="auth-divider">
                <span>or take a look first</span>
              </div>
              <Button variant="secondary" className="full-width" disabled={busy} onClick={demo}>
                {busy ? 'Opening…' : 'Explore a sample workspace'}
                <ArrowRight size={16} />
              </Button>
            </>
          ) : (
            <form onSubmit={submit}>
              {!login && (
                <Field label="Your name">
                  <input
                    name="name"
                    autoComplete="name"
                    required
                    maxLength={100}
                    placeholder="How should we call you?"
                  />
                </Field>
              )}
              <Field label="Email address">
                <input
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  maxLength={254}
                  placeholder="you@example.com"
                />
              </Field>
              <Field label="Password" hint={login ? undefined : 'Use at least 12 characters.'}>
                <div className="password-field">
                  <input
                    name="password"
                    type={visible ? 'text' : 'password'}
                    autoComplete={login ? 'current-password' : 'new-password'}
                    minLength={login ? 1 : 12}
                    maxLength={128}
                    required
                    placeholder={login ? 'Your password' : 'Create a strong password'}
                  />
                  <button
                    type="button"
                    onClick={() => setVisible(!visible)}
                    aria-label={visible ? 'Hide password' : 'Show password'}
                  >
                    {visible ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </Field>
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <Button type="submit" className="full-width" disabled={busy}>
                {busy ? 'One moment…' : login ? 'Sign in' : 'Create your workspace'}
                <ArrowRight size={16} />
              </Button>
              {!login && (
                <button
                  type="button"
                  className="text-button change-context"
                  onClick={() => setStep(0)}
                >
                  <ArrowLeft size={14} /> Change starting context
                </button>
              )}
              <p className="auth-footnote">
                Local development edition. Account data is saved on this computer.
              </p>
            </form>
          )}
          {error && step === 0 && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          <p className="auth-switch">
            {login ? 'Starting a new chapter?' : 'Already have a workspace?'}{' '}
            <Link to={login ? '/start' : '/login'}>
              {login ? 'Get started' : 'Sign in'} <ArrowUpRightText />
            </Link>
          </p>
        </div>
        <span className="auth-copyright">© {new Date().getFullYear()} LAMID ONE</span>
      </div>
      <aside className="auth-aside">
        <Eyebrow>PROGRESS, WITH INTENTION.</Eyebrow>
        <OrbitVisual small />
        <blockquote>
          “A clearer view.
          <br />A stronger next step.
          <br />
          <em>A continuous journey.</em>”
        </blockquote>
        <div className="auth-aside-bottom">
          <span className="live-dot" /> HUMAN JUDGMENT AT THE CENTER
        </div>
      </aside>
    </div>
  );
}

export function PasswordRecovery() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage('');
    try {
      const result = await api<{ recoveryToken?: string }>('/auth/request-recovery', { email });
      setToken(result.recoveryToken || '');
      setMessage('If an account matches, recovery instructions are ready.');
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <div className="auth-main">
        <Brand />
        <Link to="/login" className="back-link">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
        <div className="auth-content">
          <Eyebrow>ACCOUNT RECOVERY</Eyebrow>
          <h2>
            Recover <em>access.</em>
          </h2>
          <p>
            Enter the email associated with your account. We will not reveal whether an account
            exists.
          </p>
          <form onSubmit={submit}>
            <Field label="Email address">
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                type="email"
                required
                autoComplete="email"
              />
            </Field>
            {message && (
              <p className="form-error" role="status">
                {message}
              </p>
            )}
            {token && (
              <Link
                className="button button-secondary full-width"
                to={`/reset-password?token=${token}`}
              >
                Continue to password reset <ArrowRight size={16} />
              </Link>
            )}
            {!token && (
              <Button type="submit" className="full-width" disabled={busy}>
                {busy ? 'Checking…' : 'Send recovery instructions'} <ArrowRight size={16} />
              </Button>
            )}
          </form>
        </div>
      </div>
      <aside className="auth-aside">
        <OrbitVisual small />
      </aside>
    </div>
  );
}

export function ResetPassword() {
  const [params] = useSearchParams();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [message, setMessage] = useState('');
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (password !== confirm) return setMessage('Passwords do not match.');
    setBusy(true);
    setMessage('');
    try {
      await api('/auth/reset-password', { token: params.get('token'), password });
      setDone(true);
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <div className="auth-main">
        <Brand />
        <Link to="/login" className="back-link">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
        <div className="auth-content">
          <Eyebrow>RESET SECURITY</Eyebrow>
          <h2>
            Create a <em>new password.</em>
          </h2>
          {done ? (
            <>
              <p>Your password was changed and existing sessions were signed out.</p>
              <Link className="button button-primary full-width" to="/login">
                Return to sign in <ArrowRight size={16} />
              </Link>
            </>
          ) : (
            <form onSubmit={submit}>
              <Field label="New password">
                <input
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  minLength={12}
                  maxLength={128}
                  required
                  autoComplete="new-password"
                />
              </Field>
              <Field label="Confirm password">
                <input
                  type="password"
                  value={confirm}
                  onChange={(event) => setConfirm(event.target.value)}
                  minLength={12}
                  maxLength={128}
                  required
                  autoComplete="new-password"
                />
              </Field>
              {message && (
                <p className="form-error" role="alert">
                  {message}
                </p>
              )}
              <Button type="submit" className="full-width" disabled={busy || !params.get('token')}>
                {busy ? 'Saving…' : 'Save new password'} <ArrowRight size={16} />
              </Button>
            </form>
          )}
        </div>
      </div>
      <aside className="auth-aside">
        <OrbitVisual small />
      </aside>
    </div>
  );
}

export function VerifyAccount() {
  const [params] = useSearchParams();
  const [message, setMessage] = useState('');
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  async function verify() {
    setBusy(true);
    setMessage('');
    try {
      await api('/auth/verify', { token: params.get('token') });
      setDone(true);
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-page">
      <div className="auth-main">
        <Brand />
        <Link to="/login" className="back-link">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
        <div className="auth-content">
          <Eyebrow>ACCOUNT VERIFICATION</Eyebrow>
          <h2>
            Confirm <em>your account.</em>
          </h2>
          {done ? (
            <>
              <p>Your account is verified. You can continue into your workspace.</p>
              <Link className="button button-primary full-width" to="/login">
                Continue to sign in <ArrowRight size={16} />
              </Link>
            </>
          ) : (
            <>
              <p>
                Use the verification link from your account email. Links expire and can only be used
                once.
              </p>
              {message && (
                <p className="form-error" role="alert">
                  {message}
                </p>
              )}
              <Button
                className="full-width"
                disabled={busy || !params.get('token')}
                onClick={() => void verify()}
              >
                {busy ? 'Checking…' : 'Verify account'} <Check size={16} />
              </Button>
            </>
          )}
        </div>
      </div>
      <aside className="auth-aside">
        <OrbitVisual small />
      </aside>
    </div>
  );
}
function ArrowUpRightText() {
  return <span aria-hidden="true">↗</span>;
}
