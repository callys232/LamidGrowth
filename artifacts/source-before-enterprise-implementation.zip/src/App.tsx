import { useEffect } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import { WorkspaceShell } from './components/WorkspaceShell';
import pages from './content/pages.json';
import { AuthPage, PasswordRecovery, ResetPassword, VerifyAccount } from './pages/Auth';
import { ContentPage } from './pages/ContentPage';
import {
  ActionsPage,
  Capability,
  Clarity,
  Companion,
  Dashboard,
  Governance,
  PlannedModule,
  Rhythm,
  Settings,
} from './pages/Workspace';
function RouteEffects() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
    const page = pages.find((p) => p.route === pathname);
    document.title = pathname.startsWith('/os')
      ? 'Your workspace · LAMID ONE'
      : page?.seo_title || 'LAMID ONE — Progress, with intention.';
    let robots = document.querySelector('meta[name="robots"]');
    if (!robots) {
      robots = document.createElement('meta');
      robots.setAttribute('name', 'robots');
      document.head.appendChild(robots);
    }
    robots.setAttribute('content', 'noindex, nofollow');
    const description = document.querySelector('meta[name="description"]');
    if (description)
      description.setAttribute(
        'content',
        page?.meta_description ||
          'A connected space for your context, decisions, and next chapter.',
      );
  }, [pathname]);
  return null;
}
export function App() {
  return (
    <>
      <RouteEffects />
      <div id="top" />
      <Routes>
        <Route path="/" element={<ContentPage />} />
        <Route
          path="/start"
          element={
            <ContentPage>
              <AuthPage key="start" />
            </ContentPage>
          }
        />
        <Route
          path="/signup"
          element={
            <ContentPage>
              <AuthPage key="signup" />
            </ContentPage>
          }
        />
        <Route
          path="/login"
          element={
            <ContentPage>
              <AuthPage key="login" login />
            </ContentPage>
          }
        />
        <Route path="/forgot-password" element={<PasswordRecovery />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/verify" element={<VerifyAccount />} />
        <Route
          path="/onboarding"
          element={
            <ContentPage>
              <AuthPage key="onboarding" />
            </ContentPage>
          }
        />
        <Route path="/os" element={<WorkspaceShell />}>
          <Route index element={<Dashboard />} />
          <Route path="today" element={<ActionsPage today />} />
          <Route path="clarity" element={<Clarity />} />
          <Route path="capability" element={<Capability />} />
          <Route path="consistency" element={<ActionsPage />} />
          <Route path="companion" element={<Companion />} />
          <Route path="workflows" element={<ActionsPage workflows />} />
          <Route path="rhythm" element={<Rhythm />} />
          <Route path="progress" element={<Rhythm progress />} />
          <Route path="governance" element={<Governance />} />
          <Route path="audit" element={<Governance />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<PlannedModule />} />
        </Route>
        <Route path="*" element={<ContentPage />} />
      </Routes>
    </>
  );
}
